from peewee import *
from .BaseModel import BaseModel


class nfe_config_usuarios_relatorios(BaseModel):
    id_empresa = IntegerField()  #int
    id_usuario = IntegerField()  #int
    id_parceiro = IntegerField()  #int
    relatorio = CharField()  #char
    coluna = CharField()  #char
    ordem = CharField()  #enum
    display = CharField()  #enum
