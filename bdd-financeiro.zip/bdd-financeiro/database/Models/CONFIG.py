from peewee import *
from .BaseModel import BaseModel


class CONFIG(BaseModel):
    id_config = IntegerField(primary_key=True)  #tinyint
    nome = CharField()  #varchar
    titulo_site = CharField()  #varchar
    cnpj = CharField()  #varchar
    telefone = CharField()  #varchar
    email_contato = CharField()  #varchar
    website = CharField()  #varchar
    css_config = CharField()  #char
    login_smtp = CharField()  #char
    senha_smtp = CharField()  #char
    host_smtp = CharField()  #char
    from_smtp = CharField()  #char
    mensagem_sistema = CharField()  #longtext
    banco_agencia = CharField()  #char
    banco_agencia_dv = CharField()  #char
    banco_conta = CharField()  #char
    banco_conta_dv = CharField()  #char
    banco_convenio = CharField()  #char
    banco_carteira = CharField()  #char
    banco_instrucoes = CharField()  #varchar
    resgate_comissao = DecimalField()  #decimal
    valor_sms = DecimalField()  #decimal
    valor_email = DecimalField()  #decimal
    valor_certificado = DecimalField()  #decimal
    valor_certificado_promocao = DecimalField()  #decimal
    promocao_banner = IntegerField()  #tinyint
    promocao_titulo = CharField()  #char
    termos_loja = CharField()  #longtext
    termos_sistema = CharField()  #longtext
    host_buckets3 = CharField()  #char
    nome_buckets3 = CharField()  #char
    ip_acessoADM = CharField()  #longtext
    aliquota_iss = DecimalField()  #decimal
    versao_emissora3 = CharField()  #char
    pdv_desativado = IntegerField()  #int
    valor_meta_mensal = DecimalField()  #decimal
    nps_primeira_exibicao = IntegerField()  #int
    nps_proxima_exibicao = IntegerField()  #int
    nps_ocultar_exibicao = IntegerField()  #int

    @classmethod
    def dados_iniciais(cls, id_empresa, id_usuario):
        return [
            {
                'id_config': 1,
                'nome': 'DEV VHSYS',
                'titulo_site': 'VHSYS',
                'cnpj': '12.702.717/0001-64',
                'telefone': '0800 007 0017',
                'email_contato': 'contato@vhsys.com.br',
                'website': 'dev.vhsys.com',
                'css_config': 'azul',
                'login_smtp': 'AKIAJ55C62QSCBS6QTIA',
                'senha_smtp': 'AmXIWF0qLuh8u/rZislGt+bJ1yO/Hx5iHlaq1C3gJrA9',
                'host_smtp': 'email-smtp.us-east-1.amazonaws.com',
                'from_smtp': 'noreply@vhsys.com',
                'mensagem_sistema': '',
                'banco_agencia': '2762',
                'banco_agencia_dv': '',
                'banco_conta': '27405',
                'banco_conta_dv': '4',
                'banco_convenio': '',
                'banco_carteira': '16',
                'banco_instrucoes': '',
                'resgate_comissao': '100.00',
                'valor_sms': '0.10',
                'valor_email': '0.02',
                'valor_certificado': '215.00',
                'valor_certificado_promocao': '115.00',
                'promocao_banner': 0,
                'promocao_titulo': '50% OFF',
                'termos_loja': '',
                'termos_sistema': '',
                'host_buckets3': 'https://s3-sa-east-1.amazonaws.com/',
                'nome_buckets3': 'static.vhsys.com',
                'ip_acessoADM': '18.231.95.246;10.0.0.2;18.231.95.246;10.0.0.2;10.1.2.244;127.0.0.1;177.207.208.70;177.19.232.113;189',
                'aliquota_iss': None,
                'versao_emissora3': '1.61',
                'pdv_desativado': 0,
                'valor_meta_mensal': None,
                'nps_primeira_exibicao': 30,
                'nps_proxima_exibicao': 45,
                'nps_ocultar_exibicao': 7,
            }
        ]