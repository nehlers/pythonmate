from peewee import *
from .BaseModel import BaseModel
from .nfe_financeiro_contas_pag_agrupamentos import nfe_financeiro_contas_pag_agrupamentos
from .nfe_financeiro_contas_pag_historico import nfe_financeiro_contas_pag_historico
from .nfe_financeiro_contas_pag_recebimentos import nfe_financeiro_contas_pag_recebimentos


class nfe_financeiro_contas_pag(BaseModel):
    id_conta_pag = IntegerField(primary_key=True)  #bigint
    id_empresa = IntegerField()  #bigint
    id_registro = IntegerField()  #bigint
    identificacao = CharField()  #char
    nome_conta = CharField()  #char
    id_categoria = IntegerField()  #int
    categoria_pag = CharField()  #char
    id_banco = IntegerField()  #bigint
    id_fornecedor = IntegerField()  #bigint
    nome_fornecedor = CharField()  #varchar
    vencimento_pag = DateTimeField()  #date
    valor_pag = DecimalField()  #decimal
    valor_pago = DecimalField()  #decimal
    data_emissao = DateTimeField()  #date
    n_documento_pag = CharField()  #varchar
    observacoes_pag = CharField()  #longtext
    id_centro_custos = IntegerField()  #bigint
    centro_custos_pag = CharField()  #varchar
    data_pagamento = DateTimeField()  #date
    obs_pagamento = CharField()  #longtext
    forma_pagamento = CharField()  #char
    valor_juros = DecimalField()  #decimal
    valor_desconto = DecimalField()  #decimal
    valor_acrescimo = DecimalField()  #decimal
    data_cad_pag = DateTimeField()  #timestamp
    data_mod_pag = DateTimeField()  #datetime
    agrupado = IntegerField()  #tinyint
    agrupado_data = DateTimeField()  #datetime
    agrupado_user = CharField()  #char
    agrupamento = IntegerField()  #tinyint
    fluxo = IntegerField()  #tinyint
    sync = IntegerField()  #tinyint
    sync_id = IntegerField()  #int
    sync_user = IntegerField()  #int
    lixeira = CharField()  #enum
    situacao = CharField()  #varchar
    status = IntegerField()  #tinyint
    id_pagamento_ob = CharField()  #varchar
    codigo_barras = CharField()  #varchar
    liquidado_pag = CharField()  #enum

    @classmethod
    def apagar_dados_empresa(cls, id_empresa):
        for conta in nfe_financeiro_contas_pag.select().where(nfe_financeiro_contas_pag.id_empresa == id_empresa):
            nfe_financeiro_contas_pag_agrupamentos.delete().where(nfe_financeiro_contas_pag_agrupamentos.id_conta_pag == conta.id_conta_pag).execute()
            nfe_financeiro_contas_pag_historico.delete().where(nfe_financeiro_contas_pag_historico.id_conta_pag == conta.id_conta_pag).execute()
            nfe_financeiro_contas_pag_recebimentos.delete().where(nfe_financeiro_contas_pag_recebimentos.id_conta_pag == conta.id_conta_pag).execute()

        nfe_financeiro_contas_pag.delete().where(nfe_financeiro_contas_pag.id_empresa == id_empresa).execute()
    