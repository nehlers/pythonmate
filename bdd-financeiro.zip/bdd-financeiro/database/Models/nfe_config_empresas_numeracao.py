from peewee import *
from .BaseModel import BaseModel


class nfe_config_empresas_numeracao(BaseModel):
    id_empresa = IntegerField(primary_key=True)  #bigint
    numeracao_cliente = IntegerField()  #int
    numeracao_produto = IntegerField()  #int
    numeracao_transportadora = IntegerField()  #int
    numeracao_vendedor = IntegerField()  #int
    numeracao_contas_pag = IntegerField()  #int
    numeracao_contas_rec = IntegerField()  #int
    numeracao_boleto = IntegerField()  #int
    numeracao_nota = IntegerField()  #int
    numeracao_notah = IntegerField()  #int
    numeracao_scan = IntegerField()  #int
    numeracao_nfs = IntegerField()  #int
    numeracao_nfc = IntegerField()  #int
    numeracao_nfch = IntegerField()  #int
    numeracao_orcamento = IntegerField()  #int
    numeracao_pedido = IntegerField()  #int
    numeracao_frente = IntegerField()  #int
    numeracao_entrada = IntegerField()  #int
    numeracao_ordemservico = IntegerField()  #int
    numeracao_ordemcompra = IntegerField()  #int
    numeracao_cte = IntegerField()  #int
    numeracao_cteh = IntegerField()  #int
    numeracao_mdfe = IntegerField()  #int
    numeracao_mdfeh = IntegerField()  #int
    numeracao_servico_rec = IntegerField()  #int
    numeracao_cotacao = IntegerField()  #int
    numeracao_app_bens = IntegerField()  #int
    numeracao_app_funcionarios = IntegerField()  #int

    @classmethod
    def dados_iniciais(cls, id_empresa, id_usuario):
        return [
            {
                'id_empresa': id_empresa
            }
        ]