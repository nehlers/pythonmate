from peewee import *
from .BaseModel import BaseModel


class nfe_config_empresas_contatos(BaseModel):
    id_contato = IntegerField(primary_key=True)  #int
    id_empresa = IntegerField()  #int
    id_usuario = IntegerField()  #int
    motivo_atualizacao = IntegerField()  #tinyint
    nome = CharField()  #varchar
    email = CharField()  #varchar
    celular = CharField()  #varchar
    expira_em = DateTimeField()  #timestamp
    data_cad_contato = DateTimeField()  #timestamp

    @classmethod
    def dados_iniciais(cls, id_empresa, id_usuario):
        id = cls.select(fn.MAX(cls.id_contato)).scalar()
        id = id if id is not None else 1
        return [
            {
                'id_contato': id+1,
                'id_empresa': id_empresa,
                "id_usuario": id_usuario,
                'motivo_atualizacao': 0,
                'nome': 'VHSYS', 
                'email': 'automacao.teste@vhsys.com.br', 
                'celular': '(41) 99813-8194', 
                'expira_em': '2020-06-29 15:48:03', 
                'data_cad_contato': '2020-04-29 18:48:03'
            }
        ]
