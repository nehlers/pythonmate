from peewee import *
from .BaseModel import BaseModel


class nfe_logins_block(BaseModel):
    id_block = IntegerField(primary_key=True)  #bigint
    ip_block = CharField()  #varchar
    hostname = CharField()  #varchar
    observacao = CharField()  #varchar
    data_block = DateTimeField()  #datetime
