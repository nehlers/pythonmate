import os
from dotenv import load_dotenv
from peewee import *


load_dotenv()

db = MySQLDatabase(os.getenv('DB_NAME'), 
        user=os.getenv('DB_USER'), 
        password=os.getenv('DB_PASS'), 
        host=os.getenv('DB_HOST'), 
        port=int(os.getenv('DB_PORT')))

def make_table_name(model_class):
    model_name = model_class.__name__
    return model_name

class BaseModel(Model):
    
    @classmethod
    def inserir_dados_iniciais(cls, id_empresa, id_usuario):
        try:            
            if hasattr(cls, 'id_empresa') or (cls.select().count() == 0):
                cls.insert_many(cls.dados_iniciais(id_empresa, id_usuario)).execute()
        except IntegrityError as integrytyEx:
            print("{} {}".format(cls.__name__, integrytyEx))
        except Exception as ex:
            raise Exception("{} {}".format(cls.__name__, ex))
        
    @classmethod
    def apagar_dados_empresa(cls, id_empresa):
        if hasattr(cls, 'id_empresa'):
            cls.delete().where(cls.id_empresa == id_empresa).execute()
        
    @classmethod
    def dados_iniciais(cls, id_empresa, id_usuario):
        return []

    class Meta:        
        table_function = make_table_name                
        database = db
        