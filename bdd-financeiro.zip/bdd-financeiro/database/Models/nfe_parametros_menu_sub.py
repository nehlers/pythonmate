from peewee import *
from .BaseModel import BaseModel


class nfe_parametros_menu_sub(BaseModel):
    id_parametro_submenu = IntegerField(primary_key=True)  #int
    id_parametro_menu = IntegerField()  #int
    desc_submenu_parametro = CharField()  #varchar
    atalho_submenu_parametro = CharField()  #varchar
    status_submenu_parametro = CharField()  #enum
    ordenacao_submenu_parametro = IntegerField()  #int

    @classmethod
    def dados_iniciais(cls, id_empresa, id_usuario):
        return [            
            {
                'id_parametro_submenu': 1,
                'id_parametro_menu': 1,
                'desc_submenu_parametro': 'Mensagens por e-mail',
                'atalho_submenu_parametro': 'mensagens-email',
                'status_submenu_parametro': 'Ativo',
                'ordenacao_submenu_parametro': 1,
            },            
            {
                'id_parametro_submenu': 2,
                'id_parametro_menu': 1,
                'desc_submenu_parametro': 'SMTP Próprio',
                'atalho_submenu_parametro': 'smtp',
                'status_submenu_parametro': 'Ativo',
                'ordenacao_submenu_parametro': 2,
            },            
            {
                'id_parametro_submenu': 3,
                'id_parametro_menu': 1,
                'desc_submenu_parametro': 'Autocomplete',
                'atalho_submenu_parametro': 'autocomplete',
                'status_submenu_parametro': 'Ativo',
                'ordenacao_submenu_parametro': 3,
            },            
            {
                'id_parametro_submenu': 4,
                'id_parametro_menu': 4,
                'desc_submenu_parametro': 'Nota Fiscal',
                'atalho_submenu_parametro': 'nota-fiscal',
                'status_submenu_parametro': 'Ativo',
                'ordenacao_submenu_parametro': 1,
            },            
            {
                'id_parametro_submenu': 5,
                'id_parametro_menu': 4,
                'desc_submenu_parametro': 'Nota Fiscal Consumidor',
                'atalho_submenu_parametro': 'nota-fiscal-consumidor',
                'status_submenu_parametro': 'Ativo',
                'ordenacao_submenu_parametro': 2,
            },            
            {
                'id_parametro_submenu': 6,
                'id_parametro_menu': 4,
                'desc_submenu_parametro': 'Mensagens Nota Fiscal',
                'atalho_submenu_parametro': 'mensagens-nf',
                'status_submenu_parametro': 'Ativo',
                'ordenacao_submenu_parametro': 3,
            },            
            {
                'id_parametro_submenu': 7,
                'id_parametro_menu': 6,
                'desc_submenu_parametro': 'Nota Fiscal de Serviço',
                'atalho_submenu_parametro': 'nota-fiscal-servico',
                'status_submenu_parametro': 'Ativo',
                'ordenacao_submenu_parametro': 1,
            }
        ]
        