from peewee import *
from .BaseModel import BaseModel


class nfe_config_widgets(BaseModel):
    id_widget = IntegerField(primary_key=True)  #int
    nome_widget = CharField()  #varchar
    imagem_widget = CharField()  #varchar
    descricao_widget = CharField()  #text
    trigger_widget = CharField()  #varchar
    categoria_widget = CharField()  #varchar
    lixeira = CharField()  #enum

    @classmethod
    def dados_iniciais(cls, id_empresa, id_usuario):
        return [
            {
                'id_widget': 1,
                'nome_widget': 'Agendaasd',
                'imagem_widget': 'agenda.jpg',
                'descricao_widget': 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sem dui, iaculis sit amet massa non.',
                'trigger_widget': 'Layer_Agenda',
                'categoria_widget': 'Aplicativos',
                'lixeira': 'Nao',
            },
            {
                'id_widget': 2,
                'nome_widget': 'Contas a receber',
                'imagem_widget': 'contas-receber.jpg',
                'descricao_widget': 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sem dui, iaculis sit amet massa non.',
                'trigger_widget': 'Layer_ContasRec',
                'categoria_widget': 'Principais',
                'lixeira': 'Nao',
            },
            {
                'id_widget': 4,
                'nome_widget': 'Faturamento mensal',
                'imagem_widget': 'faturamento.jpg',
                'descricao_widget': 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sem dui, iaculis sit amet massa non.',
                'trigger_widget': 'Layer_Faturamento',
                'categoria_widget': 'Principais',
                'lixeira': 'Nao',
            },
            {
                'id_widget': 5,
                'nome_widget': 'Saldo atual das contas',
                'imagem_widget': 'saldo-atual.jpg',
                'descricao_widget': 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sem dui, iaculis sit amet massa non.',
                'trigger_widget': 'Layer_Saldo_Contas',
                'categoria_widget': 'Principais',
                'lixeira': 'Nao',
            },
            {
                'id_widget': 6,
                'nome_widget': 'Avisos internos',
                'imagem_widget': 'avisos.jpg',
                'descricao_widget': 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sem dui, iaculis sit amet massa non.',
                'trigger_widget': 'Layer_Avisos',
                'categoria_widget': 'Aplicativos',
                'lixeira': 'Nao',
            },
            {
                'id_widget': 7,
                'nome_widget': 'Resultados diários',
                'imagem_widget': 'resultados.jpg',
                'descricao_widget': 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sem dui, iaculis sit amet massa non.',
                'trigger_widget': 'Layer_Resultados',
                'categoria_widget': 'Principais',
                'lixeira': 'Nao',
            },
            {
                'id_widget': 8,
                'nome_widget': 'Demonstrativo do mês',
                'imagem_widget': 'demonstrativo.jpg',
                'descricao_widget': 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sem dui, iaculis sit amet massa non.',
                'trigger_widget': 'Layer_Demonstrativo',
                'categoria_widget': 'Principais',
                'lixeira': 'Nao',
            },
            {
                'id_widget': 9,
                'nome_widget': 'Contas a pagar',
                'imagem_widget': 'contas-pagar.jpg',
                'descricao_widget': 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sem dui, iaculis sit amet massa non.',
                'trigger_widget': 'Layer_ContasPag',
                'categoria_widget': 'Principais',
                'lixeira': 'Nao',
            },
            {
                'id_widget': 11,
                'nome_widget': 'Acesso Rápido',
                'imagem_widget': 'acesso-rapido.jpg',
                'descricao_widget': 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sem dui, iaculis sit amet massa non.',
                'trigger_widget': 'Layer_Links',
                'categoria_widget': 'Principais',
                'lixeira': 'Nao',
            },
            {
                'id_widget': 12,
                'nome_widget': 'Últimos Chamados',
                'imagem_widget': 'acesso-rapido.jpg',
                'descricao_widget': 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sem dui, iaculis sit amet massa non.',
                'trigger_widget': 'Layer_UltimosChamados',
                'categoria_widget': 'Principais',
                'lixeira': 'Nao',
            },
            {
                'id_widget': 13,
                'nome_widget': 'Lançamento Rápido',
                'imagem_widget': 'acesso-rapido.jpg',
                'descricao_widget': 'TESTESTESTESTESTESTSTS',
                'trigger_widget': 'Layer_Lancamento',
                'categoria_widget': 'Principais',
                'lixeira': 'Nao',
            }
        ]