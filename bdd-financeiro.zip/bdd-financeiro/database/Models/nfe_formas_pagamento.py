from peewee import *
from .BaseModel import BaseModel


class nfe_formas_pagamento(BaseModel):
    id_forma = IntegerField(primary_key=True)  #int
    desc_forma = CharField()  #varchar
    frente_caixa = IntegerField()  #tinyint

    @classmethod
    def dados_iniciais(cls, id_empresa, id_usuario):
        return [
            {
                'id_forma': 1,
                'desc_forma': 'Dinheiro',
                'frente_caixa': 1,
            },
            {
                'id_forma': 2,
                'desc_forma': 'Cheque',
                'frente_caixa': 1,
            },
            {
                'id_forma': 3,
                'desc_forma': 'Permuta',
                'frente_caixa': 0,
            },
            {
                'id_forma': 4,
                'desc_forma': 'Cartão de Crédito',
                'frente_caixa': 1,
            },
            {
                'id_forma': 5,
                'desc_forma': 'Cartão de Débito',
                'frente_caixa': 1,
            },
            {
                'id_forma': 6,
                'desc_forma': 'Boleto',
                'frente_caixa': 0,
            },
            {
                'id_forma': 7,
                'desc_forma': 'Transferência',
                'frente_caixa': 0,
            },
            {
                'id_forma': 8,
                'desc_forma': 'Doc',
                'frente_caixa': 0,
            },
            {
                'id_forma': 9,
                'desc_forma': 'Ted',
                'frente_caixa': 0,
            },
            {
                'id_forma': 10,
                'desc_forma': 'Depósito Identificado',
                'frente_caixa': 0,
            },
            {
                'id_forma': 11,
                'desc_forma': 'Depósito em C/C',
                'frente_caixa': 0,
            },
            {
                'id_forma': 12,
                'desc_forma': 'Duplicata Mercantil',
                'frente_caixa': 0,
            },
            {
                'id_forma': 13,
                'desc_forma': 'Faturado',
                'frente_caixa': 0,
            },
            {
                'id_forma': 14,
                'desc_forma': 'Faturar',
                'frente_caixa': 1,
            },
            {
                'id_forma': 15,
                'desc_forma': 'Débito Automático',
                'frente_caixa': 0,
            },
            {
                'id_forma': 16,
                'desc_forma': 'Lotérica',
                'frente_caixa': 0,
            },
            {
                'id_forma': 17,
                'desc_forma': 'Banco',
                'frente_caixa': 0,
            },
            {
                'id_forma': 18,
                'desc_forma': 'DDA',
                'frente_caixa': 0,
            },
            {
                'id_forma': 19,
                'desc_forma': 'Pagamento online',
                'frente_caixa': 0,
            },
            {
                'id_forma': 20,
                'desc_forma': 'BNDES',
                'frente_caixa': 0,
            },
            {
                'id_forma': 21,
                'desc_forma': 'Outros',
                'frente_caixa': 0,
            },
            {
                'id_forma': 22,
                'desc_forma': 'DP Descontada',
                'frente_caixa': 0,
            },
            {
                'id_forma': 23,
                'desc_forma': 'CH Descontado',
                'frente_caixa': 0,
            },
            {
                'id_forma': 24,
                'desc_forma': 'Vale Alimentação',
                'frente_caixa': 1,
            },
            {
                'id_forma': 25,
                'desc_forma': 'Vale Refeição',
                'frente_caixa': 1,
            },
            {
                'id_forma': 26,
                'desc_forma': 'Vale Presente',
                'frente_caixa': 1,
            },
            {
                'id_forma': 27,
                'desc_forma': 'Vale Combustível',
                'frente_caixa': 1,
            },
            {
                'id_forma': 28,
                'desc_forma': 'Crédito loja',
                'frente_caixa': 1,
            }
        ]