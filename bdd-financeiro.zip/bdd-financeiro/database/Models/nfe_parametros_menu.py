from peewee import *
from .BaseModel import BaseModel


class nfe_parametros_menu(BaseModel):
    id_parametro_menu = IntegerField(primary_key=True)  #int
    desc_parametro = CharField()  #varchar
    atalho_parametro = CharField()  #varchar
    status_parametro = CharField()  #enum
    ordenacao_parametro = IntegerField()  #int

    @classmethod
    def dados_iniciais(cls, id_empresa, id_usuario):
        return [
            {
                'id_parametro_menu': 1,
                'desc_parametro': 'Gerais',
                'atalho_parametro': 'gerais',
                'status_parametro': 'Ativo',
                'ordenacao_parametro': 1,
            },
            {
                'id_parametro_menu': 2,
                'desc_parametro': 'Cadastros',
                'atalho_parametro': 'cadastros',
                'status_parametro': 'Ativo',
                'ordenacao_parametro': 2,
            },
            {
                'id_parametro_menu': 3,
                'desc_parametro': 'Financeiro',
                'atalho_parametro': 'financeiro',
                'status_parametro': 'Ativo',
                'ordenacao_parametro': 3,
            },
            {
                'id_parametro_menu': 4,
                'desc_parametro': 'Vendas',
                'atalho_parametro': 'vendas',
                'status_parametro': 'Ativo',
                'ordenacao_parametro': 5,
            },
            {
                'id_parametro_menu': 5,
                'desc_parametro': 'Compras',
                'atalho_parametro': 'compras',
                'status_parametro': 'Ativo',
                'ordenacao_parametro': 6,
            },
            {
                'id_parametro_menu': 6,
                'desc_parametro': 'Serviços',
                'atalho_parametro': 'servicos',
                'status_parametro': 'Ativo',
                'ordenacao_parametro': 7,
            },
            {
                'id_parametro_menu': 7,
                'desc_parametro': 'Transportes',
                'atalho_parametro': 'transportes',
                'status_parametro': 'Ativo',
                'ordenacao_parametro': 8,
            },
            {
                'id_parametro_menu': 8,
                'desc_parametro': 'Estoque',
                'atalho_parametro': 'estoque',
                'status_parametro': 'Ativo',
                'ordenacao_parametro': 4,
            }
        ]