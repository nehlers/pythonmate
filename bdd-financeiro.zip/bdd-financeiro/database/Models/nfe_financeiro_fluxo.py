from peewee import *
from .BaseModel import BaseModel


class nfe_financeiro_fluxo(BaseModel):
    id_fluxo = IntegerField(primary_key=True)  #bigint
    id_empresa = IntegerField()  #bigint
    id_banco = IntegerField()  #bigint
    id_conta = IntegerField()  #bigint
    id_recebimento = IntegerField()  #int
    nome_conta = CharField()  #char
    id_cliente = IntegerField()  #bigint
    nome_cliente = CharField()  #varchar
    data_fluxo = DateTimeField()  #date
    valor_fluxo = DecimalField()  #decimal
    observacoes_fluxo = CharField()  #longtext
    id_centro_custos = IntegerField()  #bigint
    centro_custos_fluxo = CharField()  #char
    id_categoria = IntegerField()  #int
    categoria_fluxo = CharField()  #char
    forma_pagamento = CharField()  #char
    tipo_fluxo = CharField()  #enum
    data_cad_fluxo = DateTimeField()  #datetime
    data_mod_fluxo = DateTimeField()  #datetime
    lixeira = CharField()  #enum
    lixeira_location = CharField()  #char
    id_transferencia = IntegerField()  #bigint
