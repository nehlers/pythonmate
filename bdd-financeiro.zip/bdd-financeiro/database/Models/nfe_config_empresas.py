from peewee import *
from .BaseModel import BaseModel


class nfe_config_empresas(BaseModel):
    id_empresa = IntegerField(primary_key=True)  #int
    id_parceiro = IntegerField()  #smallint
    id_contabilidade = IntegerField()  #smallint
    id_academico = IntegerField()  #smallint
    tipo_pessoa = CharField()  #enum
    certificado_tipo = CharField()  #enum
    tipo_faturamento = CharField()  #enum
    cnpj_empresa = CharField()  #char
    razao_empresa = CharField()  #varchar
    fantasia_empresa = CharField()  #varchar
    endereco_empresa = CharField()  #varchar
    numero_empresa = CharField()  #char
    bairro_empresa = CharField()  #char
    complemento_empresa = CharField()  #char
    cep_empresa = CharField()  #char
    cidade_empresa = CharField()  #varchar
    cidade_empresa_cod = IntegerField()  #int
    uf_empresa = CharField()  #char
    fone_empresa = CharField()  #char
    celular_empresa = CharField()  #char
    email_empresa = CharField()  #varchar
    email_empresa_nota = CharField()  #varchar
    email_empresa_cte = CharField()  #varchar
    website_empresa = CharField()  #varchar
    insc_estadual_empresa = CharField()  #char
    insc_municipal_empresa = CharField()  #char
    cnae_empresa = CharField()  #char
    observacoes_empresa = CharField()  #longtext
    regime_empresa = IntegerField()  #tinyint
    contabilidade_cnpj = CharField()  #char
    contabilidade_cpf = CharField()  #varchar
    contabilidade_crc = CharField()  #varchar
    contabilidade_cep = CharField()  #varchar
    contabilidade_endereco = CharField()  #varchar
    contabilidade_endereco_numero = CharField()  #varchar
    contabilidade_bairro = CharField()  #varchar
    contabilidade_complemento = CharField()  #varchar
    contabilidade_cidade = CharField()  #varchar
    contabilidade_cidade_cod = IntegerField()  #int
    contabilidade_uf = CharField()  #varchar
    contabilidade_responsavel = CharField()  #varchar
    contabilidade_email = CharField()  #varchar
    contabilidade_telefone = CharField()  #char
    contabilidade_sefaz = IntegerField()  #tinyint
    responsavel_empresa = CharField()  #varchar
    responsavel_celular = CharField()  #char
    logo_empresa = CharField()  #char
    certificado_empresa = CharField()  #char
    certificado_senha_empresa = CharField()  #varchar
    certificado_expiracao = DateTimeField()  #date
    certificado_instalado = IntegerField()  #tinyint
    serie_nota = IntegerField()  #int
    serie_nfse = CharField()  #char
    serie_nfce = IntegerField()  #int
    serie_cte = IntegerField()  #int
    serie_mdfe = IntegerField()  #int
    bloqueado = IntegerField()  #tinyint
    bloqueado_desc = CharField()  #longtext
    bloqueado_data = DateTimeField()  #datetime
    bloqueado_fatura = IntegerField()  #bigint
    gerar_faturas = IntegerField()  #tinyint
    gerar_nfs = IntegerField()  #tinyint
    faturas_todos = IntegerField()  #tinyint
    dia_vencimento = IntegerField()  #tinyint
    nota_webservice = DecimalField()  #decimal
    nota_limite = IntegerField()  #int
    nota_ambiente = IntegerField()  #tinyint
    cte_ambiente = IntegerField()  #tinyint
    usuarios_limite = IntegerField()  #int
    alterar_cnpj = IntegerField()  #tinyint
    modulo_nfe = IntegerField()  #tinyint
    modulo_nfse = IntegerField()  #tinyint
    modulo_nfse_exportar = IntegerField()  #tinyint
    modulo_pdv = IntegerField()  #tinyint
    modulo_cte = IntegerField()  #tinyint
    modulo_loja = IntegerField()  #tinyint
    modulo_boleto = IntegerField()  #tinyint
    boleto_usuario = CharField()  #char
    boleto_senha = CharField()  #char
    boleto_padrao = IntegerField()  #tinyint
    creditos_empresa = DecimalField()  #decimal
    espaco_empresa = IntegerField()  #bigint
    espaco_consumido = IntegerField()  #bigint
    termos_uso = IntegerField()  #tinyint
    termos_data = DateTimeField()  #datetime
    termos_usuario = CharField()  #char
    white_label = IntegerField()  #tinyint
    cliente_stone = IntegerField()  #tinyint
    prospecto = IntegerField()  #tinyint
    freemium = IntegerField()  #tinyint
    prospecto_expiracao = DateTimeField()  #date
    prospecto_degustacao = DateTimeField()  #date
    prospecto_ativado = DateTimeField()  #datetime
    prospecto_cupom = CharField()  #char
    prospecto_origem = CharField()  #varchar
    prospecto_situacao = CharField()  #char
    prospecto_prioridade = IntegerField()  #tinyint
    prospecto_repasse = IntegerField()  #tinyint
    boasvindas = IntegerField()  #tinyint
    intro_boasvindas = IntegerField()  #tinyint
    intro_lojaapps = IntegerField()  #tinyint
    intro_meusapps = IntegerField()  #tinyint
    intro_pagante = IntegerField()  #tinyint
    intro_primeiroAcesso = IntegerField()  #tinyint
    dre_configurado = IntegerField()  #tinyint
    suporte_plus = IntegerField()  #tinyint
    publicidade = IntegerField()  #tinyint
    visivel_marketplace = IntegerField()  #tinyint
    receber_spam = IntegerField()  #tinyint
    limite_email_marketing = IntegerField()  #int
    limite_sms = IntegerField()  #int
    limite_consulta_serasa = IntegerField()  #int
    data_cad_empresa = DateTimeField()  #timestamp
    data_mod_empresa = DateTimeField()  #datetime
    lixeira = CharField()  #enum
    rntrc_empresa = CharField()  #varchar
    ocultar_sped_fiscal = IntegerField()  #tinyint

    @classmethod
    def dados_iniciais(cls, id_empresa, id_usuario):
        return [
            {
                'id_empresa': id_empresa,
                'id_parceiro': 0,
                'id_contabilidade': 292,
                'id_academico': 0,
                'tipo_pessoa': 'PF',
                'certificado_tipo': 'A1',
                'tipo_faturamento': 'Boleto',
                'cnpj_empresa': '12.702.717/0001-64',
                'razao_empresa': 'VHSYS SISTEMA DE GESTÃO S.A.',
                'fantasia_empresa': 'Acha fácil VHSYS',
                'endereco_empresa': 'RUA TENENTE DJALMA DUTRA',
                'numero_empresa': '915',
                'bairro_empresa': 'CENTRO',
                'complemento_empresa': 'Casa',
                'cep_empresa': '83.005-360',
                'cidade_empresa': 'São José dos Pinhais',
                'cidade_empresa_cod': 4125506,
                'uf_empresa': 'PR',
                'fone_empresa': '(49) 9999-95747',
                'celular_empresa': '(41) 99978-4744',
                'email_empresa': 'r.bugai@vhsys.com.br',
                'email_empresa_nota': '',
                'email_empresa_cte': '',
                'website_empresa': 'www.vhsys.com.br',
                'insc_estadual_empresa': '9053663785',
                'insc_municipal_empresa': '53856',
                'cnae_empresa': '6319400',
                'observacoes_empresa': '',
                'regime_empresa': 3,
                'contabilidade_cnpj': '',
                'contabilidade_cpf': None,
                'contabilidade_crc': None,
                'contabilidade_cep': None,
                'contabilidade_endereco': None,
                'contabilidade_endereco_numero': None,
                'contabilidade_bairro': None,
                'contabilidade_complemento': None,
                'contabilidade_cidade': None,
                'contabilidade_cidade_cod': None,
                'contabilidade_uf': None,
                'contabilidade_responsavel': 'VHSYS',
                'contabilidade_email': '',
                'contabilidade_telefone': '(41) 3035-7775',
                'contabilidade_sefaz': 1,
                'responsavel_empresa': 'Luan',
                'responsavel_celular': '',
                'logo_empresa': '1d9adec3788d7444ab75d38a884c1e3ff.jpg',
                'certificado_empresa': '1f3cb86814b96605b71595cebc3e87139.pfx',
                'certificado_senha_empresa': '=AgBQRXVLtkzQR3U',
                'certificado_expiracao': '2050-05-21',
                'certificado_instalado': 1,
                'serie_nota': 2,
                'serie_nfse': '708',
                'serie_nfce': 0,
                'serie_cte': 0,
                'serie_mdfe': 1,
                'bloqueado': 0,
                'bloqueado_desc': '',
                'bloqueado_data': '0000-00-00 00:00:00',
                'bloqueado_fatura': 0,
                'gerar_faturas': 1,
                'gerar_nfs': 0,
                'faturas_todos': 1,
                'dia_vencimento': 10,
                'nota_webservice': '0.00',
                'nota_limite': 0,
                'nota_ambiente': 2,
                'cte_ambiente': 1,
                'usuarios_limite': 14,
                'alterar_cnpj': 1,
                'modulo_nfe': 1,
                'modulo_nfse': 1,
                'modulo_nfse_exportar': 1,
                'modulo_pdv': 1,
                'modulo_cte': 1,
                'modulo_loja': 1,
                'modulo_boleto': 1,
                'boleto_usuario': 'vhsys',
                'boleto_senha': '==AACQDMyAjdvkcLJ9syOxiros8K',
                'boleto_padrao': 1,
                'creditos_empresa': '13993.53',
                'espaco_empresa': 107374182400,
                'espaco_consumido': 222691226,
                'termos_uso': 1,
                'termos_data': '2013-03-11 11:47:31',
                'termos_usuario': 'visualhost',
                'white_label': 0,
                'cliente_stone': 0,
                'prospecto': 0,
                'freemium': 0,
                'prospecto_expiracao': '0000-00-00',
                'prospecto_degustacao': '2017-11-08',
                'prospecto_ativado': '2018-12-21 00:00:00',
                'prospecto_cupom': '',
                'prospecto_origem': 'REATIVADO: REATIVADO: REATIVADO: http://www.vhsys.com.br',
                'prospecto_situacao': 'Fechado',
                'prospecto_prioridade': 0,
                'prospecto_repasse': 0,
                'boasvindas': 0,
                'intro_boasvindas': 1,
                'intro_lojaapps': 1,
                'intro_meusapps': 1,
                'intro_pagante': 0,
                'intro_primeiroAcesso': 0,
                'dre_configurado': 1,
                'suporte_plus': 0,
                'publicidade': 1,
                'visivel_marketplace': 0,
                'receber_spam': 1,
                'limite_email_marketing': 500,
                'limite_sms': 1000,
                'limite_consulta_serasa': 1000,
                'data_cad_empresa': '2011-05-24 17:39:51',
                'data_mod_empresa': '2019-06-14 10:53:09',
                'lixeira': 'Nao',
                'rntrc_empresa': None,
                'ocultar_sped_fiscal': 1,
                }
        ]