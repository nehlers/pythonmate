from peewee import *
from .BaseModel import BaseModel


class nfe_config_empresas_parametros(BaseModel):
    id_parametro = IntegerField(primary_key=True)  #int
    id_empresa = IntegerField()  #int
    cst_icms = CharField()  #char
    modalidade_icms = IntegerField()  #tinyint
    pICMS_icms = DecimalField()  #decimal
    ICMS_automatico = IntegerField()  #tinyint
    pRedBC_icms = DecimalField()  #decimal
    motDesICMS_icms = IntegerField()  #tinyint
    pCredSN_icms = DecimalField()  #decimal
    pFCP_icms = DecimalField()  #decimal
    pFCPST_icms = DecimalField()  #decimal
    pFCPSTRet_icms = DecimalField()  #decimal
    pDif_icms = DecimalField()  #decimal
    cst_ipi = CharField()  #char
    classe_enquadramento = CharField()  #char
    cEnq_enquadramento = CharField()  #char
    pIPI_ipi = DecimalField()  #decimal
    cst_pis = CharField()  #char
    pPIS_pis = DecimalField()  #decimal
    cst_cofins = CharField()  #char
    pCOFINS_cofins = DecimalField()  #decimal
    modalidade_st = IntegerField()  #tinyint
    pMVAST_st = DecimalField()  #decimal
    pRedBCST_st = DecimalField()  #decimal
    pICMSST_st = DecimalField()  #decimal
    pPIS_st = DecimalField()  #decimal
    pCOFINS_st = DecimalField()  #decimal
    cfop_vendadentro = IntegerField()  #int
    cfop_vendafora = IntegerField()  #int
    cfop_entrada = IntegerField()  #int
    cfop_importacao = IntegerField()  #int
    cfop_exportacao = IntegerField()  #int
    cfop_venda_st_dentro = IntegerField()  #int
    cfop_venda_st_fora = IntegerField()  #int
    cfop_nfce = IntegerField()  #int
    cfop_nfce_st = IntegerField()  #int
    grupo_nf_medicamento = IntegerField()  #tinyint
    grupo_nf_arma = IntegerField()  #tinyint
    grupo_nf_combustivel = IntegerField()  #tinyint
    desconto_condicionado = IntegerField()  #tinyint
    indPres_nf = IntegerField()  #tinyint
    nota_conjugada = IntegerField()  #tinyint
    nota_xml_email = IntegerField()  #tinyint
    cte_xml_email = IntegerField()  #tinyint
    mdfe_xml_email = IntegerField()  #tinyint
    nota_ultimo_nsu = IntegerField()  #int
    nota_cad_fornecedores = IntegerField()  #tinyint
    nota_cad_produtos = IntegerField()  #tinyint
    nota_cad_transportadoras = IntegerField()  #tinyint
    bc_icms_ipi = IntegerField()  #tinyint
    bc_icms_frete = IntegerField()  #tinyint
    bc_icms_seguro = IntegerField()  #tinyint
    bc_icms_outros = IntegerField()  #tinyint
    bc_icms_desconto = IntegerField()  #tinyint
    bc_ipi_frete = IntegerField()  #tinyint
    bc_ipi_seguro = IntegerField()  #tinyint
    bc_pis_frete = IntegerField()  #tinyint
    bc_pis_outros = IntegerField()  #tinyint
    bc_pis_desconto = IntegerField()  #tinyint
    bc_cofins_frete = IntegerField()  #tinyint
    bc_cofins_outros = IntegerField()  #tinyint
    bc_cofins_desconto = IntegerField()  #tinyint
    nfce_cst_icms = CharField()  #char
    nfce_modalidade_icms = IntegerField()  #tinyint
    nfce_pRedBC_icms = DecimalField()  #decimal
    nfce_motDesICMS_icms = IntegerField()  #tinyint
    nfce_cst_pis = CharField()  #char
    nfce_pPIS_pis = DecimalField()  #decimal
    nfce_cst_cofins = CharField()  #char
    nfce_pCOFINS_cofins = DecimalField()  #decimal
    nfce_indPres_nf = IntegerField()  #tinyint
    nfce_bc_icms_frete = IntegerField()  #tinyint
    nfce_bc_icms_outros = IntegerField()  #tinyint
    nfce_bc_icms_desconto = IntegerField()  #tinyint
    nfce_bc_pis_frete = IntegerField()  #tinyint
    nfce_bc_pis_outros = IntegerField()  #tinyint
    nfce_bc_pis_desconto = IntegerField()  #tinyint
    nfce_bc_cofins_frete = IntegerField()  #tinyint
    nfce_bc_cofins_outros = IntegerField()  #tinyint
    nfce_bc_cofins_desconto = IntegerField()  #tinyint
    nfce_token = CharField()  #char
    nfce_token_id = IntegerField()  #int
    nfce_layout = CharField()  #char
    nfce_observacoes = IntegerField()  #tinyint
    nfce_grupo_combustivel = IntegerField()  #tinyint
    nfse_natureza_pedido = CharField()  #char
    nfse_regime_pedido = IntegerField()  #tinyint
    nfse_regime_especial = IntegerField()  #tinyint
    nfse_valor_aliquota = DecimalField()  #decimal
    nfse_valor_aliquota_iss_sn_ip = DecimalField()  #decimal
    nfse_itemLista_servico = IntegerField()  #smallint
    nfse_aliq_cofins = DecimalField()  #decimal
    nfse_aliq_pis = DecimalField()  #decimal
    nfse_aliq_contribuicao = DecimalField()  #decimal
    nfse_aliq_ir = DecimalField()  #decimal
    nfse_aliq_iss = DecimalField()  #decimal
    nfse_reter_cofins = IntegerField()  #tinyint
    nfse_reter_pis = IntegerField()  #tinyint
    nfse_reter_csll = IntegerField()  #tinyint
    nfse_reter_ir = IntegerField()  #tinyint
    nfse_reter_inss = IntegerField()  #tinyint
    nfse_autenticacao_login = CharField()  #char
    nfse_autenticacao_senha = CharField()  #char
    pdv_estoque = IntegerField()  #tinyint
    pdv_contas = IntegerField()  #tinyint
    pdv_contas_dias = IntegerField()  #tinyint
    pdv_contas_dias_debito = IntegerField()  #tinyint
    pdv_comissao = IntegerField()  #tinyint
    pdv_desconto = DecimalField()  #decimal
    pdv_acrescimo = DecimalField()  #decimal
    pdv_valebrinde = DecimalField()  #decimal
    pdv_alterarpreco = IntegerField()  #tinyint
    pdv_emitirnfc = IntegerField()  #tinyint
    pdv_alteraroperador = IntegerField()  #tinyint
    pdv_listapreco = IntegerField()  #int
    pdv_cupom_topo = CharField()  #varchar
    pdv_cupom_rodape = CharField()  #varchar
    pdv_cupom_layout = CharField()  #char
    pdv_evo_default_terminal = CharField()  #char
    pdv_evoluservices = IntegerField()  #int
    bal_digitos_iniciais = IntegerField()  #int
    bal_tamanho_codigo = IntegerField()  #int
    bal_id_cod_prod_inicio = IntegerField()  #int
    bal_id_cod_prod_fim = IntegerField()  #int
    bal_id_valor_inicio = IntegerField()  #int
    bal_id_valor_fim = IntegerField()  #int
    bal_casas_decimais = IntegerField()  #int
    msg_orcamento = CharField()  #text
    pdf_orcamento = IntegerField()  #tinyint
    msg_pedido = CharField()  #text
    pdf_pedido = IntegerField()  #tinyint
    msg_notafiscal = CharField()  #text
    msg_ordemservico = CharField()  #text
    pdf_ordemservico = IntegerField()  #tinyint
    msg_ordemservico_termos = CharField()  #text
    msg_notaservico = CharField()  #text
    msg_ordemcompra = CharField()  #text
    pdf_ordemcompra = IntegerField()  #tinyint
    msg_boleto = CharField()  #text
    msg_envio_conta_bancaria = CharField()  #text
    geral_estoque = IntegerField()  #tinyint
    geral_estoqueminimo = IntegerField()  #tinyint
    geral_bloquearestoque = IntegerField()  #tinyint
    geral_bloquearagrupamento = IntegerField()  #tinyint
    geral_casas = IntegerField()  #tinyint
    geral_ocultarmenu = IntegerField()  #tinyint
    geral_vendedores = IntegerField()  #tinyint
    geral_comissionamento = IntegerField()  #tinyint
    geral_limitepag = IntegerField()  #tinyint
    geral_limiteautocomplete = IntegerField()  #tinyint
    geral_tipo_busca_autocomplete = IntegerField()  #tinyint
    geral_exibir_unidade_autocomplete = IntegerField()  #tinyint
    geral_exibir_estoque_autocomplete = IntegerField()  #tinyint
    geral_listapreco = IntegerField()  #tinyint
    geral_dia_util = IntegerField()  #tinyint
    geral_desconsidera = IntegerField()  #tinyint
    geral_dados_pedido = IntegerField()  #tinyint
    geral_dados_pedido_nf = IntegerField()  #tinyint
    geral_dados_gtin_nf = IntegerField()  #tinyint
    geral_dados_os = IntegerField()  #tinyint
    geral_data_lancarestoque = IntegerField()  #tinyint
    geral_impressao_capa_produto = IntegerField()  #tinyint
    geral_impressao_capa_produto_tamanho = IntegerField()  #int
    geral_impressao_capa_orcamento = IntegerField()  #tinyint
    geral_categoria_receita_id = IntegerField()  #int
    geral_categoria_receita = CharField()  #char
    geral_categoria_despesa_id = IntegerField()  #int
    geral_categoria_despesa = CharField()  #char
    geral_categoria_vendas_id = IntegerField()  #int
    geral_categoria_vendas = CharField()  #char
    geral_categoria_servicos_id = IntegerField()  #int
    geral_categoria_servicos = CharField()  #char
    geral_categoria_compras_id = IntegerField()  #int
    geral_categoria_compras = CharField()  #char
    geral_categoria_padrao_dre = IntegerField()  #tinyint
    geral_centro_receitas = CharField()  #char
    geral_centro_receitas_id = IntegerField()  #int
    geral_centro_despesas = CharField()  #char
    geral_centro_despesas_id = IntegerField()  #int
    geral_centro_vendas = CharField()  #char
    geral_centro_vendas_id = IntegerField()  #int
    geral_centro_servicos = CharField()  #char
    geral_centro_servicos_id = IntegerField()  #int
    geral_centro_compras = CharField()  #char
    geral_centro_compras_id = IntegerField()  #int
    geral_smtp_host = CharField()  #char
    geral_smtp_email = CharField()  #char
    geral_smtp_senha = CharField()  #char
    geral_smtp_porta = CharField()  #char
    geral_smtp_cript = CharField()  #char
    geral_cnpj_duplicado = IntegerField()  #tinyint
    geral_atualizar_custo = IntegerField()  #tinyint
    dashboard_faturamento_tipo = IntegerField()  #tinyint
    dashboard_faturamento_cfop = CharField()  #varchar
    dashboard_faturamento_status = CharField()  #char
    dashboard_faturamento_regra = IntegerField()  #tinyint
    dashboard_contaspag_status = CharField()  #char
    dashboard_contaspag_periodo = CharField()  #char
    dashboard_contasrec_status = CharField()  #char
    dashboard_contasrec_periodo = CharField()  #char
    ord_contaspag = CharField()  #char
    ord_contasrec = CharField()  #char
    foto_lista_produto = IntegerField()  #tinyint
    replica_valores = IntegerField()  #tinyint
    data_mod_parametros = DateTimeField()  #datetime
    usuario_mod_parametros = IntegerField()  #int
    nfce_integracao_pagamento = IntegerField()  #smallint
    nfce_token_homolog = CharField()  #char
    nfce_token_homolog_id = IntegerField()  #int
    pdv_categoria_receita = CharField()  #varchar
    pdv_categoria_receita_id = IntegerField()  #int
    pdv_categoria_despesa = CharField()  #varchar
    pdv_categoria_despesa_id = IntegerField()  #int
    gerar_boleto = IntegerField()  #smallint
    pdv_parametrizar_boleto = IntegerField()  #tinyint
    xml_entradas_receita_aguardando = CharField()  #longtext
    ultima_verificacao_xml_entrada_receita = DateTimeField()  #datetime
    grupo_nf_veiculos = IntegerField()  #tinyint
    nota_scan_manual = CharField()  #enum
    cte_scan_manual = CharField()  #enum
    mdfe_scan_manual = CharField()  #enum
    orientacao_logo_nf = CharField()  #enum
    pdv_tipo_acrescimo = CharField()  #enum
    pdv_tipo_desconto = CharField()  #enum
    pdv_cupom_impressao = CharField()  #enum
    pdv_impressao_item = CharField()  #enum
    pdv_impressao_codigo = CharField()  #enum
    pdv_impressao_desc = CharField()  #enum
    pdv_impressao_valor = CharField()  #enum
    pdv_impressao_qtde = CharField()  #enum
    pdv_caixa = CharField()  #enum
    pdv_tela_alterar_emit_nota = CharField()  #enum
    bal_status = CharField()  #enum
    bal_tipo_codigo = CharField()  #enum
    geral_tipo_impressao_carne = CharField()  #enum
    geral_tipo_conciliacao_ofx = CharField()  #enum
    geral_lancarcontas = CharField()  #enum
    geral_lancarcontas_serv = CharField()  #enum
    geral_lancarcontas_comp = CharField()  #enum
    geral_lancarestoque = CharField()  #enum

    @classmethod
    def dados_iniciais(cls, id_empresa, id_usuario):
        id = cls.select(fn.MAX(cls.id_parametro)).scalar()
        id = id if id is not None else 1
        return [
            {
                'id_parametro': id + 1,
                'id_empresa': id_empresa,
                'cst_icms': '',
                'modalidade_icms': 0,
                'pICMS_icms': '0.00',
                'ICMS_automatico': 0,
                'pRedBC_icms': '0.00',
                'motDesICMS_icms': 0,
                'pCredSN_icms': '0.00',
                'pFCP_icms': '0.00',
                'pFCPST_icms': '0.00',
                'pFCPSTRet_icms': '0.00',
                'pDif_icms': '0.0000',
                'cst_ipi': '53',
                'classe_enquadramento': '',
                'cEnq_enquadramento': '',
                'pIPI_ipi': '0.00',
                'cst_pis': '08',
                'pPIS_pis': '0.65',
                'cst_cofins': '08',
                'pCOFINS_cofins': '3.00',
                'modalidade_st': 4,
                'pMVAST_st': '0.00',
                'pRedBCST_st': '0.00',
                'pICMSST_st': '18.00',
                'pPIS_st': '0.00',
                'pCOFINS_st': '0.00',
                'cfop_vendadentro': 5102,
                'cfop_vendafora': 6102,
                'cfop_entrada': 0,
                'cfop_importacao': 0,
                'cfop_exportacao': 0,
                'cfop_venda_st_dentro': 0,
                'cfop_venda_st_fora': 0,
                'cfop_nfce': 5102,
                'cfop_nfce_st': 5102,
                'grupo_nf_medicamento': 0,
                'grupo_nf_arma': 0,
                'grupo_nf_combustivel': 0,
                'desconto_condicionado': 1,
                'indPres_nf': 9,
                'nota_conjugada': 1,
                'nota_xml_email': 1,
                'cte_xml_email': 1,
                'mdfe_xml_email': 1,
                'nota_ultimo_nsu': 543,
                'nota_cad_fornecedores': 1,
                'nota_cad_produtos': 1,
                'nota_cad_transportadoras': 1,
                'bc_icms_ipi': 0,
                'bc_icms_frete': 0,
                'bc_icms_seguro': 0,
                'bc_icms_outros': 0,
                'bc_icms_desconto': 0,
                'bc_ipi_frete': 0,
                'bc_ipi_seguro': 0,
                'bc_pis_frete': 0,
                'bc_pis_outros': 0,
                'bc_pis_desconto': 0,
                'bc_cofins_frete': 0,
                'bc_cofins_outros': 0,
                'bc_cofins_desconto': 0,
                'nfce_cst_icms': '400',
                'nfce_modalidade_icms': 0,
                'nfce_pRedBC_icms': '0.00',
                'nfce_motDesICMS_icms': 0,
                'nfce_cst_pis': '08',
                'nfce_pPIS_pis': '0.65',
                'nfce_cst_cofins': '08',
                'nfce_pCOFINS_cofins': '3.00',
                'nfce_indPres_nf': 1,
                'nfce_bc_icms_frete': 0,
                'nfce_bc_icms_outros': 0,
                'nfce_bc_icms_desconto': 0,
                'nfce_bc_pis_frete': 0,
                'nfce_bc_pis_outros': 0,
                'nfce_bc_pis_desconto': 0,
                'nfce_bc_cofins_frete': 0,
                'nfce_bc_cofins_outros': 0,
                'nfce_bc_cofins_desconto': 0,
                'nfce_token': 'V0TCMVGTESZH7VDRL0HF7JABWHKOXVWNMXZT',
                'nfce_token_id': 1,
                'nfce_layout': 'normal',
                'nfce_observacoes': 0,
                'nfce_grupo_combustivel': 0,
                'nfse_natureza_pedido': '',
                'nfse_regime_pedido': 1,
                'nfse_regime_especial': 0,
                'nfse_valor_aliquota': '2.000000',
                'nfse_valor_aliquota_iss_sn_ip': '0.000000',
                'nfse_itemLista_servico': 0,
                'nfse_aliq_cofins': '1.42',
                'nfse_aliq_pis': '2.00',
                'nfse_aliq_contribuicao': '2.00',
                'nfse_aliq_ir': '2.00',
                'nfse_aliq_iss': '4.00',
                'nfse_reter_cofins': 0,
                'nfse_reter_pis': 0,
                'nfse_reter_csll': 0,
                'nfse_reter_ir': 0,
                'nfse_reter_inss': 0,
                'nfse_autenticacao_login': 'saulo_visualhost',
                'nfse_autenticacao_senha': 'scsy@1992',
                'pdv_estoque': 1,
                'pdv_contas': 1,
                'pdv_contas_dias': 30,
                'pdv_contas_dias_debito': 1,
                'pdv_comissao': 1,
                'pdv_desconto': '15.00',
                'pdv_acrescimo': '0.00',
                'pdv_valebrinde': '200.00',
                'pdv_alterarpreco': 1,
                'pdv_emitirnfc': 1,
                'pdv_alteraroperador': 1,
                'pdv_listapreco': 0,
                'pdv_cupom_topo': 'Yba sushi ###Rua itingucu 1142###11965097938###',
                'pdv_cupom_rodape': 'Obrigado pela preferencia ###Volte sempre###Deus abencoe###',
                'pdv_cupom_layout': '60_Colunas',
                'pdv_evo_default_terminal': None,
                'pdv_evoluservices': 0,
                'bal_digitos_iniciais': 7,
                'bal_tamanho_codigo': 13,
                'bal_id_cod_prod_inicio': 2,
                'bal_id_cod_prod_fim': 7,
                'bal_id_valor_inicio': 8,
                'bal_id_valor_fim': 12,
                'bal_casas_decimais': 3,
                'msg_orcamento': 'Mensagem enviada junto ao orçamento.',
                'pdf_orcamento': 1,
                'msg_pedido': 'Mensagem enviada junto ao pedido.',
                'pdf_pedido': 1,
                'msg_notafiscal': '',
                'msg_ordemservico': 'Ordem de serviço',
                'pdf_ordemservico': 1,
                'msg_ordemservico_termos': 'No mundo atual, a expansão dos mercados mundiais auxilia a preparação e a composição das posturas dos órgãos dirigentes com relação às suas atribuições.',
                'msg_notaservico': 'teste vhsys de nota fiscal de serviço',
                'msg_ordemcompra': 'Mensagem enviada junto a ordem de compra. fasf asfsafas',
                'pdf_ordemcompra': 1,
                'msg_boleto': 'Mensagem enviada junto ao boleto bancário teste dasklhdsahdsajdsa',
                'msg_envio_conta_bancaria': '',
                'geral_estoque': 1,
                'geral_estoqueminimo': 1,
                'geral_bloquearestoque': 0,
                'geral_bloquearagrupamento': 1,
                'geral_casas': 3,
                'geral_ocultarmenu': 0,
                'geral_vendedores': 2,
                'geral_comissionamento': 2,
                'geral_limitepag': 80,
                'geral_limiteautocomplete': 0,
                'geral_tipo_busca_autocomplete': 1,
                'geral_exibir_unidade_autocomplete': 1,
                'geral_exibir_estoque_autocomplete': 0,
                'geral_listapreco': 1,
                'geral_dia_util': 1,
                'geral_desconsidera': 0,
                'geral_dados_pedido': 1,
                'geral_dados_pedido_nf': 1,
                'geral_dados_gtin_nf': 1,
                'geral_dados_os': 1,
                'geral_data_lancarestoque': 0,
                'geral_impressao_capa_produto': 1,
                'geral_impressao_capa_produto_tamanho': 50,
                'geral_impressao_capa_orcamento': 1,
                'geral_categoria_receita_id': 5,
                'geral_categoria_receita': 'Aplicações Financeiras',
                'geral_categoria_despesa_id': 0,
                'geral_categoria_despesa': '',
                'geral_categoria_vendas_id': 5,
                'geral_categoria_vendas': 'Aplicações Financeiras',
                'geral_categoria_servicos_id': 1,
                'geral_categoria_servicos': 'Saldo Inicial',
                'geral_categoria_compras_id': 25,
                'geral_categoria_compras': 'Energia Elétrica + Água',
                'geral_categoria_padrao_dre': 0,
                'geral_centro_receitas': 'Venda particular',
                'geral_centro_receitas_id': 21251,
                'geral_centro_despesas': 'Obra 1',
                'geral_centro_despesas_id': 21716,
                'geral_centro_vendas': '',
                'geral_centro_vendas_id': 0,
                'geral_centro_servicos': '@teste',
                'geral_centro_servicos_id': 20802,
                'geral_centro_compras': 'teste centro de custos',
                'geral_centro_compras_id': 17335,
                'geral_smtp_host': '',
                'geral_smtp_email': '',
                'geral_smtp_senha': '',
                'geral_smtp_porta': '',
                'geral_smtp_cript': '',
                'geral_cnpj_duplicado': 1,
                'geral_atualizar_custo': 1,
                'dashboard_faturamento_tipo': 4,
                'dashboard_faturamento_cfop': '',
                'dashboard_faturamento_status': '',
                'dashboard_faturamento_regra': 1,
                'dashboard_contaspag_status': 'Aberto',
                'dashboard_contaspag_periodo': '30',
                'dashboard_contasrec_status': 'Atraso',
                'dashboard_contasrec_periodo': '3',
                'ord_contaspag': 'D',
                'ord_contasrec': 'D',
                'foto_lista_produto': 1,
                'replica_valores': 1,
                'data_mod_parametros': '2020-04-10 16:50:57',
                'usuario_mod_parametros': 338796,
                'nfce_integracao_pagamento': 2,
                'nfce_token_homolog': 'V0TCMVGTESZH7VDRL0HF7JABWHKOXVWNMXZT',
                'nfce_token_homolog_id': 1,
                'pdv_categoria_receita': 'Ajuste Caixa',
                'pdv_categoria_receita_id': 2,
                'pdv_categoria_despesa': 'Ajuste Caixa',
                'pdv_categoria_despesa_id': 53,
                'gerar_boleto': 0,
                'pdv_parametrizar_boleto': 0,
                'xml_entradas_receita_aguardando': None,
                'ultima_verificacao_xml_entrada_receita': None,
                'grupo_nf_veiculos': 0,
                'nota_scan_manual': 'Auto',
                'cte_scan_manual': 'Auto',
                'mdfe_scan_manual': 'Auto',
                'orientacao_logo_nf': 'C',
                'pdv_tipo_acrescimo': 'P',
                'pdv_tipo_desconto': 'P',
                'pdv_cupom_impressao': 'PDF',
                'pdv_impressao_item': 'Sim',
                'pdv_impressao_codigo': 'Sim',
                'pdv_impressao_desc': 'Sim',
                'pdv_impressao_valor': 'Sim',
                'pdv_impressao_qtde': 'Sim',
                'pdv_caixa': '1',
                'pdv_tela_alterar_emit_nota': '0',
                'bal_status': '1',
                'bal_tipo_codigo': 'Valor',
                'geral_tipo_impressao_carne': 'triplo',
                'geral_tipo_conciliacao_ofx': 'Data',
                'geral_lancarcontas': 'Ambos',
                'geral_lancarcontas_serv': 'Ambos',
                'geral_lancarcontas_comp': 'Ambos',
                'geral_lancarestoque': 'Pedido',
            }
        ]