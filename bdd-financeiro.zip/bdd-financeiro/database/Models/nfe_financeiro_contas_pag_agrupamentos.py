from peewee import *
from .BaseModel import BaseModel


class nfe_financeiro_contas_pag_agrupamentos(BaseModel):
    id_agrupamento = IntegerField(primary_key=True)  #int
    id_conta_pag = IntegerField()  #bigint
    id_conta_pag_agrupada = IntegerField()  #bigint
    dt_criacao = DateTimeField()  #timestamp
    dt_atualizacao = DateTimeField()  #datetime
    lixeira = CharField()  #enum