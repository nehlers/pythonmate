from peewee import *
from .BaseModel import BaseModel


class nfe_config_whitelabel(BaseModel):
    id_whitelabel = IntegerField(primary_key=True)  #int
    code = CharField()  #longtext
    genero_whitelabel = IntegerField()  #tinyint
    nome_whitelabel = CharField()  #char
    titulo_whitelabel = CharField()  #varchar
    titulo_curto_whitelabel = CharField()  #varchar
    link_whitelabel = CharField()  #varchar
    link_portal_whitelabel = CharField()  #varchar
    telefone_whitelabel = CharField()  #varchar
    telefone_suporte_whitelabel = CharField()  #varchar
    telefone_vendas_whitelabel = CharField()  #varchar
    telefone_celular_whitelabel = CharField()  #varchar
    twitter_whitelabel = CharField()  #varchar
    youtube_whitelabel = CharField()  #varchar
    facebook_whitelabel = CharField()  #varchar
    googleplus_whitelabel = CharField()  #varchar
    linkedin_whitelabel = CharField()  #varchar
    css_email_whitelabel = CharField()  #text
    data_cad_whitelabel = DateTimeField()  #timestamp
    sso_enabled = IntegerField()  #tinyint
    sso_realm = CharField()  #longtext
    sso_key_backend = CharField()  #longtext
    sso_key_auth = CharField()  #longtext
    sso_audience = CharField()  #longtext
    sso_url = CharField()  #longtext

    @classmethod
    def dados_iniciais(cls, id_empresa, id_usuario):
        return [
            {
                'id_whitelabel': 1,
                'code': 'stone',
                'genero_whitelabel': 1,
                'nome_whitelabel': 'Stone',
                'titulo_whitelabel': 'Stone Gestão | Sistema VHSYS',
                'titulo_curto_whitelabel': 'Stone Gestão',
                'link_whitelabel': 'dev-stone.app.vhsys.com.br',
                'link_portal_whitelabel': 'dev-stone.app.vhsys.com.br',
                'telefone_whitelabel': '5007-3710',
                'telefone_suporte_whitelabel': '0800 840 2506',
                'telefone_vendas_whitelabel': '0800 008 0018',
                'telefone_celular_whitelabel': '',
                'twitter_whitelabel': 'https://twitter.com/stone',
                'youtube_whitelabel': 'https://youtube.com/stone',
                'facebook_whitelabel': 'https://facebook.com/stone',
                'googleplus_whitelabel': 'https://plus.google.com/+stone',
                'linkedin_whitelabel': 'https://www.linkedin.com/company/stone',
                'css_email_whitelabel': '{"btn_success": "background-color:#14AA4B;","btn_primary": "background-color: #088037;","text_primary": "color: #088037;","text_primary_light": "color: #34E073;","text_primary_dark": "color: #054d21;"}',
                'data_cad_whitelabel': '2019-10-08 15:05:16',
                'sso_enabled': 1,
                'sso_realm': 'stone_account',
                'sso_key_backend': '14adb359-1b3c-46fa-b9a6-6df75d9a247a',
                'sso_key_auth': 'fff7262d-0d1e-47f9-9e38-0e0def1eab18',
                'sso_audience': 'https://login.sandbox.stone.com.br/auth/realms/stone_account',
                'sso_url': 'https://login.sandbox.stone.com.br/auth',
            }
        ]