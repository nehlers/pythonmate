from peewee import *
from .BaseModel import BaseModel


class nfe_financeiro_contas_pag_recebimentos(BaseModel):
    id_recebimento = IntegerField(primary_key=True)  #int
    id_conta_pag = IntegerField()  #bigint
    data_pagamento = DateTimeField()  #date
    valor_pago = DecimalField()  #decimal
    valor_juros = DecimalField()  #decimal
    valor_desconto = DecimalField()  #decimal
    valor_acrescimo = DecimalField()  #decimal
    forma_pagamento = CharField()  #varchar
    obs_pagamento = CharField()  #longtext
    sync = IntegerField()  #tinyint
    sync_id = IntegerField()  #int
    sync_user = IntegerField()  #int
    id_pagamento_ob = CharField()  #varchar
    id_banco_cad = IntegerField()  #bigint
    