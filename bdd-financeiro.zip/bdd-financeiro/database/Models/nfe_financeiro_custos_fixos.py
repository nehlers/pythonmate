from peewee import *
from .BaseModel import BaseModel
from datetime import date
from .nfe_cadastros_bancos import nfe_cadastros_bancos

class nfe_financeiro_custos_fixos(BaseModel):
    id_custo = IntegerField(primary_key=True)  #bigint
    id_empresa = IntegerField()  #bigint
    nome_conta = CharField()  #char
    id_categoria = IntegerField()  #int
    categoria_custo = CharField()  #char
    id_banco = IntegerField()  #bigint
    id_fornecedor = IntegerField()  #bigint
    nome_fornecedor = CharField()  #varchar
    vencimento_custo = IntegerField()  #tinyint
    valor_custo = DecimalField()  #decimal
    observacoes_custo = CharField()  #longtext
    id_centro_custos = IntegerField()  #bigint
    centro_custos = CharField()  #varchar
    status_custo = CharField()  #enum
    forma_pagamento = CharField()  #varchar
    periodicidade = IntegerField()  #tinyint
    dia_semana_ocorrencia = IntegerField()  #tinyint
    dia_mes_ocorrencia = IntegerField()  #tinyint
    intervalo_dias_ocorrencia = IntegerField()  #tinyint
    data_inicio_ocorrencia = DateTimeField()  #date
    data_fim_ocorrencia = DateTimeField()  #date
    data_cad_custo = DateTimeField()  #datetime
    data_mod_custo = DateTimeField()  #datetime
    lixeira = CharField()  #enum

    @classmethod
    def dados_iniciais(cls, id_empresa, id_usuario):
        id_banco = nfe_cadastros_bancos.obter_codigo_banco(nfe_cadastros_bancos, id_empresa, 'Conta Inicial (Caixinha)')

        id = cls.select(fn.MAX(cls.id_custo)).scalar()
        id = id if id is not None else 1
        return [
            {
                "id_custo": id + 1,
                "id_empresa": id_empresa,
                "nome_conta": 'Despesa Bebidas',
                "id_categoria": 0,
                "categoria_custo": None,
                "id_banco": id_banco,
                "id_fornecedor": 0,
                "nome_fornecedor": 'Distribuidora de Bebidas',
                "vencimento_custo": 1,
                "valor_custo": 45.90,
                "observacoes_custo": None,
                "id_centro_custos": 0,
                "centro_custos": None,
                "status_custo": 'Ativo',
                "forma_pagamento": None,
                "periodicidade": 8,
                "dia_semana_ocorrencia": None,
                "dia_mes_ocorrencia": None,
                "intervalo_dias_ocorrencia": 35,
                "data_inicio_ocorrencia": '2020-03-09',
                "data_fim_ocorrencia": date.today().strftime("%Y-%m-%d"),
            },
            {
                "id_custo": id + 2,
                "id_empresa": id_empresa,
                "nome_conta": 'Despesa Doces',
                "id_categoria": 0,
                "categoria_custo": None,
                "id_banco": id_banco,
                "id_fornecedor": 0,
                "nome_fornecedor": 'Distribuidora de Doces',
                "vencimento_custo": 1,
                "valor_custo": 45.90,
                "observacoes_custo": None,
                "id_centro_custos": 0,
                "centro_custos": None,
                "status_custo": 'Ativo',
                "forma_pagamento": None,
                "periodicidade": 1,
                "dia_semana_ocorrencia": 1,
                "dia_mes_ocorrencia": 2,
                "intervalo_dias_ocorrencia": None,
                "data_inicio_ocorrencia": '2020-03-09',
                "data_fim_ocorrencia": date.today().strftime("%Y-%m-%d"),
            },
            {
                "id_custo": id + 3,
                "id_empresa": id_empresa,
                "nome_conta": 'Despesa Peças',
                "id_categoria": 0,
                "categoria_custo": None,
                "id_banco": id_banco,
                "id_fornecedor": 0,
                "nome_fornecedor": 'Distribuidora de Peças',
                "vencimento_custo": 1,
                "valor_custo": 90.90,
                "observacoes_custo": None,
                "id_centro_custos": 0,
                "centro_custos": None,
                "status_custo": 'Ativo',
                "forma_pagamento": None,
                "periodicidade": 3,
                "dia_semana_ocorrencia": None,
                "dia_mes_ocorrencia": 5,
                "intervalo_dias_ocorrencia": 5,
                "data_inicio_ocorrencia": '2020-03-26',
                "data_fim_ocorrencia": '2020-03-30',
            },
            {
                "id_custo": id + 4,
                "id_empresa": id_empresa,
                "nome_conta": 'Despesa Roupas',
                "id_categoria": 0,
                "categoria_custo": None,
                "id_banco": id_banco,
                "id_fornecedor": 0,
                "nome_fornecedor": 'Distribuidora de Roupas',
                "vencimento_custo": 1,
                "valor_custo": 2500.90,
                "observacoes_custo": None,
                "id_centro_custos": 0,
                "centro_custos": None,
                "status_custo": 'Inativo',
                "forma_pagamento": None,
                "periodicidade": 7,
                "dia_semana_ocorrencia": None,
                "dia_mes_ocorrencia": 29,
                "intervalo_dias_ocorrencia": None,
                "data_inicio_ocorrencia": '2020-04-15',
                "data_fim_ocorrencia": '2020-04-25',
            },
            {
                "id_custo": id + 5,
                "id_empresa": id_empresa,
                "nome_conta": 'Despesa Materiais',
                "id_categoria": 0,
                "categoria_custo": None,
                "id_banco": id_banco,
                "id_fornecedor": 0,
                "nome_fornecedor": 'Distribuidora de Materiais',
                "vencimento_custo": 1,
                "valor_custo": 45.90,
                "observacoes_custo": None,
                "id_centro_custos": 0,
                "centro_custos": None,
                "status_custo": 'Inativo',
                "forma_pagamento": None,
                "periodicidade": 1,
                "dia_semana_ocorrencia": 1,
                "dia_mes_ocorrencia": 2,
                "intervalo_dias_ocorrencia": None,
                "data_inicio_ocorrencia": '2020-03-09',
                "data_fim_ocorrencia": date.today().strftime("%Y-%m-%d"),
            },            
        ]

    