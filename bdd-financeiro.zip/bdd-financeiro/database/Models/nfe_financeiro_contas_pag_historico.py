from peewee import *
from .BaseModel import BaseModel


class nfe_financeiro_contas_pag_historico(BaseModel):
    id_conta_pag_historico = IntegerField(primary_key=True)  #bigint
    id_conta_pag = IntegerField()  #int
    situacao = CharField()  #varchar
    status = IntegerField()  #tinyint
    dt_historico = DateTimeField()  #timestamp
    id_pagamento = CharField()  #varchar
    id_empresa = IntegerField()  #int
    id_usuario = IntegerField()  #int
    nome_conta = CharField()  #char
    valor_pag = DecimalField()  #decimal
    valor_pago = DecimalField()  #decimal
    valor_juros = DecimalField()  #decimal
    valor_desconto = DecimalField()  #decimal
    valor_acrescimo = DecimalField()  #decimal
    dt_agendamento = DateTimeField()  #datetime
    codigo_barras = CharField()  #varchar
    valor_taxa = DecimalField()  #decimal
