from peewee import *
from .BaseModel import BaseModel


class nfe_config_usuarios_widgets(BaseModel):
    id_usuario = IntegerField(primary_key=True)  #int
    id_widget = IntegerField()  #int
    ordem = IntegerField()  #int
    coluna = CharField()  #enum

    @classmethod
    def dados_iniciais(cls, id_empresa, id_usuario):
        return [            
            {
                'id_usuario': id_usuario,
                'id_widget': 5,
                'ordem': None,
                'coluna': '0'
            }
        ]