from peewee import *
from .BaseModel import BaseModel
import os


class nfe_config_usuarios(BaseModel):
    id_usuario = IntegerField(primary_key=True)  #int
    id_empresa = IntegerField()  #int
    nome_usuario = CharField()  #varchar
    email_usuario = CharField()  #varchar
    celular_usuario = CharField()  #varchar
    login_usuario = CharField()  #char
    login_usuario_email = CharField()  #varchar
    senha_usuario = CharField()  #varchar
    tipo_usuario = CharField()  #enum
    master_usuario = CharField()  #enum
    dados_usuario = IntegerField()  #tinyint
    dados_usuario_cad = IntegerField()  #tinyint
    cargo_usuario = CharField()  #varchar
    tomador_decisao = CharField()  #enum
    home_esquerda = CharField()  #varchar
    home_direita = CharField()  #varchar
    restricoes_usuario = IntegerField()  #tinyint
    hash_recuperar = CharField()  #char
    restricoes_ip = CharField()  #char
    sync = IntegerField()  #tinyint
    sync_data = DateTimeField()  #datetime
    data_cad_usuario = DateTimeField()  #datetime
    lixeira = CharField()  #enum

    @classmethod
    def dados_iniciais(cls, id_empresa, id_usuario):
        return [
            {
                'id_usuario': id_usuario,
                'id_empresa': id_empresa,
                'nome_usuario': 'VHSYS',
                'email_usuario': 'automacao.teste@vhsys.com.br',
                'celular_usuario': '(41) 99556-5653',
                'login_usuario': os.environ["LOGIN"],
                'login_usuario_email': 'automacao.teste@vhsys.com.br',
                'senha_usuario': '=ADMhJDZmZWOyETN0EjNwUTNmhDO5QjY2QDNzYWM3UGZ',
                'tipo_usuario': 'Administrador',
                'master_usuario': 'Nao',
                'dados_usuario': 0,
                'dados_usuario_cad': 0,
                'cargo_usuario': 'Owner',
                'tomador_decisao': 'Nao',
                'home_esquerda': 'alterado',
                'home_direita': 'alterado',
                'restricoes_usuario': 0,
                'hash_recuperar': 'AwcDMyQjstoELK1CLNpUCKLBO1iSo0SzzRVN3ysys0kLt8ws',
                'restricoes_ip': '',
                'sync': 1,
                'sync_data': '2020-02-12 11:17:32',
                'data_cad_usuario': '2020-01-29 16:33:50',
                'lixeira': 'Nao',
            }
        ]