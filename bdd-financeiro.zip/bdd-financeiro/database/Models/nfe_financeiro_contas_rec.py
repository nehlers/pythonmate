from peewee import *
from .BaseModel import BaseModel
from .nfe_financeiro_contas_rec_agrupamentos import nfe_financeiro_contas_rec_agrupamentos


class nfe_financeiro_contas_rec(BaseModel):
    id_conta_rec = IntegerField(primary_key=True)  #bigint
    id_empresa = IntegerField()  #bigint
    id_registro = IntegerField()  #bigint
    identificacao = CharField()  #char
    nome_conta = CharField()  #char
    id_categoria = IntegerField()  #int
    categoria_rec = CharField()  #char
    id_banco = IntegerField()  #bigint
    id_cliente = IntegerField()  #bigint
    id_boleto = IntegerField()  #bigint
    nome_cliente = CharField()  #varchar
    vencimento_rec = DateTimeField()  #date
    valor_rec = DecimalField()  #decimal
    valor_pago = DecimalField()  #decimal
    data_emissao = DateTimeField()  #date
    vencimento_original = DateTimeField()  #date
    n_documento_rec = CharField()  #varchar
    observacoes_rec = CharField()  #longtext
    id_centro_custos = IntegerField()  #bigint
    centro_custos_rec = CharField()  #varchar
    praca_pagamento = CharField()  #varchar
    liquidado_rec = CharField()  #enum
    data_pagamento = DateTimeField()  #date
    obs_pagamento = CharField()  #longtext
    forma_pagamento = CharField()  #varchar
    valor_juros = DecimalField()  #decimal
    valor_desconto = DecimalField()  #decimal
    valor_acrescimo = DecimalField()  #decimal
    retorno_pagamento = IntegerField()  #tinyint
    tipo_conta = CharField()  #char
    data_cad_rec = DateTimeField()  #timestamp
    data_mod_rec = DateTimeField()  #datetime
    boleto_enviado = IntegerField()  #tinyint
    boleto_original = IntegerField()  #tinyint
    duplicata_enviado = IntegerField()  #tinyint
    remetido = IntegerField()  #tinyint
    registrado = IntegerField()  #tinyint
    protestar = IntegerField()  #tinyint
    dias_protestar = IntegerField()  #tinyint
    NossoNumero = CharField()  #char
    agrupado = IntegerField()  #tinyint
    agrupado_data = DateTimeField()  #datetime
    agrupado_user = CharField()  #char
    agrupamento = IntegerField()  #tinyint
    fluxo = IntegerField()  #tinyint
    sync = IntegerField()  #tinyint
    sync_id = IntegerField()  #int
    sync_user = IntegerField()  #int
    lixeira = CharField()  #enum
    id_pagamento_ob = CharField()  #varchar
    situacao = CharField()  #varchar
    status = IntegerField()  #tinyint


    @classmethod
    def apagar_dados_empresa(cls, id_empresa):
        for conta in nfe_financeiro_contas_rec.select().where(nfe_financeiro_contas_rec.id_empresa == id_empresa):
            nfe_financeiro_contas_rec_agrupamentos.delete().where(nfe_financeiro_contas_rec_agrupamentos.id_conta_rec == conta.id_conta_rec).execute()

        nfe_financeiro_contas_rec.delete().where(nfe_financeiro_contas_rec.id_empresa == id_empresa).execute()
