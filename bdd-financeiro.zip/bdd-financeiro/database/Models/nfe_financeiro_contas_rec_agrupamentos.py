from peewee import *
from .BaseModel import BaseModel


class nfe_financeiro_contas_rec_agrupamentos(BaseModel):
    id_agrupamento = IntegerField()  #int
    id_conta_rec_agrupada = IntegerField()  #bigint
    id_conta_rec = IntegerField()  #bigint
    dt_criacao = DateTimeField()  #timestamp
    dt_atualizacao = DateTimeField()  #datetime
    lixeira = CharField()  #enum
