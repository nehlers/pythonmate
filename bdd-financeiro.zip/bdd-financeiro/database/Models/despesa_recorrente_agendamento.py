from peewee import *
from .BaseModel import BaseModel
from .nfe_financeiro_custos_fixos import nfe_financeiro_custos_fixos
from playhouse.shortcuts import model_to_dict


class despesa_recorrente_agendamento(BaseModel):
    id_agendamento = IntegerField(primary_key=True)  #int
    id_custo_fixo = IntegerField()  #bigint
    id_conta_pag = IntegerField()  #bigint
    status = IntegerField()  #tinyint
    valor_custo = DecimalField()  #decimal
    data_agendamento = DateTimeField()  #timestamp
    data_cad_agendamento = DateTimeField()  #datetime
    data_mod_agendamento = DateTimeField()  #datetime

    @classmethod
    def apagar_dados_empresa(cls, id_empresa):
        despesas_fixas = (nfe_financeiro_custos_fixos
            .select()
            .where(nfe_financeiro_custos_fixos.id_empresa == id_empresa))
        cls.delete().where(cls.id_custo_fixo.in_(despesas_fixas)).execute()