SELECT CONCAT(COLUMN_NAME, ' = ',  
IF(DATA_TYPE = 'int', "IntegerField()", 
IF(DATA_TYPE = 'tinyint', "IntegerField()", 
IF(DATA_TYPE = 'varchar', "CharField()", 
IF(DATA_TYPE = 'char', "CharField()", 
IF(DATA_TYPE = 'longtext', "CharField()", 
IF(DATA_TYPE = 'decimal', "DecimalField()", 
IF(DATA_TYPE = 'smallint', "IntegerField()", 
IF(DATA_TYPE = 'enum', "CharField()", 
IF(DATA_TYPE = 'text', "CharField()", 
IF(DATA_TYPE = 'date', "DateTimeField()", 
IF(DATA_TYPE = 'timestamp', "DateTimeField()", 
IF(DATA_TYPE = 'datetime', "DateTimeField()", 
IF(DATA_TYPE = 'bigint', "IntegerField()", "NO"))))))))))))),
'  #',data_type) data
FROM INFORMATION_SCHEMA.columns
WHERE table_schema = 'vhsys_erp_test'
AND TABLE_NAME = 'TABELA DO MODEL'
