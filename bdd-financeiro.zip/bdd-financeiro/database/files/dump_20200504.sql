CREATE DATABASE  IF NOT EXISTS `vhsys_erp_test` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `vhsys_erp_test`;
-- MySQL dump 10.13  Distrib 8.0.18, for Linux (x86_64)
--
-- Host: mysql.vhsys.local    Database: vhsys_erp_test
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `CONFIG`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `CONFIG` (
  `id_config` tinyint(1) NOT NULL DEFAULT '0',
  `nome` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `titulo_site` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnpj` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_contato` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `css_config` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `login_smtp` char(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `senha_smtp` char(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `host_smtp` char(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_smtp` char(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mensagem_sistema` longtext COLLATE utf8mb4_unicode_ci,
  `banco_agencia` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banco_agencia_dv` char(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banco_conta` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banco_conta_dv` char(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banco_convenio` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banco_carteira` char(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banco_instrucoes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resgate_comissao` decimal(10,2) DEFAULT NULL,
  `valor_sms` decimal(10,2) DEFAULT NULL,
  `valor_email` decimal(10,2) DEFAULT NULL,
  `valor_certificado` decimal(10,2) DEFAULT NULL,
  `valor_certificado_promocao` decimal(10,2) DEFAULT NULL,
  `promocao_banner` tinyint(1) DEFAULT '0',
  `promocao_titulo` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `termos_loja` longtext COLLATE utf8mb4_unicode_ci,
  `termos_sistema` longtext COLLATE utf8mb4_unicode_ci,
  `host_buckets3` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nome_buckets3` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_acessoADM` longtext COLLATE utf8mb4_unicode_ci,
  `aliquota_iss` decimal(10,2) DEFAULT NULL,
  `versao_emissora3` char(6) COLLATE utf8mb4_unicode_ci DEFAULT '1.0',
  `pdv_desativado` int(11) DEFAULT '1',
  `valor_meta_mensal` decimal(10,2) DEFAULT NULL,
  `nps_primeira_exibicao` int(11) DEFAULT '30',
  `nps_proxima_exibicao` int(11) DEFAULT '45',
  `nps_ocultar_exibicao` int(11) DEFAULT '7'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRON`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `CRON` (
  `id_cron` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_jobs` tinyint(1) NOT NULL DEFAULT '0',
  `ip_execucao` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_inicio` datetime NOT NULL,
  `data_cron` datetime NOT NULL,
  PRIMARY KEY (`id_cron`),
  KEY `id_jobs` (`id_jobs`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `CRON_JOBS`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `CRON_JOBS` (
  `id_jobs` tinyint(1) NOT NULL,
  `nome_jobs` char(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `configuracao_jobs` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc_jobs` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `endereco_jobs` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Exten_Compras_Fornecedores`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `Exten_Compras_Fornecedores` (
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_fornecedor` bigint(20) DEFAULT '0',
  `razao_fornecedor` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ValorComprasPorFornecedor` decimal(32,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Exten_Vendas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `Exten_Vendas` (
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `cnpj_empresa` char(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fone_empresa` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `responsavel_celular` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `responsavel_empresa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `razao_empresa` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ValorContasAReceberNaoRecebido` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ValorVendaEmitido` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valorContasAPagar_Em_Aberto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valorContasAPagar_Em_Atraso` decimal(10,2) NOT NULL DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Exten_Vendas_Ano_Mes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `Exten_Vendas_Ano_Mes` (
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `Ano` int(11) DEFAULT NULL,
  `Mes` int(11) DEFAULT NULL,
  `ValorFaturado` decimal(32,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Exten_Vendas_Clientes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `Exten_Vendas_Clientes` (
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) NOT NULL DEFAULT '0',
  `razao_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ValorVendaPorCliente` decimal(32,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `admin_campanhas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `admin_campanhas` (
  `id_campanha` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_empresas` longtext COLLATE utf8mb4_unicode_ci,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('Imagem','HTML') COLLATE utf8mb4_unicode_ci NOT NULL,
  `campanha` longtext COLLATE utf8mb4_unicode_ci,
  `trial` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `pagante` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Ativo',
  `data_cad_campanha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_campanha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_campanha`),
  KEY `id_campanha` (`id_campanha`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `admin_oauth_clients`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `admin_oauth_clients` (
  `id_oauth` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret_key` char(44) COLLATE utf8mb4_unicode_ci NOT NULL,
  `application` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'api',
  `white_label` tinyint(1) NOT NULL DEFAULT '0',
  `data_cad_oauth` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_oauth`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `admin_planos_inflacoes_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `admin_planos_inflacoes_log` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` tinyint(3) unsigned DEFAULT NULL,
  `id_empresa` int(10) unsigned DEFAULT NULL,
  `id_plano` smallint(5) unsigned DEFAULT NULL,
  `id_servico_antigo` bigint(20) unsigned DEFAULT NULL,
  `id_servico_novo` bigint(20) unsigned DEFAULT NULL,
  `tipo_pagamento` int(11) DEFAULT NULL,
  `preco_antigo` decimal(16,2) DEFAULT NULL,
  `preco_novo` decimal(16,2) DEFAULT NULL,
  `proximo_mes` date DEFAULT NULL,
  `inflacao` decimal(16,2) DEFAULT NULL,
  `tipo_inflacao` enum('P','V') COLLATE utf8mb4_unicode_ci DEFAULT 'P',
  `data_cad_inflacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_servico_antigo` (`id_servico_antigo`),
  KEY `data_cad_inflacao` (`data_cad_inflacao`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_plano` (`id_plano`),
  KEY `id_servico_novo` (`id_servico_novo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `admin_proposta`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `admin_proposta` (
  `id_proposta` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) DEFAULT NULL,
  `id_empresa` int(11) DEFAULT '0',
  `proposta` text COLLATE utf8mb4_unicode_ci,
  `data_cad_proposta` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_proposta`),
  KEY `id_proposta` (`id_proposta`,`id_usuario`,`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `admin_servico_faturamento`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `admin_servico_faturamento` (
  `nfs_e_padrao` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uf_cidade` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_empresa_cod` int(11) DEFAULT NULL,
  `nome_cidade` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_ultima_homologacao` date DEFAULT NULL,
  `qtdEmpresasBase` bigint(20) NOT NULL DEFAULT '0',
  `qtdEmpresasEmitem` bigint(20) NOT NULL DEFAULT '0',
  `qtdNotasEmitidas3M` decimal(42,0) DEFAULT NULL,
  `valorNotasEmitidas3M` decimal(54,2) DEFAULT NULL,
  `dataUltimaNota` datetime DEFAULT NULL,
  `valorPlanoMensalVhsys` decimal(58,6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `admin_subdepartamento_usuarios`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `admin_subdepartamento_usuarios` (
  `id_subdepartamento` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_departamento` int(11) NOT NULL,
  `descricao` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_subdepartamento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `admin_usuarios`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `admin_usuarios` (
  `id_usuario` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome_usuario` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_usuario` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_usuario` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `senha_usuario` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_usuario` enum('Administrador','Usuario') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Administrador',
  `departamento_usuario` tinyint(1) NOT NULL DEFAULT '0',
  `subdepartamento` tinyint(1) NOT NULL DEFAULT '0',
  `nivel_usuario` tinyint(1) NOT NULL DEFAULT '1',
  `horario_inicio` time NOT NULL DEFAULT '09:00:00',
  `horario_inicio_almoco` time NOT NULL DEFAULT '12:00:00',
  `horario_fim_almoco` time NOT NULL DEFAULT '13:00:00',
  `horario_fim` time NOT NULL DEFAULT '18:00:00',
  `ramal_usuario` char(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto_usuario` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_usuario_diario` decimal(10,2) NOT NULL,
  `meta_usuario_mensal` decimal(10,2) NOT NULL,
  `data_cad_usuario` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `cod_cidade` int(11) NOT NULL,
  `uf` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `login_usuario` (`login_usuario`),
  KEY `nome_usuario` (`nome_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `admin_usuarios_connections_id`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `admin_usuarios_connections_id` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) DEFAULT NULL,
  `connection_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_connection_id` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `connection_id` (`connection_id`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `admin_usuarios_departamentos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `admin_usuarios_departamentos` (
  `id_departamento` tinyint(1) NOT NULL,
  `nome_departamento` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordem` tinyint(1) NOT NULL DEFAULT '0',
  `ramal_departamento` char(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `admin_usuarios_permissoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `admin_usuarios_permissoes` (
  `id_permissao` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint(20) DEFAULT '0',
  `id_sub_menu` int(11) DEFAULT '0',
  PRIMARY KEY (`id_permissao`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `admin_venda_interna`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `admin_venda_interna` (
  `id_venda` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nsa` int(11) DEFAULT NULL,
  `data_inicial` date DEFAULT NULL,
  `data_final` date DEFAULT NULL,
  `arquivo_txt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `data_cad` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_venda`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `admin_venda_interna_faturas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `admin_venda_interna_faturas` (
  `id_venda_fatura` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_venda` int(11) DEFAULT NULL,
  `id_fatura` bigint(20) DEFAULT NULL,
  `ordenacao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_venda_fatura`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `admin_vouchers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `admin_vouchers` (
  `id_voucher` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_certificadora` int(11) NOT NULL DEFAULT '0',
  `hash_voucher` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `lote_voucher` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `usuario_cad_voucher` int(11) NOT NULL DEFAULT '0',
  `usuario_exc_voucher` int(11) NOT NULL DEFAULT '0',
  `status_voucher` enum('Novo','Vinculado','Revogado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Novo',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  `data_exc_voucher` datetime DEFAULT NULL,
  `data_cad_voucher` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_voucher` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_voucher`),
  KEY `id` (`id_voucher`),
  KEY `id_certificadora` (`id_certificadora`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `admin_vouchers_certificadoras`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `admin_vouchers_certificadoras` (
  `id_certificadora` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome_certificadora` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `informacoes_certificadora` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_certificadora` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_certificadora` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_certificadora`),
  KEY `id_certificadora` (`id_certificadora`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `admin_vouchers_solicitacoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `admin_vouchers_solicitacoes` (
  `id_solicitacao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_voucher` int(11) DEFAULT '0',
  `id_certificadora` int(11) DEFAULT '0',
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_fatura` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `cnpj_cliente` char(18) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `observacao` longtext COLLATE utf8mb4_unicode_ci,
  `senha_cliente` char(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `confirmacao_de_termos` tinyint(1) NOT NULL DEFAULT '0',
  `usuario_cad_cliente` int(11) NOT NULL DEFAULT '0',
  `usuario_exc_cliente` int(11) NOT NULL DEFAULT '0',
  `data_cad_cliente` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_cliente` datetime DEFAULT NULL,
  `data_exc_cliente` datetime DEFAULT NULL,
  `data_cad_solicitacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_solicitacao` datetime DEFAULT NULL,
  `data_exc_solicitacao` datetime DEFAULT NULL,
  `data_exp_solicitacao` date DEFAULT NULL,
  `data_vis_solicitacao` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_solicitacao`),
  KEY `id_certificadora` (`id_certificadora`),
  KEY `id_cliente` (`id_empresa`),
  KEY `id` (`id_solicitacao`),
  KEY `id_voucher` (`id_voucher`),
  KEY `id_fatura` (`id_fatura`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `aplicativos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `aplicativos` (
  `id_aplicativo` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nome_aplicativo` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_atalho` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `versao_aplicativo` char(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'v1.0',
  `pasta_aplicativo` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instalar_aplicativo` enum('Admin','Todos') COLLATE utf8mb4_unicode_ci DEFAULT 'Todos',
  `icone_aplicativo` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `capa_aplicativo` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto_1_aplicativo` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto_2_aplicativo` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto_3_aplicativo` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto_4_aplicativo` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc_aplicativo` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc_aplicativo_short` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_empresa_exclusivo` int(11) DEFAULT '0',
  `nome_empresa_exclusivo` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_aplicativo` tinyint(1) DEFAULT '1',
  `valor_aplicativo` decimal(10,2) DEFAULT '0.00',
  `cor_aplicativo` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `categoria_aplicativo` enum('Organizacao','Ferramentas','Gestao','Integracoes','Loja-Virtual') COLLATE utf8mb4_unicode_ci NOT NULL,
  `instalacoes_aplicativo` int(11) NOT NULL,
  `instalacoes_ativo_aplicativo` int(11) NOT NULL,
  `data_cad_aplicativo` datetime NOT NULL,
  `data_mod_aplicativo` datetime NOT NULL,
  `status_aplicativo` enum('Ativo','Inativo','Desenvolvimento') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Inativo',
  `destaque` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_aplicativo`),
  KEY `id_empresa_exclusivo` (`id_empresa_exclusivo`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `aplicativos_desconto_periodicidade`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `aplicativos_desconto_periodicidade` (
  `id_desconto` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_aplicativo` int(11) NOT NULL,
  `mensal` decimal(10,2) DEFAULT NULL,
  `trimestral` decimal(10,2) DEFAULT NULL,
  `semestral` decimal(10,2) DEFAULT NULL,
  `anual` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_desconto`),
  KEY `id_aplicativo` (`id_aplicativo`),
  KEY `id_desconto` (`id_desconto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `aplicativos_instalacoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `aplicativos_instalacoes` (
  `id_instalacao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_aplicativo` smallint(6) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `usuario_instalacao` int(11) NOT NULL DEFAULT '0',
  `tipo_instalacao` enum('Instalacao','Desinstalacao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Instalacao',
  `trial` tinyint(1) DEFAULT '0',
  `origem` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_expiracao` date DEFAULT NULL,
  `data_cad_instalacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_instalacao`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_aplicativo` (`id_aplicativo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `aplicativos_instalados`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `aplicativos_instalados` (
  `id_aplicativo` smallint(6) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `acesso_rapido` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `configurado` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `data_expiracao` date DEFAULT NULL,
  `trial` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `id_aplicativo_id_empresa` (`id_aplicativo`,`id_empresa`),
  KEY `id_aplicativo` (`id_aplicativo`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `aplicativos_ratio`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `aplicativos_ratio` (
  `id_ratio` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_aplicativo` smallint(6) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `ratio` tinyint(1) NOT NULL DEFAULT '0',
  `data_cad_ratio` datetime NOT NULL,
  PRIMARY KEY (`id_ratio`),
  KEY `id_aplicativo` (`id_aplicativo`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_agenda`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_agenda` (
  `id_agenda` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `titulo_agenda` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mensagem_agenda` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_inicio` datetime NOT NULL,
  `data_termino` datetime NOT NULL,
  `visivel_agenda` bigint(20) NOT NULL DEFAULT '0',
  `notificacao_email` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `notificacao_email_dados` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notificacao_sms` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `notificacao_sms_dados` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notificacao_tempo` smallint(6) NOT NULL DEFAULT '0',
  `notificacao_home` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `destaque_agenda` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sim',
  `id_calendario_gc` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `id_evento_gc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `usuario_cad_agenda` bigint(20) NOT NULL DEFAULT '0',
  `id_atividade_funil` int(11) NOT NULL DEFAULT '0',
  `data_cad_agenda` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_agenda` datetime DEFAULT NULL,
  `notificado` tinyint(1) NOT NULL DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_agenda`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_agenda_calendar`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_agenda_calendar` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `id_calendario_gc` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visivel` tinyint(1) NOT NULL DEFAULT '1',
  `data_cadastro` datetime DEFAULT NULL,
  `ultima_sincronizacao` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id`),
  KEY `id_calendario_gc` (`id_calendario_gc`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_agenda_convidados`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_agenda_convidados` (
  `id_convidado` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_agenda` bigint(20) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_convidado`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_agenda` (`id_agenda`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_agenda_usuario_calendar`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_agenda_usuario_calendar` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `google_account_email` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_token` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `expires_in` bigint(20) DEFAULT '0',
  `refresh_token` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `data_cadastro` datetime DEFAULT NULL,
  `data_modificacao` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_aniversariantes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_aniversariantes` (
  `id_aniversariante` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `enviar_sms` tinyint(1) NOT NULL DEFAULT '1',
  `enviar_email` tinyint(1) NOT NULL DEFAULT '1',
  `texto_sms` char(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nós da empresa ##REMETENTE## Desejamos a você um feliz aniversário!',
  `texto_email` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Desejamos a você um feliz aniversário.',
  PRIMARY KEY (`id_aniversariante`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_api_blacklist`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_api_blacklist` (
  `id_blacklist` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipo_blacklist` enum('Tag','Ip') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blacklist` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_blacklist`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_api_token`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_api_token` (
  `id_token` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `token` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cadastro` datetime DEFAULT NULL,
  PRIMARY KEY (`id_token`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_assinaturas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_assinaturas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `access_token` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expires_in` int(11) NOT NULL DEFAULT '0',
  `data_cad_usuario` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_usuario` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_assinaturas_assinaturas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_assinaturas_assinaturas` (
  `id_assinatura` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_assinatura_cliente` int(11) NOT NULL,
  `id_recorrente` bigint(20) NOT NULL,
  `valor_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `forma_pagamento` tinyint(1) NOT NULL,
  `id_cartao` int(11) NOT NULL DEFAULT '0',
  `status_assinatura` tinyint(1) NOT NULL DEFAULT '1',
  `data_cad_assinatura` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_assinatura` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_assinatura`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_recorrente` (`id_recorrente`),
  KEY `status_assinatura` (`status_assinatura`),
  KEY `id_assinatura_cliente` (`id_assinatura_cliente`),
  KEY `lixeira` (`lixeira`),
  KEY `id_cartao` (`id_cartao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_assinaturas_assinaturas_cartoes_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_assinaturas_assinaturas_cartoes_log` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `id_assinatura` int(11) DEFAULT NULL,
  `id_conta_rec` bigint(20) DEFAULT NULL,
  `id_pagamento` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_retorno` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `retorno_operadora` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor` decimal(16,2) DEFAULT NULL,
  `data_cad_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_assinaturas_assinaturas_cupons`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_assinaturas_assinaturas_cupons` (
  `id_assinatura_cupom` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_assinatura` int(11) NOT NULL,
  `id_cupom` int(11) NOT NULL,
  `nome_cupom` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_cupom` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `duracao_isencao` tinyint(1) NOT NULL,
  `valor_desconto_recorrencia` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tipo_desconto_recorrencia` enum('P','F') COLLATE utf8mb4_unicode_ci NOT NULL,
  `duracao_desconto` tinyint(1) NOT NULL,
  `valor_desconto_adesao` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tipo_desconto_adesao` enum('P','F') COLLATE utf8mb4_unicode_ci NOT NULL,
  `qtde_parcelas_adesao` tinyint(1) NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_assinatura_cupom`),
  KEY `id_cupom` (`id_cupom`),
  KEY `id_assinatura` (`id_assinatura`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_assinaturas_assinaturas_planos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_assinaturas_assinaturas_planos` (
  `id_assinatura_plano` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_assinatura` int(11) NOT NULL,
  `id_plano` int(11) NOT NULL,
  `valor_plano` decimal(10,2) NOT NULL DEFAULT '0.00',
  `qtde_parcelas` tinyint(1) NOT NULL DEFAULT '0',
  `condicao_pag` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `data_cancelamento` datetime DEFAULT NULL,
  `data_vigencia` datetime DEFAULT NULL,
  PRIMARY KEY (`id_assinatura_plano`),
  KEY `id_plano` (`id_plano`),
  KEY `data_cancelamento` (`data_cancelamento`),
  KEY `id_assinatura` (`id_assinatura`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_assinaturas_assinaturas_planos_adicionais`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_assinaturas_assinaturas_planos_adicionais` (
  `id_assinatura_plano_adicional` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_assinatura` int(11) NOT NULL,
  `id_plano` int(11) NOT NULL,
  `id_servico` bigint(20) NOT NULL,
  `id_recorrente_adicional` bigint(20) NOT NULL,
  PRIMARY KEY (`id_assinatura_plano_adicional`),
  KEY `id_plano` (`id_plano`),
  KEY `id_ped_servico` (`id_recorrente_adicional`),
  KEY `id_assinatura` (`id_assinatura`),
  KEY `id_servico` (`id_servico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_assinaturas_assinaturas_planos_faturas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_assinaturas_assinaturas_planos_faturas` (
  `id_assinatura_plano_fatura` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_assinatura` int(11) NOT NULL,
  `id_assinatura_cliente` int(11) NOT NULL,
  `id_plano` int(11) NOT NULL,
  `id_conta_rec` bigint(20) NOT NULL,
  `primeira_fatura` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_assinatura_plano_fatura`),
  KEY `id_assinatura_cliente` (`id_assinatura_cliente`),
  KEY `id_assinatura` (`id_assinatura`),
  KEY `id_plano` (`id_plano`),
  KEY `id_conta_rec` (`id_conta_rec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_assinaturas_assinaturas_planos_servicos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_assinaturas_assinaturas_planos_servicos` (
  `id_assinatura_plano_servico` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_assinatura` int(11) NOT NULL,
  `id_plano` int(11) NOT NULL,
  `id_servico` bigint(20) NOT NULL,
  `id_ped_servico` bigint(20) NOT NULL,
  PRIMARY KEY (`id_assinatura_plano_servico`),
  KEY `id_plano` (`id_plano`),
  KEY `id_ped_servico` (`id_ped_servico`),
  KEY `id_assinatura` (`id_assinatura`),
  KEY `id_servico` (`id_servico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_assinaturas_clientes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_assinaturas_clientes` (
  `id_assinatura_cliente` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_cliente` tinyint(1) NOT NULL DEFAULT '1',
  `verificado` tinyint(1) NOT NULL DEFAULT '0',
  `data_cad_cliente` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_cliente` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_assinatura_cliente`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`),
  KEY `id_cliente` (`id_cliente`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_assinaturas_clientes_cartoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_assinaturas_clientes_cartoes` (
  `id_cartao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_assinatura_cliente` int(11) NOT NULL,
  `final_cartao` smallint(6) NOT NULL,
  `flag` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exp_month` tinyint(1) NOT NULL,
  `exp_year` smallint(6) NOT NULL,
  `token_cielo` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_cartao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_cartao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_cartao`),
  KEY `id_assinatura_cliente` (`id_assinatura_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_assinaturas_configuracoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_assinaturas_configuracoes` (
  `id_config` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `slug` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `titulo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inativar_assinatura` int(11) NOT NULL DEFAULT '0',
  `gerar_fatura` int(11) NOT NULL DEFAULT '0',
  `gerar_nfse` tinyint(1) NOT NULL DEFAULT '0',
  `gerar_os` tinyint(1) NOT NULL DEFAULT '0',
  `itemLista_servico` smallint(6) DEFAULT NULL,
  `natureza_pedido` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `local_prestacao` tinyint(1) NOT NULL DEFAULT '0',
  `valor_aliquota` decimal(10,2) NOT NULL DEFAULT '0.00',
  `reter_iss` tinyint(1) NOT NULL DEFAULT '0',
  `confirmacao_email` tinyint(1) NOT NULL DEFAULT '1',
  `url_contratacao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notificar_contratacao` tinyint(1) NOT NULL DEFAULT '1',
  `notificar_contratacao_cliente` tinyint(1) NOT NULL DEFAULT '1',
  `mensagem_contratacao_cliente` text COLLATE utf8mb4_unicode_ci,
  `habilitar_migracao` tinyint(1) NOT NULL DEFAULT '1',
  `url_migracao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notificar_migracao` tinyint(1) NOT NULL DEFAULT '0',
  `notificar_migracao_cliente` tinyint(1) NOT NULL DEFAULT '1',
  `habilitar_cancelamento` tinyint(1) NOT NULL DEFAULT '1',
  `url_cancelamento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notificar_cancelamento` tinyint(1) NOT NULL DEFAULT '1',
  `notificar_cancelamento_cliente` tinyint(1) NOT NULL DEFAULT '1',
  `integrado_vhdesk` tinyint(1) NOT NULL DEFAULT '0',
  `mensagem_cancelamento_cliente` text COLLATE utf8mb4_unicode_ci,
  `habilitar_boleto` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `id_banco_cad` int(11) NOT NULL DEFAULT '0',
  `habilitar_cielo` tinyint(1) NOT NULL DEFAULT '0',
  `cielo_sandbox` tinyint(1) DEFAULT '0',
  `cielo_merchant_id` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cielo_merchant_key` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url_webhook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_config` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_config` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_config`),
  UNIQUE KEY `ux_slug` (`slug`),
  KEY `id_empresa` (`id_empresa`),
  KEY `ix_slug` (`slug`),
  KEY `id_banco_cad` (`id_banco_cad`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_assinaturas_configuracoes_campos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_assinaturas_configuracoes_campos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `nome_campo` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exibicao` tinyint(1) NOT NULL DEFAULT '1',
  `label` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_assinaturas_cupons`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_assinaturas_cupons` (
  `id_cupom` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `nome_cupom` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_cupom` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_desconto_recorrencia` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tipo_desconto_recorrencia` enum('P','F') COLLATE utf8mb4_unicode_ci NOT NULL,
  `duracao_desconto` tinyint(1) DEFAULT NULL,
  `isentar_valor` tinyint(1) NOT NULL DEFAULT '0',
  `valor_desconto_adesao` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tipo_desconto_adesao` enum('P','F') COLLATE utf8mb4_unicode_ci NOT NULL,
  `qtde_parcela_adesao` tinyint(1) DEFAULT '0',
  `limitar_cupom` tinyint(1) NOT NULL DEFAULT '0',
  `qtde_utilizacoes` smallint(6) DEFAULT NULL,
  `data_validade` datetime DEFAULT NULL,
  `limitar_planos` tinyint(1) NOT NULL DEFAULT '0',
  `data_cad_cupom` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_cupom` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_cupom`),
  UNIQUE KEY `uq_id_empresa_codigo_cupom` (`id_empresa`,`codigo_cupom`),
  KEY `idx_id_empresa_data_cad_cupom_lixeira` (`id_empresa`,`data_cad_cupom`,`lixeira`),
  KEY `idx_id_empresa_lixeira` (`id_empresa`,`lixeira`),
  KEY `idx_id_empresa_codigo_cupom_lixeira` (`id_empresa`,`codigo_cupom`,`lixeira`),
  KEY `idx_id_empresa_nome_cupom_lixeira` (`id_empresa`,`nome_cupom`,`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_assinaturas_cupons_duracoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_assinaturas_cupons_duracoes` (
  `id_cupom_duracao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_cupom` int(11) NOT NULL,
  `condicao_pag` tinyint(1) DEFAULT NULL,
  `duracao` smallint(6) DEFAULT '0',
  PRIMARY KEY (`id_cupom_duracao`),
  KEY `id_cupom` (`id_cupom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_assinaturas_cupons_isencoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_assinaturas_cupons_isencoes` (
  `id_cupom_isencao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_cupom` int(11) NOT NULL,
  `condicao_pag` tinyint(1) DEFAULT NULL,
  `duracao` smallint(6) DEFAULT '0',
  PRIMARY KEY (`id_cupom_isencao`),
  KEY `id_cupom` (`id_cupom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_assinaturas_cupons_planos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_assinaturas_cupons_planos` (
  `id_cupom_plano` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_cupom` int(11) NOT NULL,
  `id_plano` int(11) NOT NULL,
  PRIMARY KEY (`id_cupom_plano`),
  KEY `id_cupom` (`id_cupom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_assinaturas_grades`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_assinaturas_grades` (
  `id_grade` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `nome_grade` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descricao_grade` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `padrao` tinyint(1) NOT NULL DEFAULT '0',
  `status_grade` tinyint(1) NOT NULL DEFAULT '1',
  `usuario_cad_grade` int(11) NOT NULL DEFAULT '0',
  `data_cad_grade` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_grade` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_grade`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_assinaturas_logs`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_assinaturas_logs` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `id_entidade` int(11) NOT NULL DEFAULT '0',
  `metodo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nome_rota` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request` text COLLATE utf8mb4_unicode_ci,
  `response` text COLLATE utf8mb4_unicode_ci,
  `status` int(11) DEFAULT NULL,
  `data_cad_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_assinaturas_planos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_assinaturas_planos` (
  `id_plano` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_grade` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `nome_plano` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descricao_plano` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ordem_plano` int(11) NOT NULL DEFAULT '0',
  `valor_adesao` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tipo_adesao` tinyint(1) NOT NULL DEFAULT '1',
  `qtde_parcelas` tinyint(1) NOT NULL DEFAULT '1',
  `condicoes_pag` char(8) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1,3,6,12',
  `status_plano` tinyint(1) NOT NULL DEFAULT '1',
  `recomendado` tinyint(1) NOT NULL DEFAULT '1',
  `status_recorrencia` tinyint(1) NOT NULL DEFAULT '1',
  `usuario_cad_plano` int(11) NOT NULL DEFAULT '0',
  `data_cad_plano` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_plano` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_plano`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_grade` (`id_grade`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_assinaturas_planos_adicionais`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_assinaturas_planos_adicionais` (
  `id_adicional` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_plano` int(11) NOT NULL,
  `id_servico` bigint(20) NOT NULL DEFAULT '0',
  `nome_servico` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantidade` int(11) NOT NULL DEFAULT '1',
  `valor_unit` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_adicional`),
  KEY `id_plano` (`id_plano`),
  KEY `id_servico` (`id_servico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_assinaturas_planos_desconto_periodicidade`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_assinaturas_planos_desconto_periodicidade` (
  `id_desconto` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_plano` int(11) DEFAULT NULL,
  `periodicidade` tinyint(1) DEFAULT NULL,
  `desconto` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id_desconto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_assinaturas_planos_servicos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_assinaturas_planos_servicos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_plano` int(11) NOT NULL,
  `id_servico` bigint(20) NOT NULL DEFAULT '0',
  `nome_servico` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantidade` int(11) NOT NULL DEFAULT '1',
  `valor_unit` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `id_plano` (`id_plano`),
  KEY `id_servico` (`id_servico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_ativar_beta`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_ativar_beta` (
  `id_beta` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `funcao` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `habilitar` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_beta` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_beta` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_beta`),
  KEY `id_empresa` (`id_empresa`,`habilitar`,`funcao`,`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_avisos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_avisos` (
  `id_aviso` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT '0',
  `para_aviso` bigint(20) DEFAULT '0',
  `para_aviso_usuario` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assunto_aviso` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc_aviso` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_aviso` tinyint(1) NOT NULL DEFAULT '1',
  `data_inicio_aviso` date NOT NULL,
  `data_final_aviso` date NOT NULL,
  `status_aviso` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Ativo',
  `data_cad_aviso` datetime NOT NULL,
  `data_mod_aviso` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_aviso`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_backup_nfe_historico`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_backup_nfe_historico` (
  `id_backup` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `nome_arquivo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usuario_empresa` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_backup` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_backup`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_bens`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_bens` (
  `id_bem` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `descricao_bem` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_bem` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `marca_bem` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `id_setor` int(11) NOT NULL,
  `nfe_bem` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numero_serie_bem` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_compra_bem` date NOT NULL,
  `data_implementacao` date DEFAULT NULL,
  `valor_bem` decimal(10,2) NOT NULL,
  `vida_util_bem` int(11) NOT NULL,
  `depreciacao_bem` decimal(10,1) NOT NULL,
  `fornecedor_bem` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `garantia_bem` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `funcionario_bem` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estado_bem` enum('Novo','Usado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Novo',
  `data_termino_garantia` date NOT NULL,
  `notificar` int(11) NOT NULL DEFAULT '0',
  `observacao_bem` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_bem` date NOT NULL,
  `data_mod_bem` date NOT NULL,
  `status_bem` enum('Ativo','Inativo','Manutenção') COLLATE utf8mb4_unicode_ci NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_bem`),
  KEY `lixeira` (`lixeira`),
  KEY `id_setor` (`id_setor`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_categoria` (`id_categoria`),
  KEY `garantia_bem` (`garantia_bem`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_bens_categorias`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_bens_categorias` (
  `id_categoria` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `nome_categoria` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_categoria` date DEFAULT NULL,
  `data_mod_categoria` date DEFAULT NULL,
  `status_categoria` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci DEFAULT 'Ativo',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_categoria`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_bens_setores`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_bens_setores` (
  `id_setor` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `nome_setor` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `responsavel_setor` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_setor` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci DEFAULT 'Ativo',
  `data_cad_setor` date DEFAULT NULL,
  `data_mod_setor` date DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_setor`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_boletofacil`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_boletofacil` (
  `id_favorecido` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_favorecido_boletofacil` int(11) NOT NULL DEFAULT '0',
  `tipo_favorecido` enum('PJ','PF') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PJ',
  `fantasia_favorecido` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_empresa` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cnpj_favorecido` char(18) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_favorecido` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `endereco_favorecido` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numero_favorecido` char(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `complemento_favorecido` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_favorecido` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cep_favorecido` char(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cidade_favorecido` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cidade_cod_favorecido` int(11) NOT NULL,
  `estado_favorecido` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_conta_favorecido` char(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cnpj_conta_favorecido` char(18) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_conta_favorecido` enum('CHECKING','SAVINGS') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CHECKING',
  `codigo_conta_favorecido` char(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `agencia_favorecido` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conta_favorecido` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numero_banco_favorecido` char(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `multa_boleto` decimal(10,2) DEFAULT '2.00',
  `juros_boleto` decimal(11,3) DEFAULT '0.033',
  `percentual_desconto` decimal(10,2) NOT NULL,
  `aposvencimento_boleto` int(11) DEFAULT '10',
  `limite_desconto` int(11) NOT NULL,
  `categoria_conta_favorecido` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_nascimento_favorecido` date NOT NULL,
  `senha_favorecido` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone_favorecido` char(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `representante_favorecido` char(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cpf_representante` char(18) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_nascimento_representante` date NOT NULL,
  `linhas_negocio` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token_favorecido` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_favorecido` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `atividade_comercial` int(11) NOT NULL,
  `saldo_favorecido` decimal(10,2) DEFAULT '0.00',
  `saldo_retido_favorecido` decimal(10,2) DEFAULT '0.00',
  `saldo_liberado_favorecido` decimal(10,2) DEFAULT '0.00',
  `taxa_transferencia_favorecido` decimal(10,2) DEFAULT '1.00',
  `data_cad_favorecido` datetime NOT NULL,
  `data_mod_favorecido` datetime DEFAULT NULL,
  `usuario_cad_favorecido` int(11) NOT NULL DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_favorecido`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_favorecido_boletofacil` (`id_favorecido_boletofacil`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_boletofacil_boletos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_boletofacil_boletos` (
  `id_boleto` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_favorecido` int(11) NOT NULL DEFAULT '0',
  `token_geracao` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chave_boleto` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_conta_rec` bigint(20) unsigned NOT NULL DEFAULT '0',
  `descricao_boleto` char(115) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referencia_boleto` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_boleto` decimal(10,2) NOT NULL,
  `vencimento_boleto` date NOT NULL,
  `multa_boleto` decimal(10,2) NOT NULL,
  `juros_boleto` decimal(10,2) NOT NULL,
  `valor_desconto` decimal(10,2) NOT NULL,
  `comprador_nome` char(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comprador_cnpjcpf` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comprador_email` char(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comprador_telefone` char(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comprador_datanasc` date NOT NULL,
  `comprador_endereco` char(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comprador_numero` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comprador_complemento` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comprador_cidade` char(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comprador_estado` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comprador_cep` char(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_boleto` datetime NOT NULL,
  `boletofacil_codigo` int(11) NOT NULL DEFAULT '0',
  `boletofacil_link` char(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `boletofacil_linhadigitavel` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `boletofacil_codigo_pag` int(11) NOT NULL,
  `boletofacil_valor_pago` decimal(10,2) NOT NULL,
  `boletofacil_data_pagamento` date NOT NULL,
  `boletofacil_taxas` decimal(10,2) NOT NULL,
  `liquidado_boleto` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_boleto`),
  KEY `id_favorecido` (`id_favorecido`),
  KEY `liquidado_boleto` (`liquidado_boleto`),
  KEY `id_empresa_id_conta_rec` (`id_empresa`,`id_conta_rec`),
  KEY `id_empresa` (`id_empresa`),
  KEY `boletofacil_codigo` (`boletofacil_codigo`),
  KEY `id_conta_rec` (`id_conta_rec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_boletofacil_carnet`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_boletofacil_carnet` (
  `id_carnet_boletofacil` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_conta_rec` int(11) NOT NULL,
  `carnet_boletofacil` int(11) NOT NULL,
  `boleto_original` int(11) NOT NULL,
  `hash_boleto` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_carnet_boletofacil`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_carnet_boletofacil` (`id_carnet_boletofacil`),
  KEY `carnet_boletofacil` (`carnet_boletofacil`),
  KEY `id_conta_rec` (`id_conta_rec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_boletofacil_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_boletofacil_log` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `data_log` datetime DEFAULT NULL,
  `desc_log` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_log` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_log` enum('Success','Error') COLLATE utf8mb4_unicode_ci DEFAULT 'Success',
  PRIMARY KEY (`id_log`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_boletofacil_transferencias`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_boletofacil_transferencias` (
  `id_transferencia` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_favorecido` int(11) NOT NULL DEFAULT '0',
  `token_geracao` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_transferir` decimal(10,2) NOT NULL,
  `usuario_transferencia` int(11) NOT NULL,
  `data_cad_transferencia` datetime NOT NULL,
  PRIMARY KEY (`id_transferencia`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_favorecido` (`id_favorecido`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_cobrancas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_cobrancas` (
  `id_cobranca` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `boleto` tinyint(1) NOT NULL DEFAULT '1',
  `conta` tinyint(1) NOT NULL DEFAULT '0',
  `duplicata` tinyint(1) NOT NULL DEFAULT '0',
  `enviar_aviso` tinyint(1) NOT NULL DEFAULT '1',
  `enviar_aviso_anexo` tinyint(1) NOT NULL DEFAULT '1',
  `enviar_atraso` tinyint(1) NOT NULL DEFAULT '1',
  `enviar_atraso_anexo` tinyint(1) NOT NULL DEFAULT '1',
  `dias_aviso` tinyint(1) NOT NULL DEFAULT '5',
  `dias_atraso` tinyint(1) NOT NULL DEFAULT '5',
  `enviar_sms_aviso` tinyint(1) NOT NULL DEFAULT '1',
  `enviar_sms_atraso` tinyint(1) NOT NULL DEFAULT '1',
  `enviar_email_aviso` tinyint(1) NOT NULL DEFAULT '1',
  `enviar_email_atraso` tinyint(1) NOT NULL DEFAULT '1',
  `texto_sms_aviso` char(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Segue boleto para pagamento ##LINKBOLETO## referente a ##REMETENTE##',
  `texto_sms_atraso` char(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Segue boleto para pagamento ##LINKBOLETO## referente a ##REMETENTE##',
  `texto_email_aviso` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Segue abaixo a cobrança, em caso de dúvidas, entre em contato conosco.',
  `texto_email_atraso` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Segue abaixo a cobrança, em caso de dúvidas, entre em contato conosco.',
  `email_resposta` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_cobranca`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_cobrancas_181165`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_cobrancas_181165` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `descricao` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_log` (`id_log`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_cobrancas_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_cobrancas_log` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `descricao` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_envio` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_log` (`id_log`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_cotacoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_cotacoes` (
  `id_cotacao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_pedido` int(11) NOT NULL DEFAULT '0',
  `referencia_cotacao` char(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `obs_cotacao` longtext COLLATE utf8mb4_unicode_ci,
  `obs_interno_cotacao` longtext COLLATE utf8mb4_unicode_ci,
  `status_cotacao` char(20) COLLATE utf8mb4_unicode_ci DEFAULT 'Em Aberto',
  `usuario_cad_cotacao` bigint(20) DEFAULT '0',
  `oc_emitida` tinyint(1) DEFAULT '0',
  `data_cad_cotacao` datetime NOT NULL,
  `data_mod_cotacao` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_cotacao`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_cotacoes_fornecedores`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_cotacoes_fornecedores` (
  `id_cot_fornecedor` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_cotacao` int(11) NOT NULL DEFAULT '0',
  `id_fornecedor` bigint(20) unsigned NOT NULL DEFAULT '0',
  `nome_fornecedor` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_fornecedor` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contato_fornecedor` char(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_cot_fornecedor`),
  KEY `id_fornecedor` (`id_fornecedor`),
  KEY `id_cotacao` (`id_cotacao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_cotacoes_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_cotacoes_produtos` (
  `id_cot_produto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_cotacao` int(11) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `desc_produto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unidade_produto` char(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `qtde_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_unit_atual` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_unit_sugerido` decimal(10,4) NOT NULL DEFAULT '0.0000',
  PRIMARY KEY (`id_cot_produto`),
  KEY `id_pedido` (`id_cotacao`),
  KEY `id_produto` (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_cotacoes_respostas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_cotacoes_respostas` (
  `id_resposta` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_cotacao` int(11) NOT NULL DEFAULT '0',
  `id_cot_fornecedor` int(11) NOT NULL DEFAULT '0',
  `valor_total_produtos` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_total_frete` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_total_desconto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_total_cotacao` decimal(10,2) NOT NULL DEFAULT '0.00',
  `peso_total_cotacao` decimal(10,2) NOT NULL DEFAULT '0.00',
  `condicao_pagamento` tinyint(1) NOT NULL DEFAULT '0',
  `obs_resposta` longtext COLLATE utf8mb4_unicode_ci,
  `prazo_resposta` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_resposta` datetime NOT NULL,
  PRIMARY KEY (`id_resposta`),
  KEY `id_cotacao` (`id_cotacao`),
  KEY `id_cot_fornecedor` (`id_cot_fornecedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_cotacoes_respostas_parcelas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_cotacoes_respostas_parcelas` (
  `id_parcela` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_resposta` bigint(20) DEFAULT '0',
  `data_parcela` date DEFAULT NULL,
  `valor_parcela` decimal(10,2) DEFAULT '0.00',
  `forma_pagamento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes_parcela` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_parcela`),
  KEY `id_pedido` (`id_resposta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_cotacoes_respostas_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_cotacoes_respostas_produtos` (
  `id_resposta` int(11) NOT NULL DEFAULT '0',
  `id_cot_produto` int(11) NOT NULL DEFAULT '0',
  `valor_unitario_resposta` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_total_resposta` decimal(10,2) NOT NULL DEFAULT '0.00',
  KEY `id_cot_produto` (`id_cot_produto`),
  KEY `id_resposta` (`id_resposta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_cotacoes_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_cotacoes_status` (
  `id_status` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_cotacao` bigint(20) DEFAULT '0',
  `data_status` date DEFAULT NULL,
  `obs_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_status` char(15) COLLATE utf8mb4_unicode_ci DEFAULT 'Em Aberto',
  PRIMARY KEY (`id_status`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_empresa_id_cotacao` (`id_empresa`,`id_cotacao`),
  KEY `id_orcamento` (`id_cotacao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_etiquetas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_etiquetas` (
  `id_etiqueta` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `padrao_etiqueta` tinyint(1) NOT NULL DEFAULT '0',
  `nome_etiqueta` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `margem_esquerda` decimal(10,2) NOT NULL DEFAULT '0.00',
  `margem_direita` decimal(10,2) NOT NULL DEFAULT '0.00',
  `margem_superior` decimal(10,2) NOT NULL DEFAULT '0.00',
  `largura_etiqueta` decimal(10,2) NOT NULL DEFAULT '0.00',
  `altura_etiqueta` decimal(10,2) NOT NULL DEFAULT '0.00',
  `altura_texto` decimal(10,2) DEFAULT '3.60',
  `fonte_etiqueta` char(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'helvetica',
  `fonte_tamanho` tinyint(1) NOT NULL DEFAULT '8',
  `qtde_caracteres` smallint(6) NOT NULL,
  `colunas_etiqueta` tinyint(1) NOT NULL DEFAULT '3',
  `linhas_pagina` tinyint(1) NOT NULL DEFAULT '10',
  `topo_etiqueta` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_barra` tinyint(1) NOT NULL DEFAULT '0',
  `valor_etiqueta` tinyint(1) NOT NULL DEFAULT '1',
  `codigo_produto_etiqueta` tinyint(1) NOT NULL DEFAULT '1',
  `nome_produto_etiqueta` tinyint(1) NOT NULL DEFAULT '1',
  `quantidade_produto_etiqueta` tinyint(1) NOT NULL DEFAULT '1',
  `altura_cod_barras` decimal(10,2) DEFAULT '0.00',
  `data_cad_etiqueta` datetime NOT NULL,
  `data_mod_etiqueta` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_etiqueta`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_etiquetas_padroes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_etiquetas_padroes` (
  `id_padrao` tinyint(1) NOT NULL,
  `nome_padrao` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_etiqueta` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `margem_esquerda` decimal(10,2) NOT NULL DEFAULT '0.00',
  `margem_direita` decimal(10,2) NOT NULL DEFAULT '0.00',
  `margem_superior` decimal(10,2) NOT NULL DEFAULT '0.00',
  `largura_etiqueta` decimal(10,2) NOT NULL DEFAULT '0.00',
  `altura_etiqueta` decimal(10,2) NOT NULL DEFAULT '0.00',
  `fonte_etiqueta` char(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'helvetica',
  `fonte_tamanho` tinyint(1) NOT NULL DEFAULT '8',
  `colunas_etiqueta` tinyint(1) NOT NULL DEFAULT '3',
  `linhas_pagina` tinyint(1) NOT NULL DEFAULT '10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_expedicao`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_expedicao` (
  `id_expedicao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_registro` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_transportadora` int(11) NOT NULL DEFAULT '0',
  `forma_envio` enum('Transportadora','Correios') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Transportadora',
  `tipo_venda` enum('NF','Pedido') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NF',
  `data_emissao` datetime NOT NULL,
  `status_expedicao` enum('Aberto','Andamento','Cancelado','Concluido') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Aberto',
  `lixeira_expedicao` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_expedicao`),
  KEY `id_registro` (`id_registro`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_expedicao_config`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_expedicao_config` (
  `id_empresa` int(11) DEFAULT NULL,
  `enviar_expedicao` enum('Pedido','NF') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `declarar_valor` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numeracao_expedicao` int(11) DEFAULT '0',
  `etiqueta_cliente` tinyint(1) DEFAULT '0',
  `etiqueta_volume` tinyint(1) DEFAULT '0',
  `etiqueta_transporte` tinyint(1) DEFAULT '0',
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_expedicao_embalagens`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_expedicao_embalagens` (
  `id_embalagem` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `tipo_embalagem` enum('Envelope','Pacote','Cilindro') COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_embalagem` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `altura_embalagem` double(10,3) NOT NULL,
  `largura_embalagem` double(10,3) NOT NULL,
  `comprimento_embalagem` double(10,3) NOT NULL,
  `diametro_embalagem` double(10,3) NOT NULL,
  PRIMARY KEY (`id_embalagem`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_expedicao_etiquetas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_expedicao_etiquetas` (
  `id_etiqueta` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cod_pimaco` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `espacamento_horizontal` double(5,2) NOT NULL DEFAULT '0.00',
  `espacamento_vertical` double(5,2) NOT NULL DEFAULT '0.00',
  `largura` double(5,2) NOT NULL DEFAULT '0.00',
  `altura` double(5,2) NOT NULL DEFAULT '0.00',
  `margem_esquerda` double(5,2) NOT NULL DEFAULT '0.00',
  `margem_superior` double(5,2) NOT NULL DEFAULT '0.00',
  `qtde_colunas` int(11) NOT NULL DEFAULT '0',
  `qtde_linhas` int(11) NOT NULL DEFAULT '0',
  `tipo_etiqueta` enum('A4','Carta','Zebra') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'A4',
  `lixeira_etiqueta` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_etiqueta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_expedicao_objetos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_expedicao_objetos` (
  `id_objeto` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_expedicao` int(11) DEFAULT NULL,
  `id_venda` int(11) DEFAULT NULL,
  `tipo_venda` enum('Pedido','NF') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_rastreio` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url_rastreio` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cadastro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_objeto`),
  KEY `id_expedicao` (`id_expedicao`),
  KEY `id_venda` (`id_venda`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_expedicao_objetos_volumes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_expedicao_objetos_volumes` (
  `id_volume` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_objeto` int(11) DEFAULT NULL,
  `id_embalagem` int(11) DEFAULT NULL,
  `tipo_embalagem` enum('Envelope','Pacote','Cilindro','Personalizado') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `altura_embalagem` double(10,3) DEFAULT NULL,
  `peso_embalagem` double(10,3) DEFAULT NULL,
  `largura_embalagem` double(10,3) DEFAULT NULL,
  `comprimento_embalagem` double(10,3) DEFAULT NULL,
  `diametro_embalagem` double(10,3) DEFAULT NULL,
  `quantidade_volume` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_volume`),
  KEY `id_embalagem` (`id_embalagem`),
  KEY `id_objeto` (`id_objeto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_expedicao_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_expedicao_status` (
  `id_status` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT '0',
  `id_expedicao` int(11) DEFAULT '0',
  `data_status` date DEFAULT NULL,
  `obs_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_status` char(15) COLLATE utf8mb4_unicode_ci DEFAULT 'Aberto',
  PRIMARY KEY (`id_status`),
  KEY `id_empresa_id_expedicao` (`id_empresa`,`id_expedicao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_exten_config`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_exten_config` (
  `taxa_juros` decimal(10,6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_exten_contas_bancarias`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_exten_contas_bancarias` (
  `id_conta_bancaria` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned DEFAULT NULL,
  `id_banco_cad` int(10) unsigned DEFAULT NULL,
  `conta_padrao` tinyint(1) DEFAULT '0',
  `vinculado_cadastro` tinyint(1) DEFAULT '0',
  `data_cad_conta_bancaria` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_conta_bancaria` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_conta_bancaria`),
  UNIQUE KEY `unq_id_empresa_id_banco_cad` (`id_empresa`,`id_banco_cad`),
  KEY `idx_id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_exten_emitente`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_exten_emitente` (
  `id_exten` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `cnpj` char(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nome_completo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cpf` char(14) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefone_celular` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `cep` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nome_logradouro` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complemento` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro_distrito` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnh` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endereco` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contrato_social` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `situacao` enum('congelado','liberado') COLLATE utf8mb4_unicode_ci DEFAULT 'congelado',
  `integrado` tinyint(1) DEFAULT '0',
  `data_cad` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_exten`),
  KEY `idx_id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_exten_propostas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_exten_propostas` (
  `id_proposta` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `id_banco_cad` int(11) DEFAULT NULL,
  `valor_total` decimal(16,2) DEFAULT NULL,
  `valor_desembolso` decimal(16,2) DEFAULT NULL,
  `situacao` enum('analise','aceitacao','reprovado','rejeitado','contrato','liberacao','pago','pendente','cancelar') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'analise',
  `url_contrato` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `info` text COLLATE utf8mb4_unicode_ci,
  `data_cad_proposta` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_proposta` datetime NOT NULL,
  PRIMARY KEY (`id_proposta`),
  KEY `idx_id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_exten_propostas_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_exten_propostas_log` (
  `id_proposta_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_proposta` int(11) DEFAULT NULL,
  `id_empresa` int(11) DEFAULT NULL,
  `conteudo` text COLLATE utf8mb4_unicode_ci,
  `status` enum('sucesso','falha') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resposta` text COLLATE utf8mb4_unicode_ci,
  `code` smallint(6) DEFAULT NULL,
  `data_cad_payload` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_proposta_log`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_exten_propostas_recebiveis`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_exten_propostas_recebiveis` (
  `id_recebivel` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_proposta` int(11) NOT NULL,
  `id_conta_rec` int(11) NOT NULL,
  `n_documento_rec` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identificador` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nota_chave` char(44) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chave` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_emissao` datetime NOT NULL,
  `razao_cliente` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_nfe` enum('produto','servico') COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_total` decimal(16,2) DEFAULT NULL,
  `valor_pago_negociacao` decimal(16,2) DEFAULT NULL,
  `ambiente` tinyint(1) DEFAULT '1',
  `xml_enviado` tinyint(1) DEFAULT '0',
  `situacao` enum('deferido','indeferido','aprovado','rejeitado','pago','cancelado','provisionado','aceitacao','reprovado') COLLATE utf8mb4_unicode_ci DEFAULT 'deferido',
  PRIMARY KEY (`id_recebivel`),
  KEY `idx_id_proposta` (`id_proposta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_exten_tokens`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_exten_tokens` (
  `id_token` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_expiracao` datetime DEFAULT NULL,
  PRIMARY KEY (`id_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_exten_webhook_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_exten_webhook_log` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipo` enum('emitente','proposta') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `situacao` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conteudo` text COLLATE utf8mb4_unicode_ci,
  `xml_enviado` text COLLATE utf8mb4_unicode_ci,
  `code` smallint(6) DEFAULT NULL,
  `error` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funcionarios`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funcionarios` (
  `id_funcionario` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `nome_funcionario` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cpf_funcionario` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `matricula_funcionario` int(11) DEFAULT NULL,
  `rg_funcionario` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_emissao_rg` date DEFAULT NULL,
  `orgao_emissor_rg` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_nascimento_funcionario` date DEFAULT NULL,
  `local_nascimento_funcionario` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_funcionario` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci DEFAULT 'Ativo',
  `sexo_funcionario` enum('Masculino','Feminino') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nome_pai_funcionario` char(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nome_mae_funcionario` char(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes_funcionario` text COLLATE utf8mb4_unicode_ci,
  `fone_funcionario` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `celular_funcionario` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_funcionario` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ctps_funcionario` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serie_ctps_funcionario` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_expedicao_ctps` date DEFAULT NULL,
  `uf_ctps_funcionario` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pis_funcionario` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_cargo` int(11) DEFAULT NULL,
  `cbo_funcionario` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `departamento_funcionario` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_admissao_funcionario` date DEFAULT NULL,
  `data_demissao_funcionario` date DEFAULT NULL,
  `trabalho_inicio` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trabalho_termino` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `intervalo_inicio` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `intervalo_termino` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salario_funcionario` decimal(10,2) DEFAULT NULL,
  `banco_funcionario` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agencia_funcionario` char(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conta_funcionario` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep_funcionario` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endereco_funcionario` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_funcionario` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro_funcionario` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complemento_funcionario` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_funcionario` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_funcionario_cod` int(11) DEFAULT NULL,
  `uf_funcionario` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_funcionario` date DEFAULT NULL,
  `data_mod_funcionario` date DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_funcionario`),
  KEY `id_cargo` (`id_cargo`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funcionarios_anexos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funcionarios_anexos` (
  `id_anexo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_funcionario` int(11) NOT NULL,
  `usuario_anexo` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `caminho_anexo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_anexo` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tamanho_anexo` int(11) NOT NULL DEFAULT '0',
  `tipo_anexo` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_anexo` datetime NOT NULL,
  PRIMARY KEY (`id_anexo`),
  KEY `id_funcionario_anexo` (`id_funcionario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funcionarios_beneficios`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funcionarios_beneficios` (
  `id_beneficio` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_funcionario` int(11) DEFAULT NULL,
  `nome_beneficio` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_beneficio` decimal(10,2) DEFAULT NULL,
  `data_cad_beneficio` date DEFAULT NULL,
  PRIMARY KEY (`id_beneficio`),
  KEY `id_funcionario` (`id_funcionario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funcionarios_cargos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funcionarios_cargos` (
  `id_cargo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `nome_cargo` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salario_cargo` decimal(10,2) DEFAULT NULL,
  `descricao_cargo` longtext COLLATE utf8mb4_unicode_ci,
  `status_cargo` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci DEFAULT 'Ativo',
  `data_cad_cargo` date DEFAULT NULL,
  `data_mod_cargo` date DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_cargo`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funcionarios_contatos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funcionarios_contatos` (
  `id_contato` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_funcionario` int(11) NOT NULL,
  `nome_contato` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone_contato` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_contato` date NOT NULL,
  PRIMARY KEY (`id_contato`),
  KEY `id_funcionario` (`id_funcionario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funcionarios_dependentes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funcionarios_dependentes` (
  `id_dependente` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_funcionario` int(11) NOT NULL,
  `nome_dependente` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_dependente` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fone_dependente` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rg_dependente` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cpf_dependente` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_nascimento_dependente` date NOT NULL,
  `data_cad_dependente` date NOT NULL,
  PRIMARY KEY (`id_dependente`),
  KEY `id_funcionario_dependente` (`id_funcionario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funcionarios_ocorrencias`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funcionarios_ocorrencias` (
  `id_ocorrencia` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_funcionario` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `id_anexo` int(11) NOT NULL,
  `desc_ocorrencia` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_ocorrencia` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_ocorrencia`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_funcionario_ocorrencia` (`id_funcionario`),
  KEY `id_anexo` (`id_anexo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funil`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funil` (
  `id_funil` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `nome_funil` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cor_funil` char(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cinza',
  `tipo_funil` enum('Produtos','Servicos') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Produtos',
  `data_cad_funil` datetime NOT NULL,
  `data_mod_funil` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_funil`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funil_atividades`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funil_atividades` (
  `id_atividade` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `tipo_atividade` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icone_atividade` char(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `situacao_atividade` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_atividade`),
  UNIQUE KEY `id_empresa_tipo_atividade` (`id_empresa`,`tipo_atividade`),
  KEY `id_funil` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funil_campos_personalizados`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funil_campos_personalizados` (
  `id_campo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `nome_campo` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao_campo` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_campo` enum('Texto','Select') COLLATE utf8mb4_unicode_ci NOT NULL,
  `respostas_campo` mediumtext COLLATE utf8mb4_unicode_ci,
  `obrigatorio_campo` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_campo` datetime DEFAULT NULL,
  `data_mod_campo` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_campo`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funil_config`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funil_config` (
  `id_config` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `motivo_perda` tinyint(1) NOT NULL DEFAULT '0',
  `motivo_fecha` tinyint(1) NOT NULL DEFAULT '0',
  `data_mod_config` datetime NOT NULL,
  PRIMARY KEY (`id_config`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funil_etapas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funil_etapas` (
  `id_etapa` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_funil` int(11) NOT NULL DEFAULT '0',
  `nome_etapa` char(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordem_etapa` tinyint(1) NOT NULL DEFAULT '0',
  `data_cad_etapa` datetime NOT NULL,
  `data_mod_etapa` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_etapa`),
  KEY `id_funil` (`id_funil`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funil_metas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funil_metas` (
  `id_meta` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_funil` int(11) NOT NULL DEFAULT '0',
  `usuario_meta` int(11) NOT NULL DEFAULT '0',
  `tipo_meta` enum('valor','qtde') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'valor',
  `valor_meta` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `qtde_negocios` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ano_meta` date NOT NULL,
  `mes_meta` tinyint(3) unsigned NOT NULL,
  `periodo_meta` enum('mes','semana','dia') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'mes',
  `data_cad_meta` datetime NOT NULL,
  `data_mod_meta` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_meta`),
  KEY `lixeira` (`lixeira`),
  KEY `id_funil` (`id_funil`),
  KEY `usuario_meta` (`usuario_meta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funil_motivos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funil_motivos` (
  `id_motivo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `tipo_motivo` enum('Perdido','Fechado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Perdido',
  `desc_motivo` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_motivo` datetime NOT NULL,
  `data_mod_motivo` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_motivo`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funil_negocios`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funil_negocios` (
  `id_negocio` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_funil` int(11) NOT NULL DEFAULT '0',
  `titulo_negocio` char(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_cadastro` enum('Prospecto','Cliente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Prospecto',
  `id_cadastro` int(11) NOT NULL DEFAULT '0',
  `nome_cadastro` char(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_contato` int(11) NOT NULL DEFAULT '0',
  `nome_contato` char(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_negocio` decimal(10,2) NOT NULL DEFAULT '0.00',
  `data_fechamento` date NOT NULL,
  `data_finalizacao` date NOT NULL,
  `id_etapa` int(11) NOT NULL DEFAULT '0',
  `data_etapa_entrada` date NOT NULL,
  `status_negocio` enum('Aberto','Perdido','Fechado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Aberto',
  `status_negocio_desc` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario_cad_negocio` int(11) NOT NULL DEFAULT '0',
  `orcamento_emitido` int(11) NOT NULL DEFAULT '0',
  `orcamento_numero` int(11) NOT NULL DEFAULT '0',
  `os_emitido` int(11) NOT NULL DEFAULT '0',
  `os_numero` int(11) NOT NULL DEFAULT '0',
  `data_cad_negocio` datetime DEFAULT NULL,
  `data_mod_negocio` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_negocio`),
  KEY `id_funil` (`id_funil`),
  KEY `id_etapa` (`id_etapa`),
  KEY `usuario_cad_negocio` (`usuario_cad_negocio`),
  KEY `id_prospecto` (`id_cadastro`),
  KEY `lixeira` (`lixeira`),
  KEY `id_contato` (`id_contato`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funil_negocios_atividades`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funil_negocios_atividades` (
  `id_atividade` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_negocio` int(11) NOT NULL DEFAULT '0',
  `tipo_atividade` char(15) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Tarefa',
  `nome_atividade` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_cadastro` enum('Prospecto','Cliente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Prospecto',
  `id_cadastro` int(11) NOT NULL DEFAULT '0',
  `nome_cadastro` char(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_atividade` datetime NOT NULL,
  `duracao_atividade` time DEFAULT NULL,
  `descricao_atividade` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario_cad_atividade` int(11) NOT NULL DEFAULT '0',
  `usuario_atividade` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_atividade` enum('Planejado','Concluido') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Planejado',
  `data_cad_atividade` datetime NOT NULL,
  `data_mod_atividade` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_atividade`),
  KEY `id_negocio` (`id_negocio`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funil_negocios_etapas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funil_negocios_etapas` (
  `id_historico` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_negocio` int(11) NOT NULL DEFAULT '0',
  `id_etapa` int(11) NOT NULL DEFAULT '0',
  `idade_etapa` smallint(6) NOT NULL DEFAULT '0',
  `data_cad_historico` datetime NOT NULL,
  PRIMARY KEY (`id_historico`),
  KEY `id_etapa` (`id_etapa`),
  KEY `id_negocio` (`id_negocio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funil_negocios_historico`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funil_negocios_historico` (
  `id_historico` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_negocio` int(11) NOT NULL DEFAULT '0',
  `desc_historico` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `acao_historico` enum('movido','excluido','criado') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_historico` char(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario_cad_historico` int(11) NOT NULL DEFAULT '0',
  `usuario_historico` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_historico` datetime NOT NULL,
  PRIMARY KEY (`id_historico`),
  KEY `id_negocio` (`id_negocio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funil_prospectos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funil_prospectos` (
  `id_prospecto` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `tipo_prospecto` enum('PJ','PF') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PF',
  `nome_prospecto` char(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `endereco_prospecto` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_prospecto` char(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro_prospecto` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complemento_prospecto` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep_prospecto` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_prospecto` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_prospecto_cod` int(11) DEFAULT NULL,
  `uf_prospecto` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pais_prospecto` char(45) COLLATE utf8mb4_unicode_ci DEFAULT 'Brasil',
  `pais_prospecto_cod` char(4) COLLATE utf8mb4_unicode_ci DEFAULT '1058',
  `data_nasc_prospecto` date DEFAULT NULL,
  `site_prospecto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes_prospecto` longtext COLLATE utf8mb4_unicode_ci,
  `usuario_cad_prospecto` int(11) DEFAULT '0',
  `data_cad_prospecto` datetime DEFAULT NULL,
  `data_mod_prospecto` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_prospecto`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funil_prospectos_contatos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funil_prospectos_contatos` (
  `id_contato` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_prospecto` int(11) NOT NULL DEFAULT '0',
  `nome_contato` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone_contato` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_contato` char(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_contato`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_cliente` (`id_prospecto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funil_respostas_campos_personalizados`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funil_respostas_campos_personalizados` (
  `id_negocio` int(11) DEFAULT NULL,
  `id_campo` int(11) DEFAULT NULL,
  `resposta` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_resposta` datetime DEFAULT NULL,
  KEY `id_negocio` (`id_negocio`),
  KEY `id_campo` (`id_campo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funil_usuarios`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funil_usuarios` (
  `id_funil` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  KEY `id_usuario` (`id_usuario`),
  KEY `id_funil` (`id_funil`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_funil_usuarios_permissoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_funil_usuarios_permissoes` (
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `id_permissao` tinyint(1) NOT NULL DEFAULT '0',
  KEY `id_usuario` (`id_usuario`),
  KEY `id_permissao` (`id_permissao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_gerencianet`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_gerencianet` (
  `id_gerencianet` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `client_id` char(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_secret` char(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ambiente` tinyint(1) NOT NULL DEFAULT '0',
  `enviar_email` tinyint(1) NOT NULL DEFAULT '1',
  `mudar_ambiente` tinyint(1) NOT NULL DEFAULT '0',
  `multa_boleto` decimal(10,2) DEFAULT '2.00',
  `juros_boleto` decimal(11,3) DEFAULT '0.033',
  `percentual_desconto` decimal(10,2) DEFAULT '0.00',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_gerencianet`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_gerencianet_boletos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_gerencianet_boletos` (
  `id_boleto` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `charge_id` int(11) DEFAULT NULL,
  `barcode` char(54) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expire_at` date DEFAULT NULL,
  `status` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `amount_paid` decimal(10,2) DEFAULT '0.00',
  `payment` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `multa_boleto` decimal(10,2) DEFAULT NULL,
  `juros_boleto` decimal(10,2) DEFAULT NULL,
  `percentual_desconto` decimal(10,2) DEFAULT NULL,
  `comprador_nome` char(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comprador_cnpjcpf` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comprador_email` char(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comprador_telefone` char(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comprador_datanasc` date DEFAULT NULL,
  `comprador_endereco` char(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comprador_numero` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comprador_complemento` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comprador_cidade` char(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comprador_estado` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comprador_cep` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_boleto` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_boleto`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_empresa_charge_id` (`id_empresa`,`charge_id`),
  KEY `lixeira` (`lixeira`),
  KEY `charge_id` (`charge_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_gerencianet_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_gerencianet_log` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `data_log` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `desc_log` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_log` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_log` text COLLATE utf8mb4_unicode_ci,
  `status_log` enum('Success','Error') COLLATE utf8mb4_unicode_ci DEFAULT 'Success',
  PRIMARY KEY (`id_log`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_gerencianet_log_api`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_gerencianet_log_api` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `charge_id` int(11) DEFAULT NULL,
  `custom_id` int(11) DEFAULT '0',
  `code` int(11) DEFAULT NULL,
  `error` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `errorDescription` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_empresa_charge_id` (`id_empresa`,`charge_id`),
  KEY `charge_id` (`charge_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_gerencianet_token_notification`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_gerencianet_token_notification` (
  `id_notification` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `charge_id` int(11) DEFAULT NULL,
  `custom_id` int(11) DEFAULT NULL,
  `token_notification` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_notification`),
  KEY `charge_id` (`charge_id`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_empresa_charge_id` (`id_empresa`,`charge_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_gerencianet_transacoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_gerencianet_transacoes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `charge_id` int(11) DEFAULT NULL,
  `status` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `custom_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id`),
  KEY `charge_id` (`charge_id`),
  KEY `id_empresa_charge_id` (`id_empresa`,`charge_id`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_icmsst`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_icmsst` (
  `id_regra` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `tipo_regra` tinyint(1) NOT NULL DEFAULT '0',
  `ncm_regra` char(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `desc_produto` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_cliente` bigint(20) NOT NULL DEFAULT '0',
  `nome_cliente` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `obs_notafiscal` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `naodeduzir_icms` tinyint(1) NOT NULL DEFAULT '0',
  `cest_produto` char(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tributacao_icms` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_regra` datetime NOT NULL,
  `data_mod_regra` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_regra`),
  KEY `id_produto` (`id_produto`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`),
  KEY `ncm_icms` (`ncm_regra`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_icmsst_estados`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_icmsst_estados` (
  `id_estado` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_regra` bigint(20) NOT NULL DEFAULT '0',
  `estado_destino` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mva_original` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `mva_importacao` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `reducao_bc_icms` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `reducao_bc_icms_st` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `aliquota_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `aliquota_icms_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `iest` char(14) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_estado`),
  UNIQUE KEY `id_regra_estado_destino` (`id_regra`,`estado_destino`),
  KEY `id_empresa` (`id_regra`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_importacao`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_importacao` (
  `id_importacao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `numero_di` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_di` date NOT NULL,
  `adicoes_di` smallint(6) NOT NULL DEFAULT '0',
  `tipo_transporte` enum('AWB(Aereo)','BL(Maritimo)','CTRC(Terrestre)') COLLATE utf8mb4_unicode_ci NOT NULL,
  `uf_desembaraco` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `local_desembaraco` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_desembaraco` date NOT NULL,
  `aliq_diferenciada` tinyint(1) NOT NULL DEFAULT '0',
  `moeda_merc_tipo` enum('EURO','DOLAR','REAL') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'REAL',
  `moeda_merc_valor` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `moeda_frete_tipo` enum('EURO','DOLAR','REAL') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'REAL',
  `moeda_frete_valor` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `moeda_seguro_tipo` enum('EURO','DOLAR','REAL') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'REAL',
  `moeda_seguro_valor` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `frete_compoe` tinyint(1) NOT NULL DEFAULT '1',
  `peso_bruto_di` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `peso_liquido_di` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `qtde_frete_di` smallint(6) NOT NULL DEFAULT '0',
  `valor_custo_frete` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_mercadoria` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_seguro` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_desp_cif` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_total_cif` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_frete_unit` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_capatazia` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_siscomex` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_despachante` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_frete_nac_unit` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_variacao` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_dta` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_afrmm` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_armazenagem` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_frete_nac` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_despesas` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_multa` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_total_despesas` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_final_outros` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_embalagem` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_servico` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_outros` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_ii_bc` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_ii_aliq` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_ii_valor` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_ipi_bc` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_ipi_aliq` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_ipi_valor` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_pis_bc` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_pis_aliq` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_pis_valor` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_cofins_bc` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_cofins_aliq` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_cofins_valor` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_cofins_red` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_cofins_red_valor` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_icms_bc` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_icms_aliq` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_icms_valor` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_icms_red` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_icms_red_valor` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_total` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_custo_final` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_icms_total` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imposto_icms_total_red` decimal(10,4) NOT NULL DEFAULT '0.0000',
  PRIMARY KEY (`id_importacao`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_importacao_fornecedores`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_importacao_fornecedores` (
  `id_fornecedor` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_importacao` int(11) NOT NULL DEFAULT '0',
  `nome_fornecedor` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_fornecedor` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fatura_fornecedor` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_base_cp` date NOT NULL,
  `condicao_pagamento` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numero_contrato` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `centro_custos` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_centro_custos` int(11) NOT NULL,
  PRIMARY KEY (`id_fornecedor`),
  KEY `id_importacao` (`id_importacao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_importacao_parametros`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_importacao_parametros` (
  `id_empresa` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `frete_tipo` enum('Peso','Valor') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Peso',
  `frete_pis_cofins` tinyint(1) NOT NULL DEFAULT '1',
  `frete_icms` tinyint(1) NOT NULL DEFAULT '1',
  `seguro_tipo` enum('Peso','Valor') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Valor',
  `seguro_pis_cofins` tinyint(1) NOT NULL DEFAULT '1',
  `seguro_icms` tinyint(1) NOT NULL DEFAULT '1',
  `cif_tipo` enum('Peso','Valor') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Valor',
  `cif_pis_cofins` tinyint(1) NOT NULL DEFAULT '1',
  `cif_icms` tinyint(1) NOT NULL DEFAULT '1',
  `thc_tipo` enum('Peso','Valor') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Peso',
  `thc_pis_cofins` tinyint(1) NOT NULL DEFAULT '1',
  `thc_icms` tinyint(1) NOT NULL DEFAULT '1',
  `multa_tipo` enum('Peso','Valor') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Valor',
  `multa_pis_cofins` tinyint(1) NOT NULL DEFAULT '0',
  `multa_icms` tinyint(1) NOT NULL DEFAULT '0',
  `variacao_tipo` enum('Peso','Valor') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Valor',
  `variacao_pis_cofins` tinyint(1) NOT NULL DEFAULT '0',
  `variacao_icms` tinyint(1) NOT NULL DEFAULT '0',
  `fretenac_tipo` enum('Peso','Valor') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Valor',
  `fretenac_pis_cofins` tinyint(1) NOT NULL DEFAULT '0',
  `fretenac_icms` tinyint(1) NOT NULL DEFAULT '0',
  `fob_tipo` enum('Peso','Valor') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Valor',
  `fob_pis_cofins` tinyint(1) NOT NULL DEFAULT '0',
  `fob_icms` tinyint(1) NOT NULL DEFAULT '0',
  `dta_tipo` enum('Peso','Valor') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Valor',
  `dta_pis_cofins` tinyint(1) NOT NULL DEFAULT '0',
  `dta_icms` tinyint(1) NOT NULL DEFAULT '1',
  `siscomex_tipo` enum('Peso','Valor') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Valor',
  `siscomex_pis_cofins` tinyint(1) NOT NULL DEFAULT '1',
  `siscomex_icms` tinyint(1) NOT NULL DEFAULT '1',
  `afrmm_tipo` enum('Peso','Valor') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Valor',
  `afrmm_pis_cofins` tinyint(1) NOT NULL DEFAULT '0',
  `afrmm_icms` tinyint(1) NOT NULL DEFAULT '0',
  `despachante_tipo` enum('Peso','Valor') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Valor',
  `despachante_pis_cofins` tinyint(1) NOT NULL DEFAULT '0',
  `despachante_icms` tinyint(1) NOT NULL DEFAULT '0',
  `armazenagem_tipo` enum('Peso','Valor') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Valor',
  `armazenagem_pis_cofins` tinyint(1) NOT NULL DEFAULT '0',
  `armazenagem_icms` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_empresa`),
  UNIQUE KEY `id_empresa_unik` (`id_empresa`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_importacao_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_importacao_produtos` (
  `id_ped_produto` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_importacao` int(11) NOT NULL DEFAULT '0',
  `id_fornecedor` int(11) NOT NULL DEFAULT '0',
  `numero_adicao` tinyint(1) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `desc_produto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qtde_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `peso_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_unit_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_total_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_ped_produto`),
  KEY `id_fornecedor` (`id_fornecedor`),
  KEY `id_produto` (`id_produto`),
  KEY `id_importacao` (`id_importacao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_locacoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_locacoes` (
  `id_locacao` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL,
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_cliente` bigint(20) NOT NULL,
  `numeracao_locacao` int(11) NOT NULL,
  `id_lista` int(11) DEFAULT '0',
  `status_locacao` tinyint(1) NOT NULL DEFAULT '1',
  `nome_fornecedor` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_fornecedor` bigint(20) NOT NULL,
  `data_inicio` datetime NOT NULL,
  `data_termino` datetime NOT NULL,
  `data_confirmacao` date NOT NULL,
  `data_retirada` date NOT NULL,
  `tipo_retirada` tinyint(1) NOT NULL DEFAULT '1',
  `tipo_devolucao` tinyint(1) NOT NULL DEFAULT '1',
  `valor_desconto` decimal(10,6) NOT NULL,
  `valor_entrega` decimal(10,6) NOT NULL,
  `locacao_obs` varchar(800) COLLATE utf8mb4_unicode_ci NOT NULL,
  `locacao_obs_interna` varchar(800) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reservado` tinyint(1) NOT NULL DEFAULT '0',
  `id_os` bigint(20) DEFAULT '0',
  `id_orcamento` bigint(20) DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_locacao`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_fornecedor` (`id_fornecedor`),
  KEY `id_cliente` (`id_cliente`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_locacoes_adicionais`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_locacoes_adicionais` (
  `id_locacoes_adicionais` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_locacao` int(11) NOT NULL,
  `valor` decimal(10,6) NOT NULL DEFAULT '0.000000',
  `observacoes` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_locacoes_adicionais`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_locacoes_config`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_locacoes_config` (
  `id_config` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL,
  `reservar_estoque` tinyint(1) NOT NULL DEFAULT '1',
  `bloquear_reservados` tinyint(1) NOT NULL DEFAULT '1',
  `reservar_produtos_negativos` tinyint(1) NOT NULL DEFAULT '0',
  `numeracao` int(11) NOT NULL DEFAULT '0',
  `lista_preco_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id_config`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_locacoes_contratos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_locacoes_contratos` (
  `id_contrato` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '1',
  `titulo_contrato` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conteudo_contrato` longtext COLLATE utf8mb4_unicode_ci,
  `status_contrato` tinyint(1) NOT NULL DEFAULT '1',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_contrato`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_locacoes_movimentacoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_locacoes_movimentacoes` (
  `id_movimentacao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_locacao` int(11) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `tipo_estoque` tinyint(1) NOT NULL DEFAULT '0',
  `tipo_movimentacao` tinyint(1) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `valor_unitario` decimal(10,6) NOT NULL,
  `nome_produto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `data_movimentacao` date NOT NULL,
  `data_cadastro` datetime NOT NULL,
  `usuario_cad` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_movimentacao`),
  KEY `id_locacao` (`id_locacao`),
  KEY `tipo_estoque` (`tipo_estoque`),
  KEY `id_locacao_produto` (`id_produto`),
  KEY `data_movimentacao` (`data_movimentacao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_locacoes_ocorrencias`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_locacoes_ocorrencias` (
  `id_ocorrencia` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_locacao` bigint(20) NOT NULL,
  `id_empresa` bigint(20) NOT NULL,
  `data_ocorrencia` datetime NOT NULL,
  `status_ocorrencia` tinyint(1) NOT NULL,
  `obs_ocorrencia` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_ocorrencia`),
  KEY `id_locacao` (`id_locacao`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_locacoes_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_locacoes_produtos` (
  `id_locacao_produto` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_locacao` int(11) NOT NULL,
  `id_produto` int(11) DEFAULT NULL,
  `nome_produto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantidade` int(11) DEFAULT NULL,
  `reservado` tinyint(1) DEFAULT '0',
  `valor_unitario` decimal(14,6) DEFAULT NULL,
  `valor_reposicao` decimal(14,6) DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_locacao_produto`),
  KEY `id_produto` (`id_produto`),
  KEY `lixeria` (`lixeira`),
  KEY `id_locacao` (`id_locacao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_loja_aviseme`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_loja_aviseme` (
  `id_aviseme` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned NOT NULL,
  `id_produto` bigint(20) unsigned NOT NULL,
  `id_usuario` int(10) unsigned DEFAULT NULL,
  `nome_usuario` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_usuario` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone_usuario` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `data_cad_aviseme` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_aviseme` datetime DEFAULT NULL,
  PRIMARY KEY (`id_aviseme`),
  KEY `id_empresa_idx` (`id_empresa`),
  KEY `empresa_lixeira_idx` (`id_empresa`,`lixeira`),
  KEY `empresa_produto_lixeira_idx` (`id_empresa`,`id_produto`,`lixeira`),
  KEY `id_produto_idx` (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_loja_banners`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_loja_banners` (
  `id_foto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `alt_imagem` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foto_grande` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_foto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_foto` datetime DEFAULT NULL,
  PRIMARY KEY (`id_foto`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_loja_carrinho`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_loja_carrinho` (
  `id_carrinho` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `id_usuario` int(10) unsigned DEFAULT NULL,
  `id_session` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_produto` bigint(20) NOT NULL,
  `qtde_produto` smallint(6) NOT NULL,
  `data_carrinho` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_carrinho`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_produto` (`id_produto`),
  KEY `id_usuario_idx` (`id_usuario`),
  KEY `id_session` (`id_session`),
  KEY `lixeira` (`lixeira`),
  KEY `empresa_usuario_idx` (`id_empresa`,`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_loja_contatos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_loja_contatos` (
  `id_contato` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `id_usuario` int(10) unsigned DEFAULT NULL,
  `nome_contato` char(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_contato` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone_contato` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mensagem_contato` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_contato` datetime NOT NULL,
  `lido_contato` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_contato`),
  KEY `lixeira` (`lixeira`),
  KEY `empresa_usuario_idx` (`id_empresa`,`id_usuario`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario_idx` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_loja_cupom`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_loja_cupom` (
  `id_cupom` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `codigo_cupom` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_desconto_cupom` enum('Valor','Porc') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Valor',
  `valor_desconto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `validade_cupom` date NOT NULL,
  `status_cupom` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Inativo',
  `utilizado` smallint(6) NOT NULL DEFAULT '0',
  `data_cad_cupom` datetime NOT NULL,
  `data_mod_cupom` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_cupom`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_loja_dados`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_loja_dados` (
  `id_loja` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `nome_loja` char(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endereco_loja` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `titulo_loja` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao_loja` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_tags_loja` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo_loja` char(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descricao_postagem` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `favicon_loja` char(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `templete_loja` char(40) COLLATE utf8mb4_unicode_ci DEFAULT 'classico',
  `cor_principal` char(9) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cor_secundaria` char(9) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fundo_topo_imagem` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fundo_topo_cor` char(9) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'FFFFFF',
  `topo_fonte_cor` char(9) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '7d797d',
  `menu_fundo_cor` char(9) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '333333',
  `menu_fonte_cor` char(9) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fcfcfc',
  `fundo_corpo_imagem` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fundo_corpo_cor` char(9) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'FFFFFF',
  `fundo_rodape_imagem` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fundo_rodape_cor` char(9) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'c7c7c7',
  `fundo_rodape_fonte_cor` char(9) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '777777',
  `rodape_facebook` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rodape_twitter` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rodape_instagram` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fonte_tipo` char(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Verdana',
  `fonte_cor` char(9) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '7d797d',
  `fonte_tamanho` char(4) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '12px',
  `campo_fundo` char(9) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'FFFFFF',
  `campo_cor` char(9) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `campo_borda` char(4) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1px',
  `campo_borda_cor` char(9) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CCCCCC',
  `estoque_negativo` tinyint(1) NOT NULL DEFAULT '1',
  `conteudo_head` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_contato` varchar(400) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_pagDigital` tinyint(1) NOT NULL DEFAULT '1',
  `payment_pagDigital_login` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_pagDigital_token` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_cielo` tinyint(1) NOT NULL,
  `payment_cielo_merchantid` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_cielo_merchantkey` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_cielo_taxa_parcela` double(10,4) NOT NULL DEFAULT '0.0000',
  `payment_cielo_taxa_vista` double(10,4) NOT NULL DEFAULT '0.0000',
  `payment_cielo_max_parcela` int(11) NOT NULL DEFAULT '12',
  `payment_cielo_parcela_vendedor` int(11) NOT NULL DEFAULT '12',
  `payment_pagSeguro` tinyint(1) NOT NULL DEFAULT '0',
  `payment_pagSeguro_login` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_pagSeguro_token` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_mercadoPago` tinyint(1) NOT NULL DEFAULT '0',
  `payment_mercadoPago_login` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_mercadoPago_token` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_payu` tinyint(1) NOT NULL DEFAULT '0',
  `payment_payu_merchantid` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_payu_accountid` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_payu_apikey` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_paypal` tinyint(1) NOT NULL DEFAULT '0',
  `payment_paypal_clientid` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `payment_paypal_clientsecret` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `payment_boleto` tinyint(1) NOT NULL DEFAULT '0',
  `payment_boleto_banco` int(11) NOT NULL DEFAULT '0',
  `payment_boleto_prazo` tinyint(1) NOT NULL DEFAULT '7',
  `payment_deposito` tinyint(1) NOT NULL DEFAULT '0',
  `payment_deposito_info` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_deposito_banco` int(11) NOT NULL DEFAULT '0',
  `visivel_loja` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sim',
  `protocolo_https` tinyint(1) NOT NULL DEFAULT '0',
  `opcao_compra` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sim',
  `ocultar_valores` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `valor_minimo_compra` decimal(10,2) NOT NULL DEFAULT '0.00',
  `visivel_aviseme` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `visivel_mensagem` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `visivel_banner` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `banner_paginas` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `banner_tempo` smallint(6) NOT NULL DEFAULT '3000',
  `visivel_newsletter` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `frete_gratis` tinyint(1) NOT NULL DEFAULT '0',
  `frete_gratis_mensagem` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frete_gratis_valor` decimal(10,2) NOT NULL DEFAULT '0.00',
  `frete_gratis_peso` decimal(10,2) NOT NULL DEFAULT '0.00',
  `frete_gratis_prazo` tinyint(1) NOT NULL,
  `frete_retirar` tinyint(1) NOT NULL DEFAULT '0',
  `frete_correios` tinyint(1) NOT NULL DEFAULT '1',
  `frete_login` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `frete_senha` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `frete_sedex_cod` char(6) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '40010',
  `frete_pad_cod` char(6) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '41106',
  `frete_esedex_cod` char(6) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '40215',
  `braspress` tinyint(1) NOT NULL DEFAULT '0',
  `braspress_origem` char(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `braspress_tipofrete` tinyint(1) NOT NULL DEFAULT '1',
  `braspress_cnpj` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jadlog` tinyint(1) NOT NULL DEFAULT '0',
  `jadlog_modalidade` tinyint(1) NOT NULL DEFAULT '0',
  `jadlog_senha` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jadlog_cnpj` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jamef` tinyint(1) NOT NULL DEFAULT '0',
  `jamef_regiao` char(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jamef_estado` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jamef_cnpj` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mercadoenvio` tinyint(1) NOT NULL DEFAULT '0',
  `mercadoenvio_retirar` tinyint(1) NOT NULL DEFAULT '0',
  `mercadoenvio_gratis` int(11) NOT NULL DEFAULT '0',
  `emails_contato` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cupom_desconto` tinyint(1) NOT NULL DEFAULT '0',
  `paginacao_loja` enum('8','12','24','36','48','60') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '12',
  `data_cad_loja` datetime NOT NULL,
  `data_mod_loja` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_loja`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_loja_empresa_contato`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_loja_empresa_contato` (
  `id_empresa` int(11) NOT NULL,
  `razao_contato` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnpj_contato` varchar(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fone_contato` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_contato` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_contato` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endereco_contato` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  UNIQUE KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_loja_fretegratis`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_loja_fretegratis` (
  `id_freteg` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `nome_cidade` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_cidade` int(11) NOT NULL DEFAULT '0',
  `uf_cidade` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desconto_frete` decimal(10,2) NOT NULL DEFAULT '0.00',
  `despachante_frete` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `prazo_entrega` tinyint(1) NOT NULL DEFAULT '0',
  `valor_fixo` decimal(10,2) NOT NULL DEFAULT '0.00',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_freteg`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_loja_marketplace_empresa`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_loja_marketplace_empresa` (
  `id_marketplace_empresa` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `nome_empresa` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo_empresa` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_empresa` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ramo_empresa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descricao_empresa` text COLLATE utf8mb4_unicode_ci,
  `horario_empresa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep_empresa` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endereco_empresa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_empresa` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complemento_empresa` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro_empresa` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_empresa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uf_empresa` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefone_empresa` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_empresa` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website_empresa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_empresa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `data_cad_marketplace_empresa` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_marketplace_empresa` datetime DEFAULT NULL,
  PRIMARY KEY (`id_marketplace_empresa`),
  KEY `id_empresa_idx` (`id_empresa`),
  KEY `ramo_empresa_idx` (`ramo_empresa`),
  KEY `uf_empresa_idx` (`uf_empresa`),
  KEY `nome_empresa_idx` (`nome_empresa`),
  KEY `cidade_empresa_idx` (`cidade_empresa`),
  KEY `lixeira_idx` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_loja_newsletter`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_loja_newsletter` (
  `id_newsletter` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `id_usuario` int(10) unsigned DEFAULT NULL,
  `nome_cliente` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_cliente` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_newsletter`),
  KEY `id_empresa` (`id_empresa`),
  KEY `empresa_usuario_idx` (`id_empresa`,`id_usuario`),
  KEY `id_usuario_idx` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_loja_paginas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_loja_paginas` (
  `id_pagina` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `nome_pagina` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `titulo_pagina` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conteudo_pagina` mediumtext COLLATE utf8mb4_unicode_ci,
  `visivel_menu` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sim',
  `data_cad_pagina` datetime NOT NULL,
  `data_mod_pagina` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_pagina`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_loja_pedidos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_loja_pedidos` (
  `id_pedido` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `id_usuario` int(10) unsigned DEFAULT NULL,
  `id_transacao` char(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `data_transacao` date NOT NULL,
  `valor_desconto` decimal(10,2) NOT NULL,
  `valor_original` decimal(10,2) NOT NULL,
  `valor_loja` decimal(10,2) NOT NULL,
  `valor_total` decimal(10,2) NOT NULL,
  `tipo_pagamento` char(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parcelas` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_pedido` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_pedido_cod` tinyint(1) NOT NULL,
  `cliente_nome` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cliente_email` char(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cliente_rg` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cliente_cpf` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cliente_data_nascimento` char(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cliente_endereco` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cliente_complemento` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cliente_bairro` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cliente_cidade` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cliente_estado` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cliente_cep` char(9) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cliente_telefone` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_frete` decimal(10,2) NOT NULL,
  `tipo_frete` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_cupom` int(11) NOT NULL DEFAULT '0',
  `gateway` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `boleto_vencimento` date NOT NULL,
  `boleto_numero` int(11) NOT NULL,
  `referencia` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lido_pedido` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `pedido_emitido` tinyint(1) NOT NULL DEFAULT '0',
  `pedido_emitido_tipo` enum('Servico','Pedido') COLLATE utf8mb4_unicode_ci DEFAULT 'Pedido',
  `data_cad_pedido` datetime NOT NULL,
  PRIMARY KEY (`id_pedido`),
  KEY `id_empresa` (`id_empresa`),
  KEY `empresa_usuario_idx` (`id_empresa`,`id_usuario`),
  KEY `id_usuario_idx` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_loja_pedidos_mensagens`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_loja_pedidos_mensagens` (
  `id_mensagem` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_mensagem_parent` int(10) unsigned DEFAULT NULL,
  `id_empresa` int(11) NOT NULL,
  `id_pedido` bigint(20) DEFAULT NULL,
  `id_status` int(10) unsigned NOT NULL,
  `id_usuario` int(10) unsigned NOT NULL DEFAULT '0',
  `id_operador` int(10) unsigned NOT NULL DEFAULT '0',
  `assunto_mensagem` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `texto_mensagem` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_mensagem` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_mensagem` datetime DEFAULT NULL,
  PRIMARY KEY (`id_mensagem`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_loja_pedidos_mensagens_historico`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_loja_pedidos_mensagens_historico` (
  `id_historico` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_mensagem` int(10) unsigned NOT NULL,
  `id_status` int(10) unsigned NOT NULL,
  `id_usuario` int(10) unsigned NOT NULL DEFAULT '0',
  `id_operador` int(10) unsigned NOT NULL DEFAULT '0',
  `data_cad_historico` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_historico`),
  UNIQUE KEY `id_mensagem_id_status_id_usuario_id_operador_unq` (`id_mensagem`,`id_status`,`id_usuario`,`id_operador`),
  KEY `id_status_idx` (`id_status`),
  KEY `id_operador_idx` (`id_operador`),
  KEY `id_mensagem_id_usuario_idx` (`id_mensagem`,`id_usuario`),
  KEY `id_mensagem_id_operador_idx` (`id_mensagem`,`id_operador`),
  KEY `id_mensagem_idx` (`id_mensagem`),
  KEY `id_usuario_idx` (`id_usuario`),
  CONSTRAINT `app_loja_pedidos_mensagens_historico_id_mensagem_foreign` FOREIGN KEY (`id_mensagem`) REFERENCES `app_loja_pedidos_mensagens` (`id_mensagem`),
  CONSTRAINT `app_loja_pedidos_mensagens_historico_id_status_foreign` FOREIGN KEY (`id_status`) REFERENCES `app_loja_pedidos_mensagens_status` (`id_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_loja_pedidos_mensagens_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_loja_pedidos_mensagens_status` (
  `id_status` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descricao_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ativo_status` tinyint(1) NOT NULL DEFAULT '1',
  `ordem_status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_status`),
  KEY `ativo_status_idx` (`ativo_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_loja_pedidos_ocorrencias`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_loja_pedidos_ocorrencias` (
  `id_ocorrencia` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_pedido` bigint(20) NOT NULL DEFAULT '0',
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `publica_ocorrencia` tinyint(1) NOT NULL DEFAULT '0',
  `texto_ocorrencia` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `data_ocorrencia` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_ocorrencia`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_pedido` (`id_pedido`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_loja_pedidos_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_loja_pedidos_produtos` (
  `id_prod` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_pedido` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `produto_codigo` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc_produto` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qtde_produto` decimal(10,2) NOT NULL,
  `valor_unit_produto` decimal(10,2) NOT NULL,
  `valor_total_produto` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id_prod`),
  KEY `id_pedido` (`id_pedido`),
  KEY `id_produto` (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_loja_pedidos_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_loja_pedidos_status` (
  `id_status` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_pedido` bigint(20) NOT NULL DEFAULT '0',
  `status_alterado` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_alteracao` datetime NOT NULL,
  PRIMARY KEY (`id_status`),
  KEY `id_pedido` (`id_pedido`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_loja_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_loja_produtos` (
  `id_loja_produto` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_produto` bigint(20) DEFAULT NULL,
  `id_empresa` int(11) DEFAULT NULL,
  `id_produto_parent` int(11) DEFAULT '0',
  `nome_exibicao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_promocional` decimal(15,6) DEFAULT '0.000000',
  `descricao_seo` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `palavras_chave` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_loja_produto`),
  UNIQUE KEY `id_produto` (`id_produto`),
  KEY `id_empresa` (`id_empresa`),
  KEY `slug` (`slug`),
  KEY `id_produto_parent` (`id_produto_parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_loja_usuarios`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_loja_usuarios` (
  `id_usuario` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned NOT NULL,
  `nome_usuario` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_usuario` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_usuario` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `senha_usuario` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `senha_redefine_data_usuario` datetime DEFAULT NULL,
  `senha_redefine_key_usuario` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_usuario` enum('F','J') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cpf_cnpj_usuario` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rg_ie_usuario` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `razao_social_usuario` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contato_usuario` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_nascimento_usuario` date DEFAULT NULL,
  `telefone_usuario` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `celular_usuario` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `newsletter_usuario` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `data_cad_usuario` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_usuario` datetime DEFAULT NULL,
  `data_acesso_usuario` datetime DEFAULT NULL,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `login_usuario_unq` (`id_empresa`,`login_usuario`),
  KEY `lixeira_idx` (`lixeira`),
  KEY `data_mod_usuario_idx` (`data_mod_usuario`),
  KEY `id_empresa_email_usuario_idx` (`id_usuario`,`id_empresa`,`email_usuario`),
  KEY `senha_redefine_key_usuario_idx` (`senha_redefine_key_usuario`),
  KEY `tipo_usuario_idx` (`tipo_usuario`),
  KEY `empresa_data_cad_usuario_idx` (`id_empresa`,`data_cad_usuario`),
  KEY `data_cad_usuario_idx` (`data_cad_usuario`),
  KEY `empresa_senha_redefine_key_usuario_idx` (`id_empresa`,`senha_redefine_key_usuario`),
  KEY `empresa_data_mod_usuario_idx` (`id_empresa`,`data_mod_usuario`),
  KEY `data_acesso_usuario_idx` (`data_acesso_usuario`),
  KEY `empresa_cpf_cnpj_usuario_idx` (`id_empresa`,`cpf_cnpj_usuario`),
  KEY `empresa_data_acesso_usuario_idx` (`id_empresa`,`data_acesso_usuario`),
  KEY `empresa_data_nascimento_usuario_idx` (`id_empresa`,`data_nascimento_usuario`),
  KEY `id_empresa_idx` (`id_empresa`),
  KEY `empresa_newsletter_usuario_idx` (`id_empresa`,`newsletter_usuario`),
  KEY `cpf_cnpj_usuario_idx` (`cpf_cnpj_usuario`),
  KEY `empresa_login_usuario_idx` (`id_empresa`,`login_usuario`),
  KEY `empresa_lixeira_idx` (`id_empresa`,`lixeira`),
  KEY `data_nascimento_usuario_idx` (`data_nascimento_usuario`),
  KEY `empresa_email_usuario_idx` (`id_empresa`,`email_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_loja_usuarios_endereco`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_loja_usuarios_endereco` (
  `id_endereco` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(10) unsigned NOT NULL,
  `descricao_endereco` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Padrão',
  `contato_endereco` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cpf_cnpj_endereco` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep_endereco` char(9) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logradouro_endereco` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_endereco` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complemento_endereco` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro_endereco` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_endereco` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado_endereco` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `padrao_endereco` tinyint(1) NOT NULL DEFAULT '1',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `data_cad_endereco` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_endereco` datetime DEFAULT NULL,
  PRIMARY KEY (`id_endereco`),
  KEY `cep_endereco_idx` (`cep_endereco`),
  KEY `estado_endereco_idx` (`estado_endereco`),
  KEY `usuario_lixeira_padrao_idx` (`id_usuario`,`lixeira`,`padrao_endereco`),
  KEY `data_cad_endereco_idx` (`data_cad_endereco`),
  KEY `id_usuario_idx` (`id_usuario`),
  KEY `cidade_endereco_idx` (`cidade_endereco`),
  KEY `lixeira_idx` (`lixeira`),
  KEY `data_mod_endereco_idx` (`data_mod_endereco`),
  KEY `usuario_lixeira_idx` (`id_usuario`,`lixeira`),
  KEY `cidade_estado_idx` (`cidade_endereco`,`estado_endereco`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_lojaintegrada`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_lojaintegrada` (
  `id_lojaintegrada` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `ApplicationKey` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ApiKey` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `baixar_estoque` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `ultima_sincronizacao` datetime NOT NULL,
  PRIMARY KEY (`id_lojaintegrada`),
  UNIQUE KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_lojaintegrada_clientes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_lojaintegrada_clientes` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) NOT NULL DEFAULT '0',
  `id_cliente_lojaintegrada` bigint(20) NOT NULL,
  `nome_cliente` char(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_sincronizacao` datetime NOT NULL,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_lojaintegrada_pedidos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_lojaintegrada_pedidos` (
  `id_ped` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `id_pedido_lojaintegrada` bigint(20) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) NOT NULL DEFAULT '0',
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `valor_total_produtos` decimal(10,2) NOT NULL DEFAULT '0.00',
  `desconto_pedido` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_total_nota` decimal(10,2) NOT NULL DEFAULT '0.00',
  `frete_pedido` decimal(10,2) NOT NULL DEFAULT '0.00',
  `data_pedido` date NOT NULL,
  `obs_pedido` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `obs_interno_pedido` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_pedido` char(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status_pedido_cod` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `pedido_emitido` tinyint(1) NOT NULL DEFAULT '0',
  `data_cad_pedido` datetime NOT NULL,
  `data_mod_pedido` datetime NOT NULL,
  `data_lixeira` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_ped`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_lojaintegrada_pedidos_enderecos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_lojaintegrada_pedidos_enderecos` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_ped` bigint(20) NOT NULL DEFAULT '0',
  `id_end_cliente_lojaintegrada` bigint(20) NOT NULL,
  `endereco_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_cliente` int(11) DEFAULT NULL,
  `bairro_cliente` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complemento_cliente` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep_cliente` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_cliente_cod` int(11) DEFAULT NULL,
  `pais_cliente` char(45) COLLATE utf8mb4_unicode_ci DEFAULT 'Brasil',
  `pais_cliente_cod` char(4) COLLATE utf8mb4_unicode_ci DEFAULT '1058',
  `uf_cliente` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_sincronizacao` datetime NOT NULL,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`),
  KEY `id_ped` (`id_ped`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_lojaintegrada_pedidos_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_lojaintegrada_pedidos_produtos` (
  `id_ped_produto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_ped` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `id_produto_lojaintegrada` char(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `desc_produto` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qtde_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `desconto_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_unit_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_total_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_ped_produto`),
  KEY `id_ped` (`id_ped`),
  KEY `id_produto` (`id_produto`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_lojaintegrada_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_lojaintegrada_produtos` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `id_produto_lojaintegrada` bigint(20) NOT NULL DEFAULT '0',
  `nome_produto` char(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `variacoes_produto` text COLLATE utf8mb4_unicode_ci,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `data_sincronizacao` datetime NOT NULL,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa_id_produto_id_meuspedidos` (`id_empresa`,`id_produto`,`id_produto_lojaintegrada`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_magento`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_magento` (
  `id_magento` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `endereco_magento` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_magento` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `senha_magento` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `baixar_estoque` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `ultima_sincronizacao` datetime NOT NULL,
  PRIMARY KEY (`id_magento`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_magento_pedidos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_magento_pedidos` (
  `id_ped` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_pedido` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `id_pedido_magento` int(11) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) DEFAULT '0',
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_total_produtos` decimal(10,2) DEFAULT '0.00',
  `frete_pedido` decimal(10,2) DEFAULT '0.00',
  `desconto_pedido` decimal(10,2) DEFAULT '0.00',
  `valor_total_nota` decimal(10,2) DEFAULT '0.00',
  `transportadora_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_pedido` date DEFAULT NULL,
  `obs_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `obs_interno_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `status_pedido` char(20) COLLATE utf8mb4_unicode_ci DEFAULT 'Em Aberto',
  `pedido_emitido` tinyint(1) DEFAULT '0',
  `data_cad_pedido` datetime DEFAULT NULL,
  `data_mod_pedido` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_ped`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_magento_pedidos_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_magento_pedidos_produtos` (
  `id_ped_produto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_ped` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `id_produto_magento` bigint(20) NOT NULL DEFAULT '0',
  `desc_produto` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qtde_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `desconto_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_unit_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_total_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_ped_produto`),
  KEY `id_ped` (`id_ped`),
  KEY `id_produto` (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_mercadolivre`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_mercadolivre` (
  `id_mercadolivre` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned NOT NULL DEFAULT '0',
  `app_access_token` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `app_user` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `app_refresh` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `app_expire` bigint(20) DEFAULT NULL,
  `logado` tinyint(1) DEFAULT '1',
  `config_msg_naolidas` tinyint(1) DEFAULT '0',
  `data_cadastro` datetime DEFAULT NULL,
  `data_modificacao` datetime DEFAULT NULL,
  PRIMARY KEY (`id_mercadolivre`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_mercadolivre_anuncios`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_mercadolivre_anuncios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL,
  `app_user` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_produto` bigint(20) DEFAULT NULL,
  `ml_id` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci,
  `status` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permalink` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '#',
  `listing_type_id` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `available_quantity` int(11) DEFAULT '1',
  `base_price` decimal(10,2) DEFAULT '0.00',
  `thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `variations` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id`),
  KEY `id_produto` (`id_produto`),
  KEY `app_user` (`app_user`),
  KEY `id_empresa` (`id_empresa`),
  KEY `ml_id` (`ml_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_mercadolivre_pedidos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_mercadolivre_pedidos` (
  `id_ped` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `app_user` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_pedido_mercadolivre` bigint(20) NOT NULL DEFAULT '0',
  `id_cliente_ml` bigint(20) NOT NULL DEFAULT '0',
  `nome_cliente_ml` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `id_cliente` bigint(20) NOT NULL DEFAULT '0',
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_cliente` char(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `documento_cliente` char(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendedor_pedido` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_total_produtos` decimal(10,2) DEFAULT '0.00',
  `desconto_pedido` decimal(10,2) DEFAULT '0.00',
  `valor_total_nota` decimal(10,2) DEFAULT '0.00',
  `data_pedido` date DEFAULT NULL,
  `status_pedido` char(20) COLLATE utf8mb4_unicode_ci DEFAULT 'Em Aberto',
  `status_envio` char(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `id_envio` bigint(20) DEFAULT '0',
  `pedido_emitido` tinyint(1) DEFAULT '0',
  `data_cad_pedido` datetime DEFAULT NULL,
  `data_mod_pedido` datetime DEFAULT NULL,
  `feedback_pedido_venda_id` bigint(20) DEFAULT '0',
  `feedback_pedido_venda` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feedback_pedido_venda_status` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feedback_pedido_compra_id` bigint(20) DEFAULT '0',
  `feedback_pedido_compra` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feedback_pedido_compra_status` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_ped`),
  KEY `id_empresa` (`id_empresa`),
  KEY `app_user` (`app_user`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa_app_user_id_pedido_mercadolivre` (`id_empresa`,`app_user`,`id_pedido_mercadolivre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_mercadolivre_pedidos_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_mercadolivre_pedidos_produtos` (
  `id_ped_produto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_ped` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` int(11) NOT NULL DEFAULT '0',
  `id_produto_mercadolivre` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `desc_produto` char(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `qtde_produto` int(11) NOT NULL DEFAULT '0',
  `desconto_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_unit_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_total_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `produto_ml` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_ped_produto`),
  KEY `id_ped` (`id_ped`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_mercadolivre_sinc_anuncios`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_mercadolivre_sinc_anuncios` (
  `id_sinc` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `app_user` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_anuncio` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cadastro` datetime DEFAULT NULL,
  `erro` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id_sinc`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_anuncio` (`id_anuncio`),
  KEY `app_user` (`app_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_mercadolivre_sinc_pedidos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_mercadolivre_sinc_pedidos` (
  `id_sinc` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `app_user` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cadastro` datetime DEFAULT NULL,
  `erro` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id_sinc`),
  KEY `app_user` (`app_user`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_mercadolivre_sincronizacao`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_mercadolivre_sincronizacao` (
  `id_sinc` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `app_user` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `anuncios_sincronizados` tinyint(1) NOT NULL DEFAULT '0',
  `pedidos_sincronizados` tinyint(1) NOT NULL DEFAULT '0',
  `data_sinc_anuncios` datetime DEFAULT NULL,
  `data_sinc_pedidos` datetime DEFAULT NULL,
  PRIMARY KEY (`id_sinc`),
  KEY `id_empresa` (`id_empresa`),
  KEY `app_user` (`app_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_mercadolivre_sugestao`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_mercadolivre_sugestao` (
  `id_sugestao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `sugestao` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_sugestao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_sugestao`),
  KEY `id_sugestao` (`id_sugestao`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_meuspedidos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_meuspedidos` (
  `id_meupedido` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `CompanyToken` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `baixar_estoque` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `config_sinc_pedidos` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `config_sinc_produtos` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `config_sinc_categorias` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `config_sinc_transportadoras` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `config_sinc_clientes` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `config_sinc_condicoes` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `config_sinc_listas` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `config_sinc_titulos` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `config_sinc_vendedores` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `config_exportar_categorias` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `config_exportar_clientes` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `config_exportar_listas` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `config_exportar_produtos` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `config_exportar_transportadoras` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `config_exportar_condicoes` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `config_exportar_titulos` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `ignorar_inativos` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `alterado_apos` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ultima_sincronizacao_stoque` datetime DEFAULT NULL,
  `data_cad_meuspedidos` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_meupedido`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_meuspedidos_categorias`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_meuspedidos_categorias` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_categoria` bigint(20) NOT NULL DEFAULT '0',
  `id_categoria_meuspedidos` bigint(20) NOT NULL DEFAULT '0',
  `nome_categoria` char(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `data_sincronizacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_categoria` (`id_categoria`),
  KEY `id_categoria_meuspedidos` (`id_categoria_meuspedidos`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_meuspedidos_clientes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_meuspedidos_clientes` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) NOT NULL DEFAULT '0',
  `id_cliente_meuspedidos` bigint(20) NOT NULL DEFAULT '0',
  `nome_cliente` char(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_sincronizacao` datetime NOT NULL,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `ix_app_meuspedidos_clientes_id_cliente_id_cliente_meuspedidos` (`id_cliente`,`id_cliente_meuspedidos`),
  KEY `id_cliente_meuspedidos` (`id_cliente_meuspedidos`),
  KEY `id_empresa_id_cliente_id_cliente_meuspedidos` (`id_empresa`,`id_cliente`,`id_cliente_meuspedidos`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_meuspedidos_condicoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_meuspedidos_condicoes` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_condicao` bigint(20) NOT NULL DEFAULT '0',
  `id_condicao_meuspedidos` bigint(20) NOT NULL DEFAULT '0',
  `nome_condicao` char(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_minimo` decimal(10,2) NOT NULL,
  `data_sincronizacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_pagamento_meuspedidos` (`id_condicao_meuspedidos`),
  KEY `id_forma_pagamento` (`id_condicao`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_meuspedidos_faturamento`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_meuspedidos_faturamento` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_conta_rec` int(11) NOT NULL,
  `id_pedido` int(11) NOT NULL,
  `id_faturamento_meuspedidos` bigint(20) NOT NULL,
  `valor_faturado` decimal(10,2) DEFAULT NULL,
  `data_faturamento` date DEFAULT NULL,
  `numero_nf` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `informacoes_adicionais` int(11) DEFAULT NULL,
  `data_cad_faturamento` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_faturamento` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_pedido` (`id_pedido`),
  KEY `id_vinculo` (`id_vinculo`),
  KEY `id_conta_rec` (`id_conta_rec`),
  KEY `id_faturamento_meuspedidos` (`id_faturamento_meuspedidos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_meuspedidos_formas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_meuspedidos_formas` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_forma` bigint(20) NOT NULL DEFAULT '0',
  `id_forma_meuspedidos` bigint(20) NOT NULL DEFAULT '0',
  `desc_forma` char(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_sincronizacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `id_condicao_meuspedidos` (`id_forma_meuspedidos`),
  KEY `id_forma` (`id_forma`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_meuspedidos_listas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_meuspedidos_listas` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_lista` bigint(20) NOT NULL DEFAULT '0',
  `id_lista_meuspedidos` bigint(20) NOT NULL DEFAULT '0',
  `nome_lista` char(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_sincronizacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_categoria_meuspedidos` (`id_lista_meuspedidos`),
  KEY `lixeira` (`lixeira`),
  KEY `id_categoria` (`id_lista`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_meuspedidos_listas_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_meuspedidos_listas_produtos` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `id_lista` bigint(20) NOT NULL DEFAULT '0',
  `id_tabela_meuspedidos` bigint(20) NOT NULL DEFAULT '0',
  `data_sincronizacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`),
  KEY `id_categoria` (`id_lista`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_meuspedidos_pedidos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_meuspedidos_pedidos` (
  `id_ped` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_pedido` int(11) NOT NULL DEFAULT '0',
  `id_pedido_meuspedidos` bigint(20) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) DEFAULT '0',
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendedor_pedido_id` bigint(20) DEFAULT NULL,
  `vendedor_pedido` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_transportadora` int(11) DEFAULT NULL,
  `transportadora_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `condicao_pagamento_id` int(11) DEFAULT NULL,
  `condicao_pagamento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `forma_pagamento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_total_produtos` decimal(10,2) DEFAULT '0.00',
  `desconto_pedido` decimal(10,2) DEFAULT '0.00',
  `valor_total_nota` decimal(10,2) DEFAULT '0.00',
  `data_pedido` date DEFAULT NULL,
  `obs_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `obs_interno_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `status_pedido` char(20) COLLATE utf8mb4_unicode_ci DEFAULT 'Em Aberto',
  `pedido_emitido` tinyint(1) DEFAULT '0',
  `data_cad_pedido` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_pedido` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_ped`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_pedido_id_pedido_meuspedidos` (`id_pedido`,`id_pedido_meuspedidos`),
  KEY `id_pedido_meuspedidos` (`id_pedido_meuspedidos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_meuspedidos_pedidos_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_meuspedidos_pedidos_produtos` (
  `id_ped_produto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_ped` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `id_produto_meuspedidos` bigint(20) NOT NULL DEFAULT '0',
  `desc_produto` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qtde_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `preco_bruto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `desconto_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_unit_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `ipi_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_total_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_ped_produto`),
  KEY `id_ped` (`id_ped`),
  KEY `id_produto` (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_meuspedidos_pedidos_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_meuspedidos_pedidos_status` (
  `id_ped_status` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_pedido` int(11) NOT NULL,
  `id_status` bigint(20) NOT NULL,
  `data_sincronizacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_ped_status`),
  KEY `id_ped_status` (`id_ped_status`),
  KEY `id_status` (`id_status`),
  KEY `id_pedido` (`id_pedido`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_meuspedidos_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_meuspedidos_produtos` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `id_produto_meuspedidos` bigint(20) NOT NULL DEFAULT '0',
  `nome_produto` char(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `origem_vinculo` tinyint(1) NOT NULL DEFAULT '0',
  `ultima_alteracao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_sincronizacao` datetime NOT NULL,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `ix_app_meuspedidos_produtos_id_produto_id_produto_meuspedidos` (`id_produto`,`id_produto_meuspedidos`),
  KEY `id_produto_meuspedidos` (`id_produto_meuspedidos`),
  KEY `id_empresa_id_produto_id_meuspedidos` (`id_empresa`,`id_produto`,`id_produto_meuspedidos`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_meuspedidos_produtos_fotos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_meuspedidos_produtos_fotos` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_produto` bigint(20) NOT NULL,
  `id_foto` bigint(20) NOT NULL,
  `id_produto_meuspedidos` bigint(20) NOT NULL,
  `id_produto_foto_meuspedidos` bigint(20) NOT NULL,
  `foto_grande` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto_thumb` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_sincronizacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_vinculo`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_produto_meuspedidos` (`id_produto_meuspedidos`),
  KEY `lixeira` (`lixeira`),
  KEY `id_vinculo` (`id_vinculo`),
  KEY `id_produto` (`id_produto`),
  KEY `id_produto_foto_meuspedidos` (`id_produto_foto_meuspedidos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_meuspedidos_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_meuspedidos_status` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_status_meuspedidos` bigint(20) NOT NULL,
  `nome_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_status` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`),
  KEY `id_vinculo` (`id_vinculo`),
  KEY `id_status_meuspedidos` (`id_status_meuspedidos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_meuspedidos_titulos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_meuspedidos_titulos` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_conta_rec` bigint(20) NOT NULL DEFAULT '0',
  `id_titulo_meuspedidos` bigint(20) NOT NULL DEFAULT '0',
  `nome_conta` char(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `liquidado_rec` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `vencimento_rec` date NOT NULL,
  `data_sincronizacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `lixeira` (`lixeira`),
  KEY `id_titulo` (`id_conta_rec`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_titulo_meuspedidos` (`id_titulo_meuspedidos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_meuspedidos_transportadoras`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_meuspedidos_transportadoras` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_transportadora` bigint(20) NOT NULL DEFAULT '0',
  `id_transportadora_meuspedidos` bigint(20) NOT NULL DEFAULT '0',
  `nome_transportadora` char(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_sincronizacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `id_empresa_id_transportadora_id_transportadora_meuspedidos` (`id_empresa`,`id_transportadora`,`id_transportadora_meuspedidos`),
  KEY `lixeira` (`lixeira`),
  KEY `id_transportadora_id_transportadora_meuspedidos` (`id_transportadora`,`id_transportadora_meuspedidos`),
  KEY `id_transportadora_meuspedidos` (`id_transportadora_meuspedidos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_meuspedidos_vendedores`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_meuspedidos_vendedores` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_vendedor` bigint(20) NOT NULL DEFAULT '0',
  `id_vendedor_meuspedidos` bigint(20) NOT NULL DEFAULT '0',
  `nome_vendedor` char(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_sincronizacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `id_vendedor_id_vendedor_meuspedidos` (`id_vendedor`,`id_vendedor_meuspedidos`),
  KEY `id_vendedor_meuspedidos` (`id_vendedor_meuspedidos`),
  KEY `id_empresa_id_vendedor_id_vendedor_meuspedidos` (`id_empresa`,`id_vendedor`,`id_vendedor_meuspedidos`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_multiempresa`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_multiempresa` (
  `id_multiempresa` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `tipo_empresa` tinyint(1) NOT NULL DEFAULT '0',
  `data_cad_multiempresa` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_multiempresa` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_multiempresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_multiempresa_permissoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_multiempresa_permissoes` (
  `id_permissoes` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_matriz` int(11) NOT NULL DEFAULT '0',
  `id_filial` int(11) NOT NULL DEFAULT '0',
  `faturamento` tinyint(1) NOT NULL DEFAULT '0',
  `estoque` tinyint(1) NOT NULL DEFAULT '0',
  `financeiro` tinyint(1) NOT NULL DEFAULT '0',
  `autorizacao` tinyint(1) NOT NULL DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_permissoes`),
  KEY `id_matriz` (`id_matriz`),
  KEY `id_filial` (`id_filial`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_newsletter`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_newsletter` (
  `id_news` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_remetente` int(11) NOT NULL DEFAULT '0',
  `grupos_news` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contatos_news` int(11) NOT NULL,
  `nome_lista_news` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assunto_news` char(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conteudo_news` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_news` tinyint(1) NOT NULL DEFAULT '0',
  `id_lista_news` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_envio_news` datetime NOT NULL,
  `data_cad_news` datetime NOT NULL,
  `usuario_news` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `envio_id` char(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_news`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`),
  KEY `id_remetente` (`id_remetente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_newsletter_destinatarios`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_newsletter_destinatarios` (
  `id_destinatario` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned DEFAULT NULL,
  `id_news` int(10) unsigned DEFAULT NULL,
  `email_destinatario` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_destinatario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_newsletter_log_api`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_newsletter_log_api` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned NOT NULL,
  `id_news` int(10) unsigned NOT NULL,
  `code` smallint(5) unsigned NOT NULL,
  `error_id` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `error` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`),
  KEY `idx_id_empresa_id_news` (`id_empresa`,`id_news`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_newsletter_log_lista`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_newsletter_log_lista` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `nome_lista` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dados_lista` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id_log`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_newsletter_remetentes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_newsletter_remetentes` (
  `id_remetente` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `nome_remetente` char(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_remetente` char(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_remetente` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_remetente` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `remetente_id` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_remetente`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_newsletter_resultados`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_newsletter_resultados` (
  `id_resultado` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_news` int(11) NOT NULL DEFAULT '0',
  `enviados` int(11) NOT NULL DEFAULT '0',
  `visualizacoes` int(11) NOT NULL DEFAULT '0',
  `cliques` int(11) NOT NULL DEFAULT '0',
  `retornos` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_resultado`),
  KEY `id_news` (`id_news`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_nuvemshop`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_nuvemshop` (
  `id_empresa` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `access_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `user_id` int(11) NOT NULL,
  `sincroniza_produtos` tinyint(1) NOT NULL DEFAULT '0',
  `sincroniza_pedidos` tinyint(1) NOT NULL DEFAULT '0',
  `sincroniza_clientes` tinyint(1) NOT NULL DEFAULT '0',
  `primeiro_acesso` tinyint(1) NOT NULL DEFAULT '1',
  `data_sync_produtos` datetime DEFAULT NULL,
  `data_sync_clientes` datetime DEFAULT NULL,
  `data_sync_pedidos` datetime DEFAULT NULL,
  PRIMARY KEY (`id_empresa`),
  UNIQUE KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_nuvemshop_clientes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_nuvemshop_clientes` (
  `id_vinculo` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_cliente` bigint(20) NOT NULL,
  `id_cliente_nv` bigint(20) NOT NULL,
  `id_empresa` bigint(20) NOT NULL,
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_cliente` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_sincronizacao` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `id_cliente_nv` (`id_cliente_nv`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_nuvemshop_pedidos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_nuvemshop_pedidos` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_pedido_nv` bigint(20) NOT NULL DEFAULT '0',
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) NOT NULL DEFAULT '0',
  `id_cliente_nv` bigint(20) NOT NULL DEFAULT '0',
  `numero_pedido` int(11) NOT NULL,
  `status_pedido` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `pagamento_status` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `pedido_emitido` tinyint(1) NOT NULL DEFAULT '0',
  `valor_total_nota` double NOT NULL,
  `frete_pedido` double NOT NULL,
  `data_pedido` datetime NOT NULL,
  `data_sincronizacao` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `id_pedido_nv` (`id_pedido_nv`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_cliente_nv` (`id_cliente_nv`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_nuvemshop_pedidos_produto`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_nuvemshop_pedidos_produto` (
  `id_ped_produto` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_vinculo` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `id_produto_nv` bigint(20) NOT NULL DEFAULT '0',
  `id_variacao_nv` bigint(20) NOT NULL DEFAULT '0',
  `desc_produto` char(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `qtde_produto` int(11) NOT NULL DEFAULT '0',
  `valor_unit_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_total_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  PRIMARY KEY (`id_ped_produto`),
  KEY `id_produto` (`id_produto`),
  KEY `id_vinculo` (`id_vinculo`),
  KEY `id_produto_nv` (`id_produto_nv`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_nuvemshop_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_nuvemshop_produtos` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `id_produto_nv` bigint(20) NOT NULL DEFAULT '0',
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `id_variacao_nv` bigint(20) DEFAULT NULL,
  `variacoes_produto` text COLLATE utf8mb4_unicode_ci,
  `nome_produto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `data_sincronizacao` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `id_produto` (`id_produto`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_produto_nv` (`id_produto_nv`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_olist`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_olist` (
  `id_olist` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `access_token` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refresh_token` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expires_in` bigint(20) DEFAULT '0',
  `id_token` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seller_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logado` tinyint(1) DEFAULT '0',
  `config_sinc_estoque` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `config_sinc_produtos` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `config_sinc_clientes` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `pedidos_sincronizados` tinyint(1) DEFAULT '0',
  `produtos_sincronizados` tinyint(1) DEFAULT '0',
  `data_cadastro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_modificacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_olist`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_olist_categorias`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_olist_categorias` (
  `id_categoria` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marketplace` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_categoria`),
  KEY `parent` (`parent`),
  KEY `marketplace` (`marketplace`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_olist_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_olist_log` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `descricao` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `json` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`),
  KEY `id_log` (`id_log`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_olist_pedidos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_olist_pedidos` (
  `id_ped` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL,
  `id_pedido_olist` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_cliente` bigint(20) NOT NULL DEFAULT '0',
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `documento_cliente` varchar(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_total_produtos` decimal(10,2) DEFAULT '0.00',
  `valor_total_nota` decimal(10,2) DEFAULT '0.00',
  `frete_pedido` decimal(10,2) DEFAULT '0.00',
  `envio` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_pedido` date DEFAULT NULL,
  `pagamento` mediumtext COLLATE utf8mb4_unicode_ci,
  `obs_interna_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status_pedido` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancelation_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `status_envio` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pedido_emitido` tinyint(1) DEFAULT '0',
  `data_cad_pedido` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_pedido` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_ped`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_pedido_olist` (`id_pedido_olist`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_olist_pedidos_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_olist_pedidos_produtos` (
  `id_ped_produto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_ped` bigint(20) NOT NULL,
  `id_produto` int(11) NOT NULL DEFAULT '0',
  `id_produto_olist` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc_produto` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `qtde_produto` int(11) NOT NULL DEFAULT '0',
  `valor_unit_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_total_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_ped_produto`),
  KEY `id_ped` (`id_ped`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_olist_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_olist_produtos` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `id_produto_olist` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `nome_produto` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_de` decimal(15,2) NOT NULL,
  `valor_por` decimal(15,2) NOT NULL,
  `estoque` decimal(15,4) NOT NULL,
  `descricao` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `ean` varchar(14) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `marca` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `medidas_produto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `medidas_pacote` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prazo_extra` tinyint(1) NOT NULL,
  `atributos` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_sincronizacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa_id_produto_id_produto_tray` (`id_empresa`,`id_produto`,`id_produto_olist`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_olist_webhooks`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_olist_webhooks` (
  `id_webhook` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `seller_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resource` varchar(70) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_webhook` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_webhook`),
  KEY `seller_id` (`seller_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_opencart`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_opencart` (
  `id_opencart` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `endereco_opencart` char(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `senha_opencart` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `baixar_estoque` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Sim',
  `ultima_sincronizacao` datetime NOT NULL,
  PRIMARY KEY (`id_opencart`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_opencart_clientes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_opencart_clientes` (
  `id_empresa` int(11) DEFAULT NULL,
  `id_cliente` bigint(20) DEFAULT NULL,
  `id_cliente_opencart` bigint(20) DEFAULT NULL,
  `nome_cliente` char(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  KEY `id_cliente` (`id_cliente`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_cliente_opencart` (`id_cliente_opencart`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_opencart_pedidos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_opencart_pedidos` (
  `id_ped` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL,
  `id_pedido` int(11) NOT NULL,
  `id_cliente` bigint(20) NOT NULL,
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_total_produtos` decimal(10,2) NOT NULL,
  `valor_total_nota` decimal(10,2) NOT NULL,
  `frete_pedido` decimal(10,2) NOT NULL,
  `data_pedido` date NOT NULL,
  `status_pedido` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `obs_interno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_pedido` date NOT NULL,
  `data_mod_pedido` date NOT NULL,
  `pedido_emitido` tinyint(1) NOT NULL DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_ped`),
  KEY `id_pedido` (`id_pedido`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_cliente` (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_opencart_pedidos_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_opencart_pedidos_produtos` (
  `id_ped_produto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_ped` bigint(20) DEFAULT NULL,
  `id_produto` bigint(20) DEFAULT NULL,
  `id_produto_opencart` bigint(20) DEFAULT NULL,
  `desc_produto` char(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qtde_produto` bigint(20) DEFAULT NULL,
  `desconto_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_unit_produto` decimal(10,2) DEFAULT NULL,
  `valor_total_produto` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id_ped_produto`),
  KEY `id_ped` (`id_ped`),
  KEY `id_produto_opencart` (`id_produto_opencart`),
  KEY `id_produto` (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_opencart_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_opencart_produtos` (
  `id_empresa` bigint(20) DEFAULT NULL,
  `id_produto` bigint(20) DEFAULT NULL,
  `id_produto_opencart` bigint(20) DEFAULT NULL,
  `desc_produto` char(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  KEY `id_empresa` (`id_empresa`),
  KEY `id_produto_opencart` (`id_produto_opencart`),
  KEY `id_produto` (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_oportunidades`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_oportunidades` (
  `id_oportunidade` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `nome_produto` char(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `descricao_produto` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `contato_produto` char(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone_contato` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto_principal_produto` char(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto_2_produto` char(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto_3_produto` char(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qtde_vendido` smallint(6) NOT NULL DEFAULT '0',
  `views_produto` int(11) NOT NULL DEFAULT '0',
  `status_produto` enum('Em análise','Reprovado','Publicado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Em análise',
  `status_produto_obs` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'O produto será analisado pela nossa equipe antes de ser publicado.',
  `data_cad_produto` datetime NOT NULL,
  `data_mod_produto` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_oportunidade`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_pesquisa`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_pesquisa` (
  `id_pesquisa` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `titulo_pesquisa` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subtitulo_pesquisa` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `confirmacao_pesquisa` char(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sua resposta foi registrada.',
  `status_pesquisa` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Ativo',
  `data_inicio` date NOT NULL,
  `data_final` date NOT NULL,
  `data_cad_pesquisa` datetime NOT NULL,
  `data_mod_pesquisa` datetime NOT NULL,
  `url_encurtada` char(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_pesquisa`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_pesquisa_perguntas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_pesquisa_perguntas` (
  `id_pergunta` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_pesquisa` int(11) NOT NULL DEFAULT '0',
  `titulo_pergunta` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subtitulo_pergunta` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_pergunta` enum('text','textarea','radio','checkbox','select') COLLATE utf8mb4_unicode_ci NOT NULL,
  `obrigatoria_pergunta` tinyint(1) NOT NULL DEFAULT '0',
  `ordenacao_pergunta` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_pergunta`),
  KEY `id_pesquisa` (`id_pesquisa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_pesquisa_perguntas_opcoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_pesquisa_perguntas_opcoes` (
  `id_opcao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_pergunta` int(11) NOT NULL DEFAULT '0',
  `titulo_opcao` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_opcao`),
  KEY `id_pergunta` (`id_pergunta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_pesquisa_respostas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_pesquisa_respostas` (
  `id_resposta` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_pesquisa` int(11) NOT NULL DEFAULT '0',
  `ip_resposta` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_resposta` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_resposta`),
  KEY `lixeira` (`lixeira`),
  KEY `id_pesquisa` (`id_pesquisa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_pesquisa_respostas_opcoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_pesquisa_respostas_opcoes` (
  `id_opresposta` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_resposta` int(11) NOT NULL DEFAULT '0',
  `id_pergunta` int(11) NOT NULL DEFAULT '0',
  `resposta_texto` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_opresposta`),
  KEY `id_pergunta` (`id_pergunta`),
  KEY `id_resposta` (`id_resposta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_prestashop`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_prestashop` (
  `id_empresa` int(11) NOT NULL,
  `token` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url_loja` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sincroniza_clientes` tinyint(1) NOT NULL,
  `sincroniza_transportadoras` tinyint(1) NOT NULL,
  `sincroniza_produtos` tinyint(1) NOT NULL,
  `sincroniza_pedidos` tinyint(1) NOT NULL,
  `primeira_sincronia_estoque` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_prestashop_clientes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_prestashop_clientes` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_cliente` bigint(20) NOT NULL,
  `id_clienteprestashop` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_cliente` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_sincronizacao` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_vinculo`),
  UNIQUE KEY `id_cliente` (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_prestashop_pedidos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_prestashop_pedidos` (
  `id_ped` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_pedido_ps` bigint(20) NOT NULL DEFAULT '0',
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) NOT NULL DEFAULT '0',
  `id_cliente_ps` bigint(20) NOT NULL DEFAULT '0',
  `nome_cliente` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `id_transportadora` bigint(20) DEFAULT NULL,
  `transportadora_pedido` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `frete_pedido` double DEFAULT NULL,
  `status_pedido` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_total_nota` double NOT NULL DEFAULT '0',
  `pedido_emitido` tinyint(1) DEFAULT '0',
  `data_pedido` datetime DEFAULT NULL,
  `data_sincronizacao` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_ped`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_prestashop_pedidos_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_prestashop_pedidos_produtos` (
  `id_ped_produto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_ped` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `id_produto_ps` bigint(20) NOT NULL DEFAULT '0',
  `id_variacao_ps` bigint(20) NOT NULL DEFAULT '0',
  `desc_produto` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qtde_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_unit_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_total_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_ped_produto`),
  KEY `id_produto` (`id_produto`),
  KEY `id_ped` (`id_ped`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_prestashop_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_prestashop_produtos` (
  `id_vinculo` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `id_produto_ps` bigint(20) NOT NULL,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `nome_produto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `variacoes_produto` text COLLATE utf8mb4_unicode_ci,
  `data_sincronizacao` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_prestashop_transportadoras`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_prestashop_transportadoras` (
  `id_vinculo` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL,
  `id_transportadora` bigint(20) NOT NULL,
  `id_transportadora_ps` bigint(20) NOT NULL,
  `nome_transportadora` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_sincronizacao` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_vinculo`),
  UNIQUE KEY `id_transportadora` (`id_transportadora`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_projetos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_projetos` (
  `id_projeto` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `nome_projeto` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `responsavel_projeto` int(11) NOT NULL DEFAULT '0',
  `data_inicio` date NOT NULL,
  `data_entrega` date DEFAULT NULL,
  `data_conclusao` date DEFAULT NULL,
  `valor_projeto` decimal(10,2) DEFAULT NULL,
  `observacoes_projeto` mediumtext COLLATE utf8mb4_unicode_ci,
  `entregue` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `usuario_cad_projeto` int(11) NOT NULL DEFAULT '0',
  `usuario_mod_projeto` int(11) DEFAULT '0',
  `data_cad_projeto` datetime NOT NULL,
  `data_mod_projeto` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_projeto`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`),
  KEY `responsavel_projeto` (`responsavel_projeto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_projetos_config`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_projetos_config` (
  `id_config` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `enviar_email_tarefas` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `enviar_email_desc` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enviar_email_tarefas_criar` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sim',
  `dashboard_projetos` tinyint(1) NOT NULL DEFAULT '1',
  `dashboard_tarefas` tinyint(1) NOT NULL DEFAULT '1',
  `usuario_mod_config` int(11) NOT NULL DEFAULT '0',
  `data_mod_config` datetime NOT NULL,
  PRIMARY KEY (`id_config`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_projetos_etapas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_projetos_etapas` (
  `id_etapa` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_projeto` int(11) NOT NULL DEFAULT '0',
  `nome_etapa` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordenacao_etapa` tinyint(1) NOT NULL DEFAULT '0',
  `usuario_cad_etapa` int(11) NOT NULL DEFAULT '0',
  `usuario_mod_etapa` int(11) DEFAULT '0',
  `data_cad_etapa` datetime NOT NULL,
  `data_mod_etapa` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_etapa`),
  KEY `lixeira` (`lixeira`),
  KEY `id_projeto` (`id_projeto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_projetos_padroes_etapas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_projetos_padroes_etapas` (
  `id_padrao_etapa` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `nome_etapa` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordenacao_etapa` tinyint(1) NOT NULL DEFAULT '0',
  `usuario_cad_etapa` int(11) NOT NULL DEFAULT '0',
  `data_cad_etapa` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_padrao_etapa`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_projetos_padroes_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_projetos_padroes_status` (
  `id_padrao_status` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `nome_status` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario_cad_status` int(11) NOT NULL DEFAULT '0',
  `data_cad_status` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_padrao_status`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_projetos_permissoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_projetos_permissoes` (
  `id_permissao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `cadastrar_projetos` tinyint(1) NOT NULL DEFAULT '0',
  `configuracoes` tinyint(1) NOT NULL DEFAULT '0',
  `dashboard` tinyint(1) NOT NULL DEFAULT '0',
  `visualizar_dados` tinyint(1) NOT NULL DEFAULT '0',
  `historico_trabalho` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_permissao`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_projetos_tarefas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_projetos_tarefas` (
  `id_tarefa` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_projeto` int(11) DEFAULT '0',
  `id_etapa` int(11) DEFAULT '0',
  `id_responsavel` int(11) NOT NULL DEFAULT '0',
  `titulo_tarefa` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_inicio` date DEFAULT NULL,
  `data_entrega` date DEFAULT NULL,
  `tarefa_continua` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `horas_previstas` time DEFAULT NULL,
  `empenho_dia` time DEFAULT NULL,
  `prioridade_tarefa` enum('Baixa','Média','Alta') COLLATE utf8mb4_unicode_ci DEFAULT 'Baixa',
  `status_tarefa` char(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao_tarefa` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `trabalhando` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `entregue` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `usuario_cad_tarefa` int(11) NOT NULL DEFAULT '0',
  `usuario_mod_tarefa` int(11) DEFAULT '0',
  `data_cad_tarefa` datetime NOT NULL,
  `data_mod_tarefa` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_tarefa`),
  KEY `id_projeto` (`id_projeto`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`),
  KEY `id_etapa` (`id_etapa`),
  KEY `id_responsavel` (`id_responsavel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_projetos_tarefas_ocorrencias`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_projetos_tarefas_ocorrencias` (
  `id_ocorrencia` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_tarefa` int(11) NOT NULL DEFAULT '0',
  `desc_ocorrencia` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario_cad_ocorrencia` int(11) NOT NULL DEFAULT '0',
  `data_cad_ocorrencia` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_ocorrencia`),
  KEY `lixeira` (`lixeira`),
  KEY `id_tafefa` (`id_tarefa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_projetos_tarefas_requisitos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_projetos_tarefas_requisitos` (
  `id_requisito` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_tarefa` int(11) NOT NULL DEFAULT '0',
  `id_tarefa_requisito` int(11) NOT NULL DEFAULT '0',
  `usuario_cad_requisito` int(11) NOT NULL DEFAULT '0',
  `data_cad_requisito` datetime NOT NULL,
  PRIMARY KEY (`id_requisito`),
  KEY `id_tarefa_requisito` (`id_tarefa_requisito`),
  KEY `id_tarefa` (`id_tarefa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_projetos_tarefas_trabalhos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_projetos_tarefas_trabalhos` (
  `id_trabalho` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_tarefa` int(11) NOT NULL DEFAULT '0',
  `inicio_trabalho` time NOT NULL,
  `termino_trabalho` time NOT NULL,
  `tempo_trabalho` time NOT NULL,
  `usuario_cad_trabalho` int(11) NOT NULL DEFAULT '0',
  `data_cad_trabalho` datetime NOT NULL,
  `data_fim_trabalho` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_trabalho`),
  KEY `lixeira` (`lixeira`),
  KEY `id_tafefa` (`id_tarefa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_rastreamento_dados`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_rastreamento_dados` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `data_rastreamento` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_rdstation`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_rdstation` (
  `id_rdstation` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `webhook_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `confirmacao` tinyint(1) NOT NULL DEFAULT '0',
  `data_cad_config` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_rdstation`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_rdstation_config`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_rdstation_config` (
  `id_credencial` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `client_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_secret` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refresh_token` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expires_in` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_token` datetime DEFAULT NULL,
  `access_token` varchar(680) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_credencial`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_rdstation_credenciais`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_rdstation_credenciais` (
  `id_credencial` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `client_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_secret` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `refresh_token` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expires_in` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_token` datetime DEFAULT NULL,
  `access_token` varchar(680) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_credencial`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_rdstation_leads`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_rdstation_leads` (
  `id_lead` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `id` int(11) DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `opportunity` tinyint(1) DEFAULT NULL,
  `number_conversions` tinyint(1) DEFAULT NULL,
  `user` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_conversion_cumulative_sum` tinyint(1) DEFAULT NULL,
  `first_conversion_source` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_conversion_cumulative_sum` tinyint(1) DEFAULT NULL,
  `last_conversion_source` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `personal_phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lead_stage` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fit_score` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interest` tinyint(1) DEFAULT NULL,
  `convertido_cliente` tinyint(1) DEFAULT '0',
  `prospecto_funil` tinyint(1) DEFAULT '0',
  `data_cad_lead` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_lead`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_recebaja_bordero`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_recebaja_bordero` (
  `id_bordero` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned NOT NULL,
  `id` bigint(20) unsigned NOT NULL,
  `acquisition_rate` decimal(16,2) DEFAULT NULL,
  `acquisition_net_value` decimal(16,2) DEFAULT NULL,
  `id_bank_account` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acquisition_fees` decimal(16,2) DEFAULT NULL,
  `acquisition_nominal_value` decimal(16,2) DEFAULT NULL,
  `id_company_seller` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acquisition_total_interest` decimal(16,2) DEFAULT NULL,
  `acquisition_total_credit` decimal(16,2) DEFAULT NULL,
  `is_acquisition_elegible` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `acquisition_cet_monthly` decimal(16,2) DEFAULT NULL,
  `deposit_date` date DEFAULT NULL,
  `data_mod_bordero` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_cad_bordero` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_bordero`),
  KEY `id` (`id`),
  KEY `state` (`state`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_recebaja_bordero_recebiveis`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_recebaja_bordero_recebiveis` (
  `id_recebivel` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_bordero` int(10) unsigned DEFAULT NULL,
  `id` int(10) unsigned DEFAULT NULL,
  `credit_value` decimal(16,2) DEFAULT NULL,
  `interest` decimal(16,2) DEFAULT NULL,
  `receivable_value` decimal(16,2) DEFAULT NULL,
  `value` decimal(16,2) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `original_id` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nfe` int(11) DEFAULT NULL,
  `buyer_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_recebivel`),
  KEY `id_bordero` (`id_bordero`),
  KEY `nfe` (`nfe`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_recebaja_cadastros_clientes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_recebaja_cadastros_clientes` (
  `id_cliente` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `player` int(11) DEFAULT NULL,
  `receita` decimal(10,2) DEFAULT NULL,
  `tipo_natureza` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `classificacao` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `optin` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `cnpj` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_abertura_cnpj` datetime DEFAULT NULL,
  `data_cad_cliente` datetime DEFAULT NULL,
  `data_mod_cliente` datetime DEFAULT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_recebaja_config`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_recebaja_config` (
  `id_config` tinyint(3) unsigned NOT NULL,
  `taxa_juros` decimal(16,2) unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_recebaja_emitente`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_recebaja_emitente` (
  `id_emitente` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `receita` decimal(16,2) DEFAULT NULL,
  `integrado` tinyint(1) NOT NULL DEFAULT '0',
  `url_termo_adesao` text COLLATE utf8mb4_unicode_ci,
  `retorno_atualizacao` longtext COLLATE utf8mb4_unicode_ci,
  `data_cad` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_emitente`),
  UNIQUE KEY `uq_id_empresa` (`id_empresa`),
  KEY `id_empresa` (`id_empresa`),
  KEY `integrado` (`integrado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_recebaja_emitente_contas_bancarias`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_recebaja_emitente_contas_bancarias` (
  `id_conta_bancaria` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned DEFAULT NULL,
  `id_banco_cad` int(10) unsigned DEFAULT NULL,
  `conta_padrao` tinyint(1) DEFAULT '0',
  `vinculado_cadastro` tinyint(1) DEFAULT '0',
  `data_cad_conta_bancaria` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_conta_bancaria` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_conta_bancaria`),
  UNIQUE KEY `unq_id_empresa_id_banco_cad` (`id_empresa`,`id_banco_cad`),
  KEY `idx_id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_recebaja_emitente_contas_bancarias_token`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_recebaja_emitente_contas_bancarias_token` (
  `id_token` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_banco_cad` int(10) unsigned DEFAULT NULL,
  `id` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_token` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_token`),
  UNIQUE KEY `unq_id_empresa_id_banco_cad` (`id_banco_cad`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_recebaja_emitente_documentos_empresas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_recebaja_emitente_documentos_empresas` (
  `id_documento` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned DEFAULT NULL,
  `tipo_documento` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `documento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_documento` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_documento`),
  KEY `tipo_documento` (`tipo_documento`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_recebaja_emitente_documentos_usuarios`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_recebaja_emitente_documentos_usuarios` (
  `id_documento` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned DEFAULT NULL,
  `id_usuario` int(10) unsigned DEFAULT NULL,
  `tipo_documento` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `documento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_documento` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_documento`),
  KEY `tipo_documento` (`tipo_documento`),
  KEY `id_representante` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_recebaja_emitente_token`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_recebaja_emitente_token` (
  `id_token` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned NOT NULL,
  `token` text COLLATE utf8mb4_unicode_ci,
  `company_id` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_token` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_token`),
  KEY `company_id` (`company_id`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_recebaja_emitente_usuarios`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_recebaja_emitente_usuarios` (
  `id_usuario` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario_parent` int(11) DEFAULT NULL,
  `id_empresa` int(10) unsigned NOT NULL,
  `tipo` tinyint(1) DEFAULT NULL,
  `nome_completo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cpf` char(14) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rg` char(14) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estado_civil` char(14) COLLATE utf8mb4_unicode_ci NOT NULL,
  `genero` char(14) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_nascimento` date NOT NULL,
  `telefone` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cep` char(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `endereco` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numero` char(9) COLLATE utf8mb4_unicode_ci NOT NULL,
  `complemento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cidade` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estado` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_representante` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_usuario`),
  KEY `cpf` (`cpf`),
  KEY `tipo` (`tipo`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_recebaja_emitente_usuarios_token`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_recebaja_emitente_usuarios_token` (
  `id_token` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cpf` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_token`),
  KEY `cpf` (`cpf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_recebaja_hooks`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_recebaja_hooks` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `conteudo` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_recebaja_nf`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_recebaja_nf` (
  `id_nf` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned NOT NULL,
  `nfe` int(10) unsigned NOT NULL,
  `buyer_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_nf`),
  KEY `nfe` (`nfe`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_recebaja_nf_blacklist`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_recebaja_nf_blacklist` (
  `id_blacklist` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned NOT NULL,
  `nota_chave` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `motivo` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_blacklist` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_blacklist`),
  KEY `id_empresa` (`id_empresa`),
  KEY `nota_chave` (`nota_chave`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_recebaja_nf_recebiveis`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_recebaja_nf_recebiveis` (
  `id_recebivel` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_nf` int(10) unsigned DEFAULT NULL,
  `value` decimal(16,2) unsigned DEFAULT NULL,
  `receivable_value` decimal(16,2) DEFAULT NULL,
  `interest` decimal(16,2) unsigned DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `ndup` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_recebivel`),
  KEY `id` (`id`),
  KEY `id_nf` (`id_nf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_recebaja_reanalise`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_recebaja_reanalise` (
  `id_reanalise` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned DEFAULT NULL,
  `analysis_id` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `data_cad_reanalise` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_reanalise`),
  KEY `id` (`analysis_id`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_recebaja_reanalise_duplicatas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_recebaja_reanalise_duplicatas` (
  `id_reanalise_duplicata` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_reanalise` int(11) DEFAULT NULL,
  `id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_reanalise_duplicata`),
  KEY `id_reanalise` (`id_reanalise`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_recebaja_recompra`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_recebaja_recompra` (
  `id_recompra` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` decimal(16,2) unsigned DEFAULT NULL,
  `id` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receipt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `data_cad_recompra` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_recompra` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_recompra`),
  KEY `id_empresa` (`id_empresa`),
  KEY `state` (`state`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_recebaja_recompra_recebiveis`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_recebaja_recompra_recebiveis` (
  `id_recompra_recebiveis` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_recompra` int(11) DEFAULT NULL,
  `buyer_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fiscal_document_number` int(11) DEFAULT NULL,
  `daily_interest` decimal(16,2) DEFAULT NULL,
  `id` int(11) DEFAULT NULL,
  `value` decimal(16,2) DEFAULT NULL,
  `original_id` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `buyback_value` decimal(16,2) DEFAULT NULL,
  PRIMARY KEY (`id_recompra_recebiveis`),
  KEY `id_recompra` (`id_recompra`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_serasa_consultas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_serasa_consultas` (
  `id_consulta` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `tipo_consulta` char(35) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_usuario` bigint(20) DEFAULT '0',
  `nome_usuario` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `documento_consulta` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nome_consulta` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nome_mae_consulta` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_nasc_consulta` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `situacao_consulta` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_ocorrencias` int(11) DEFAULT '0',
  `mensagem_consulta` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resultado_consulta` longtext COLLATE utf8mb4_unicode_ci,
  `data_consulta` datetime DEFAULT NULL,
  PRIMARY KEY (`id_consulta`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_serasa_tipos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_serasa_tipos` (
  `id_tipo` tinyint(1) NOT NULL,
  `nome_consulta` varchar(70) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parametro_consulta` char(35) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao_consulta` varchar(600) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_custo` decimal(10,2) NOT NULL,
  `valor_consulta` decimal(10,2) NOT NULL,
  `tipo_consulta` char(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_consulta` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Inativo',
  KEY `status_consulta` (`status_consulta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_serasa_tipos_adicionais`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_serasa_tipos_adicionais` (
  `id_adicional` tinyint(1) NOT NULL,
  `id_tipo` tinyint(1) NOT NULL DEFAULT '0',
  `nome_adicional` char(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_custo` decimal(10,2) NOT NULL,
  `valor_consulta` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_stone_config`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_stone_config` (
  `id_config` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `stone_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnpj` char(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cappta_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_config` datetime DEFAULT NULL,
  `status` enum('open','processing','closed','cancelled','finish') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `data_mod_config` datetime DEFAULT NULL,
  `credito_juros_parcelado` enum('merchant','issuer') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'merchant',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  `habilitar` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sim',
  PRIMARY KEY (`id_config`),
  KEY `stone_code` (`stone_code`),
  KEY `id_config` (`id_config`),
  KEY `id_empresa` (`id_empresa`,`id_config`,`status`,`lixeira`,`habilitar`,`cappta_id`,`cnpj`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_stone_danfes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_stone_danfes` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `id_nfc` int(11) DEFAULT NULL,
  `id_frente` int(11) DEFAULT NULL,
  `id_pedido_venda` int(11) DEFAULT NULL,
  `id_pdv` int(11) DEFAULT NULL,
  `danfe_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_vinculo`),
  KEY `id_empresa` (`id_empresa`,`id_vinculo`,`id_nfc`,`id_frente`,`id_pedido_venda`,`id_pdv`,`danfe_id`,`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_stone_ordens`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_stone_ordens` (
  `id_ordem` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `id_frente` int(11) DEFAULT NULL,
  `id_nfc` int(11) DEFAULT NULL,
  `cod_pos` int(11) DEFAULT NULL,
  `order_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_ordem` datetime DEFAULT NULL,
  `data_mod_ordem` datetime DEFAULT NULL,
  PRIMARY KEY (`id_ordem`),
  KEY `id_pedido` (`id_frente`,`order_id`,`id_empresa`,`cod_pos`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_stone_pos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_stone_pos` (
  `id_pos` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `cod_pos` int(11) NOT NULL,
  `cnpj_empresa` char(14) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stonecode` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rotulo_pos` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serial` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` char(1) COLLATE utf8mb4_unicode_ci DEFAULT 'D',
  `order_id_processando` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_pos` datetime DEFAULT NULL,
  `data_mod_pos` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_pos`),
  KEY `cod_pos` (`cod_pos`,`id_empresa`,`lixeira`,`cnpj_empresa`,`status`,`order_id_processando`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_stone_vinculo_caixa`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_stone_vinculo_caixa` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_pos` int(11) NOT NULL,
  `id_pdv` int(11) NOT NULL,
  `padrao` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_vinculo`),
  KEY `id_empresa` (`id_empresa`,`id_pos`,`id_pdv`,`padrao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_tokens`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_tokens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(10) unsigned NOT NULL,
  `id_empresa` int(10) unsigned NOT NULL,
  `access_token` text COLLATE utf8mb4_unicode_ci,
  `expires_in` int(10) unsigned NOT NULL DEFAULT '0',
  `data_cad_usuario` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_usuario` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_tray`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_tray` (
  `id_tray` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `store_id` bigint(20) NOT NULL DEFAULT '0',
  `access_token` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refresh_token` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiration_access_token` datetime DEFAULT NULL,
  `expiration_refresh_token` datetime DEFAULT NULL,
  `api_address` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `config_sinc_estoque` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `config_sinc_clientes` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `config_sinc_produtos` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `logado` tinyint(1) DEFAULT '1',
  `data_cadastro` datetime DEFAULT NULL,
  `data_modificacao` datetime DEFAULT NULL,
  PRIMARY KEY (`id_tray`),
  KEY `store_id` (`store_id`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_tray_clientes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_tray_clientes` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) NOT NULL DEFAULT '0',
  `id_cliente_tray` bigint(20) NOT NULL DEFAULT '0',
  `nome_cliente` char(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_sincronizacao` datetime NOT NULL,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa_id_cliente_id_cliente_tray` (`id_empresa`,`id_cliente`,`id_cliente_tray`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_tray_pedidos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_tray_pedidos` (
  `id_ped` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_pedido_tray` bigint(20) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) DEFAULT '0',
  `id_cliente_tray` bigint(20) DEFAULT '0',
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_total_nota` decimal(10,2) DEFAULT '0.00',
  `transportadora_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frete_pedido` decimal(10,2) DEFAULT '0.00',
  `data_pedido` date DEFAULT NULL,
  `pagamento` mediumtext COLLATE utf8mb4_unicode_ci,
  `obs_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `obs_interna_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `status_pedido` char(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Em Aberto',
  `pedido_emitido` tinyint(1) DEFAULT '0',
  `data_cad_pedido` datetime DEFAULT NULL,
  `data_mod_pedido` datetime DEFAULT NULL,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_ped`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_tray_pedidos_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_tray_pedidos_produtos` (
  `id_ped_produto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_ped` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `id_produto_tray` bigint(20) NOT NULL DEFAULT '0',
  `id_variacao_tray` bigint(20) NOT NULL DEFAULT '0',
  `desc_produto` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qtde_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_unit_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_total_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_ped_produto`),
  KEY `id_produto` (`id_produto`),
  KEY `id_ped` (`id_ped`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_tray_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_tray_produtos` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `id_produto_tray` bigint(20) NOT NULL DEFAULT '0',
  `nome_produto` char(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `variations` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `data_sincronizacao` datetime NOT NULL,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `id_empresa_id_produto_id_produto_tray` (`id_empresa`,`id_produto`,`id_produto_tray`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_vendamais`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_vendamais` (
  `id_vendamais` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `nome_usuario` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_compralista` int(11) NOT NULL DEFAULT '0',
  `nome_lista` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_empresas` int(11) DEFAULT NULL,
  `estado` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `json_cidades` longtext COLLATE utf8mb4_unicode_ci,
  `json_segmentos` longtext COLLATE utf8mb4_unicode_ci,
  `capital_social_de` decimal(10,2) NOT NULL DEFAULT '0.00',
  `capital_social_para` decimal(10,2) NOT NULL DEFAULT '0.00',
  `apenas_email` tinyint(1) NOT NULL DEFAULT '0',
  `apenas_telefone` tinyint(1) NOT NULL DEFAULT '0',
  `popularidade` tinyint(1) NOT NULL DEFAULT '0',
  `valor_lista` decimal(10,2) NOT NULL DEFAULT '0.00',
  `arquivo_csv` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `importado_funil` tinyint(1) NOT NULL DEFAULT '0',
  `data_importacao_funil` datetime DEFAULT NULL,
  `data_cad_compra` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_vendamais`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_vendamais_configuracoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_vendamais_configuracoes` (
  `valor_por_empresa` decimal(10,2) NOT NULL,
  `valor_por_empresa_movimentacao` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_vendamais_leads`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_vendamais_leads` (
  `id_vendamais_leads` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_vendamais` int(11) NOT NULL DEFAULT '0',
  `cnpj` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `popularity` int(11) DEFAULT NULL,
  `telefone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `municipio` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uf` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fantasia` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logradouro` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero` smallint(6) DEFAULT NULL,
  `complemento` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `abertura` datetime DEFAULT NULL,
  `natureza_juridica` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `situacao` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_situacao` datetime DEFAULT NULL,
  `situacao_especial` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `motivo_situacao_especial` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_situacao_especial` datetime DEFAULT NULL,
  `capital_social` decimal(10,2) DEFAULT '0.00',
  `efr` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_vendamais_leads`),
  KEY `id_vendamais` (`id_vendamais`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_vhdesk`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_vhdesk` (
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_empresa_vhdesk` int(11) NOT NULL DEFAULT '0',
  `endereco_vhdesk` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `titulo_vhdesk` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao_vhdesk` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_empresa_vhdesk` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone_empresa_vhdesk` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cnpj_empresa_vhdesk` char(18) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_tags_vhdesk` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receber_notificacao` tinyint(1) NOT NULL DEFAULT '0',
  `receber_email` tinyint(1) NOT NULL DEFAULT '0',
  `reabrir_chamados` tinyint(1) NOT NULL DEFAULT '0',
  `cadastro_facebook` tinyint(1) NOT NULL DEFAULT '0',
  `cadastro_google` tinyint(1) NOT NULL DEFAULT '0',
  `cadastro_confirmacao` tinyint(1) NOT NULL DEFAULT '0',
  `codigo_html` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo_empresa` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `social_facebook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_twitter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_site` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_instagram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_linkedin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_gplus` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numeracao_chamado` int(11) DEFAULT NULL,
  `data_cad_vhdesk` datetime NOT NULL,
  `data_mod_vhdesk` datetime NOT NULL,
  `data_sinc_vhdesk` datetime NOT NULL,
  UNIQUE KEY `endereco_vhdesk` (`endereco_vhdesk`),
  KEY `id_empresa_vhdesk` (`id_empresa_vhdesk`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_vhdesk_atividade_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_vhdesk_atividade_status` (
  `id_atividade` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_chamado` int(11) NOT NULL DEFAULT '0',
  `status_chamado` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_status` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_status` datetime DEFAULT NULL,
  PRIMARY KEY (`id_atividade`),
  KEY `id_chamado` (`id_chamado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_vhdesk_chamados`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_vhdesk_chamados` (
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_empresa_vhdesk` int(11) NOT NULL DEFAULT '0',
  `id_chamado` int(11) NOT NULL DEFAULT '0',
  `numeracao_chamado` int(11) NOT NULL DEFAULT '1',
  `nome_cliente` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `assunto_chamado` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_chamado` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operador_vhsys` int(11) NOT NULL DEFAULT '0',
  `operador_nome` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prioridade_chamado` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cor_prioridade` char(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avaliacao_chamado` decimal(10,2) DEFAULT NULL,
  `lido_chamado_empresa` tinyint(1) NOT NULL DEFAULT '0',
  `lido_chamado_cliente` tinyint(1) NOT NULL DEFAULT '0',
  `encerrado_chamado` tinyint(1) NOT NULL DEFAULT '0',
  `data_cad_chamado` datetime NOT NULL,
  `data_mod_chamado` datetime NOT NULL,
  `data_fechado` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  KEY `id_empresa` (`id_empresa`),
  KEY `id_chamado` (`id_chamado`),
  KEY `id_empresa_vhdesk` (`id_empresa_vhdesk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_vhdrive`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_vhdrive` (
  `id_arquivo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_categoria` int(11) NOT NULL DEFAULT '0',
  `identificacao` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pasta_arquivo` char(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_arquivo` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `titulo_arquivo` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `observacao_arquivo` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extensao_arquivo` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tamanho_arquivo` int(11) NOT NULL DEFAULT '0',
  `privado` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `link` enum('Publico','Privado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Publico',
  `downloads` int(11) NOT NULL DEFAULT '0',
  `usuario_cad_nome` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usuario_cad_arquivo` int(11) DEFAULT '0',
  `data_cad_arquivo` datetime NOT NULL,
  `data_exclusao` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_arquivo`),
  KEY `id_categoria` (`id_categoria`),
  KEY `usuario_cad_arquivo` (`usuario_cad_arquivo`),
  KEY `identificacao` (`identificacao`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_vhdrive_categorias`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_vhdrive_categorias` (
  `id_categoria` tinyint(1) NOT NULL,
  `nome_categoria` char(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pasta_categoria` char(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consome_espaco` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sim',
  `identificador` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_slug` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_vhdrive_config`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_vhdrive_config` (
  `id_config` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `tipo_listagem` enum('Bloco','Lista') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Bloco',
  `ordem_listagem_campo` enum('Nome','Espaco') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nome',
  `ordem_listagem` enum('Asc','Desc') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Asc',
  PRIMARY KEY (`id_config`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_woocommerce`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_woocommerce` (
  `id_woocommerce` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `store_url` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `consumer_key` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `consumer_secret` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `config_sinc_estoque` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `config_sinc_clientes` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `config_sinc_produtos` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `basic_auth` tinyint(1) NOT NULL DEFAULT '0',
  `logado` tinyint(1) DEFAULT '1',
  `data_cadastro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_modificacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `tentativa_autenticacao` enum('LOGIN','CHAVES') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'LOGIN',
  PRIMARY KEY (`id_woocommerce`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_woocommerce_clientes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_woocommerce_clientes` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) NOT NULL DEFAULT '0',
  `id_cliente_woocommerce` bigint(20) NOT NULL DEFAULT '0',
  `nome_cliente` char(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_sincronizacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa_id_cliente_id_cliente_woocommerce` (`id_empresa`,`id_cliente`,`id_cliente_woocommerce`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_woocommerce_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_woocommerce_log` (
  `id_woocommerce_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `headers` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `input` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Negado','Aceito') COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_woocommerce_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_woocommerce_log`),
  KEY `id_woocommerce_log` (`id_woocommerce_log`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_woocommerce_pedidos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_woocommerce_pedidos` (
  `id_ped` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_pedido_woocommerce` bigint(20) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) DEFAULT '0',
  `id_cliente_woocommerce` bigint(20) DEFAULT '0',
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_total_nota` decimal(10,2) DEFAULT '0.00',
  `transportadora_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frete_pedido` decimal(10,2) DEFAULT '0.00',
  `data_pedido` date DEFAULT NULL,
  `pagamento` mediumtext COLLATE utf8mb4_unicode_ci,
  `obs_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `status_pedido` char(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Em Aberto',
  `pedido_emitido` tinyint(1) DEFAULT '0',
  `data_cad_pedido` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_pedido` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_ped`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_woocommerce_pedidos_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_woocommerce_pedidos_produtos` (
  `id_ped_produto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_ped` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `id_produto_woocommerce` bigint(20) NOT NULL DEFAULT '0',
  `id_variacao_woocommerce` bigint(20) NOT NULL DEFAULT '0',
  `desc_produto` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `variacoes` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `qtde_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_unit_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_total_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_ped_produto`),
  KEY `id_produto` (`id_produto`),
  KEY `id_ped` (`id_ped`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_woocommerce_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_woocommerce_produtos` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `id_produto_woocommerce` bigint(20) NOT NULL DEFAULT '0',
  `nome_produto` char(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `variations` longtext COLLATE utf8mb4_unicode_ci,
  `data_sincronizacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `id_empresa_id_produto_id_produto_wocommerce` (`id_empresa`,`id_produto`,`id_produto_woocommerce`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_woocommerce_webhooks_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_woocommerce_webhooks_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `webhooks_enviados` longtext COLLATE utf8mb4_unicode_ci,
  `resultado_post` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_xtech`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_xtech` (
  `id_xtech` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_usuario` bigint(20) NOT NULL,
  `site_id` bigint(20) DEFAULT NULL,
  `hash` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_key` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dominio` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sync_pedidos` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `sync_produtos` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `sync_clientes` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `data_ultima_sync` datetime DEFAULT NULL,
  `data_cad_setting` datetime DEFAULT NULL,
  `data_mod_setting` datetime DEFAULT NULL,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_xtech`),
  KEY `lixeira` (`lixeira`),
  KEY `site_id` (`site_id`),
  KEY `api_key` (`api_key`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`),
  KEY `hash` (`hash`),
  KEY `dominio` (`dominio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_xtech_clientes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_xtech_clientes` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) NOT NULL DEFAULT '0',
  `id_cliente_xtech` bigint(20) NOT NULL DEFAULT '0',
  `nome_cliente` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `documento` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_id` bigint(20) DEFAULT NULL,
  `status` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `data_cad_vinculo` datetime DEFAULT NULL,
  `data_mod_vinculo` datetime DEFAULT NULL,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_cliente_xtech` (`id_cliente_xtech`),
  KEY `documento` (`documento`),
  KEY `nome_cliente` (`nome_cliente`),
  KEY `id_cliente` (`id_cliente`),
  KEY `lixeira` (`lixeira`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_xtech_pedidos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_xtech_pedidos` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_pedido` bigint(20) NOT NULL DEFAULT '0',
  `id_pedido_xtech` bigint(20) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) NOT NULL,
  `id_cliente_xtech` bigint(20) NOT NULL,
  `pedido_numero_xtech` bigint(20) DEFAULT NULL,
  `site_id` bigint(20) DEFAULT NULL,
  `nome_cliente` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_total` decimal(10,2) DEFAULT '0.00',
  `transportadora_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_frete` decimal(10,2) DEFAULT '0.00',
  `data_pedido` datetime DEFAULT NULL,
  `pagamento` mediumtext COLLATE utf8mb4_unicode_ci,
  `obs_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pedido_emitido` longtext COLLATE utf8mb4_unicode_ci,
  `quantidade` bigint(20) DEFAULT '0',
  `data_envio` datetime DEFAULT NULL,
  `data_cad_vinculo` datetime DEFAULT NULL,
  `data_mod_vinculo` datetime DEFAULT NULL,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `nome_cliente` (`nome_cliente`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_pedido_xtech` (`id_pedido_xtech`),
  KEY `id_cliente` (`id_cliente`),
  KEY `pedido_numero_xtech` (`pedido_numero_xtech`),
  KEY `id_pedido` (`id_pedido`),
  KEY `lixeira` (`lixeira`),
  KEY `id_cliente_xtech` (`id_cliente_xtech`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_xtech_pedidos_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_xtech_pedidos_produtos` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_pedido` bigint(20) NOT NULL DEFAULT '0',
  `id_pedido_xtech` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL,
  `id_produto_xtech` bigint(20) NOT NULL,
  `id_variacao_xtech` bigint(20) DEFAULT NULL,
  `nome_produto` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_vinculo` datetime DEFAULT NULL,
  `data_mod_vinculo` datetime DEFAULT NULL,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_pedido_xtech` (`id_pedido_xtech`),
  KEY `id_produto` (`id_produto`),
  KEY `id_variado` (`id_variacao_xtech`),
  KEY `id_pedido` (`id_pedido`),
  KEY `lixeira` (`lixeira`),
  KEY `id_produto_xtech` (`id_produto_xtech`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_xtech_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_xtech_produtos` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `id_produto_xtech` bigint(20) NOT NULL DEFAULT '0',
  `id_variacao_xtech` bigint(20) DEFAULT NULL,
  `nome_produto` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `sku` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `site_id` bigint(20) DEFAULT NULL,
  `status` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `variacao` longtext COLLATE utf8mb4_unicode_ci,
  `data_cad_vinculo` datetime DEFAULT NULL,
  `data_mod_vinculo` datetime DEFAULT NULL,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_vinculo`),
  KEY `id_produto` (`id_produto`),
  KEY `lixeira` (`lixeira`),
  KEY `site_id` (`site_id`),
  KEY `nome_produto` (`nome_produto`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_produto_xtech` (`id_produto_xtech`),
  KEY `sku` (`sku`),
  KEY `id_variacao` (`id_variacao_xtech`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `app_xtech_webhook_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `app_xtech_webhook_log` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `site_id` bigint(20) DEFAULT NULL,
  `tipo` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conteudo` longtext COLLATE utf8mb4_unicode_ci,
  `code` smallint(6) DEFAULT NULL,
  `error` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `boleto_bradesco_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `boleto_bradesco_log` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_fatura` int(11) DEFAULT NULL,
  `resposta` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`),
  KEY `id_fatura` (`id_fatura`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `checkout`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `checkout` (
  `id_checkout` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo_checkout` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_segmento` int(11) NOT NULL DEFAULT '0',
  `id_fatura` int(11) DEFAULT NULL,
  `id_plano` int(11) DEFAULT NULL,
  `id_servico_pai` int(11) NOT NULL DEFAULT '0',
  `valor_total` decimal(10,2) DEFAULT NULL,
  `periodicidade_checkout` int(11) DEFAULT NULL,
  `limite_nota` int(11) NOT NULL DEFAULT '0',
  `limite_usuario` int(11) NOT NULL DEFAULT '0',
  `id_cupom` int(11) DEFAULT '0',
  `data_cad_checkout` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_checkout` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_checkout`),
  UNIQUE KEY `codigo_checkout` (`codigo_checkout`),
  KEY `id_plano` (`id_plano`),
  KEY `id_servico_pai` (`id_servico_pai`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `checkout_itens`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `checkout_itens` (
  `id_item` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_checkout` int(11) DEFAULT NULL,
  `id_plano` int(11) DEFAULT NULL,
  `id_checkout_servico` int(11) DEFAULT '0',
  `desc_servico` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_servico` decimal(10,2) DEFAULT NULL,
  `tipo_servico` enum('Plano','Adicional') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `checkout_segmentos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `checkout_segmentos` (
  `id_segmento` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `plano_padrao` smallint(6) DEFAULT '0',
  `nome_segmento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `padrao` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_segmento`),
  UNIQUE KEY `slug_UNIQUE` (`slug`),
  KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `checkout_segmentos_servicos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `checkout_segmentos_servicos` (
  `id_segmento` int(11) DEFAULT NULL,
  `id_checkout_servico` int(11) DEFAULT NULL,
  `valor_promocional` decimal(10,2) DEFAULT '0.00',
  KEY `id_servico` (`id_checkout_servico`),
  KEY `id_segmento` (`id_segmento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `checkout_servicos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `checkout_servicos` (
  `id_checkout_servico` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_plano` int(11) DEFAULT NULL,
  `nome_servico` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chamada_servico` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descricao_servico` text COLLATE utf8mb4_unicode_ci,
  `recorrente` tinyint(1) DEFAULT '1',
  `trial` tinyint(1) DEFAULT '1',
  `data_cad_servico` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_servico` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_checkout_servico`),
  KEY `id_plano` (`id_plano`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `checkout_servicos_imagens`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `checkout_servicos_imagens` (
  `id_imagem` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_checkout_servico` int(11) DEFAULT NULL,
  `nome_imagem` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_imagem`),
  KEY `id_servico_checkout` (`id_checkout_servico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cielo_erro_integracao`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `cielo_erro_integracao` (
  `id_erro_integracao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mensagem` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `acao` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_erro_integracao`),
  KEY `id_erro_integracao` (`id_erro_integracao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cielo_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `cielo_log` (
  `id_cielo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_fatura` int(11) NOT NULL DEFAULT '0',
  `tid_cielo` char(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_lr_cielo` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_status` tinyint(1) NOT NULL,
  `tipo_consulta` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_consulta` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `msg_cielo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_cielo`),
  KEY `idx_id_fatura_cod_status` (`id_fatura`,`codigo_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cielo_status_transacao`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `cielo_status_transacao` (
  `id_status_transacao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_status_transacao`),
  KEY `id_status_transacao` (`id_status_transacao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cielo_taxas_cartoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `cielo_taxas_cartoes` (
  `id_taxa` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bandeira_cartao` enum('visa','mastercard','diners','discover','elo','amex','jcb','aura') COLLATE utf8mb4_unicode_ci NOT NULL,
  `prazo_cartao` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parcela_cartao` int(11) DEFAULT NULL,
  `taxa_cielo` double(5,2) DEFAULT NULL,
  PRIMARY KEY (`id_taxa`),
  KEY `bandeira_cartao_parcela_cartao` (`bandeira_cartao`,`parcela_cartao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `codigo_gclid`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `codigo_gclid` (
  `id_gclid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_plano` int(11) NOT NULL DEFAULT '0',
  `valor_plano` decimal(10,2) DEFAULT '0.00',
  `data_contratacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `gclid` varchar(400) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_gclid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_aprovacao`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_aprovacao` (
  `id_aprovacao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `desconto_aprovacao` decimal(10,2) NOT NULL DEFAULT '0.00',
  `motivo_aprovacao` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario_aprovacao` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_aprovacao` datetime NOT NULL,
  `usuario_aprovado` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_aprovado` datetime DEFAULT NULL,
  `status_aprovacao` enum('Aprovado','Reprovado','Pendente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pendente',
  `status_motivo` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_aprovacao`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`),
  KEY `aprovado` (`status_aprovacao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_cadastros_onboarding`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_cadastros_onboarding` (
  `id_onboarding` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `formalizada` tinyint(1) DEFAULT NULL,
  `documento` varchar(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_cidade` int(11) DEFAULT NULL,
  `mais_precisa` int(11) DEFAULT NULL,
  `setor` int(11) DEFAULT NULL,
  `etapa` int(11) NOT NULL,
  `data_cad_onboarding` datetime DEFAULT NULL,
  `data_mod_onboarding` datetime DEFAULT NULL,
  PRIMARY KEY (`id_onboarding`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_cadastros_onboarding_recursos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_cadastros_onboarding_recursos` (
  `id_recurso` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_onboarding` int(11) NOT NULL,
  `recurso` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_recurso`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_campanha_empresas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_campanha_empresas` (
  `id_campanha` int(11) DEFAULT NULL,
  `id_empresa` int(11) DEFAULT NULL,
  `data_cad` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_campanhas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_campanhas` (
  `id_campanha` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome_campanha` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_inicio` date NOT NULL,
  `data_fim` date DEFAULT NULL,
  `tipo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_campanha` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_campanha` datetime DEFAULT NULL,
  PRIMARY KEY (`id_campanha`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_config`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_config` (
  `id_config` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `meta_diaria` decimal(10,2) NOT NULL,
  `meta_mensal` decimal(10,2) NOT NULL,
  `meta_diaria_externo` decimal(10,2) NOT NULL,
  `meta_mensal_externo` decimal(10,2) NOT NULL,
  `meta_diaria_parceiros` decimal(10,2) NOT NULL,
  `meta_mensal_parceiros` decimal(10,2) NOT NULL,
  `tempo_trial` int(11) NOT NULL,
  `tempo_trial_novo` int(11) NOT NULL,
  `limite_programar_pagamento` date NOT NULL,
  `limite_trial_novo` smallint(6) NOT NULL DEFAULT '1',
  `limite_discador_novo` smallint(6) NOT NULL DEFAULT '1',
  `limite_discador_agendamento` smallint(6) NOT NULL DEFAULT '1',
  `limite_tentativas_dia` smallint(6) NOT NULL DEFAULT '1',
  `limite_tentativas_cadastro` smallint(6) NOT NULL DEFAULT '1',
  `limite_tentativas_dia_cobranca` smallint(6) NOT NULL DEFAULT '1',
  `limite_tentativas_cadastro_cobranca` smallint(6) NOT NULL DEFAULT '1',
  `reagendar_congest` tinyint(1) NOT NULL DEFAULT '0',
  `ligacoes_simultaneas_novo` smallint(6) NOT NULL DEFAULT '1',
  `ligacoes_simultaneas_agendamento` smallint(6) NOT NULL DEFAULT '1',
  `ligacoes_simultaneas_cobranca` smallint(6) NOT NULL DEFAULT '1',
  `horario_agenda` tinyint(1) NOT NULL DEFAULT '13',
  `ligar_freemium` tinyint(1) NOT NULL DEFAULT '0',
  `espera_discador` int(11) DEFAULT NULL,
  `rota` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_config`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_discador`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_discador` (
  `id_discador` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_discador`),
  UNIQUE KEY `id_empresa_uniq` (`id_empresa`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_discador_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_discador_log` (
  `id_discador` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url_discador` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `local_saida` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `retorno_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_empresa` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_discador`),
  KEY `id_discador` (`id_discador`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_empresas_origens`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_empresas_origens` (
  `id_origem` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `origem` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_origem` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_origem`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa_origem` (`id_origem`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_engajamentoscore`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_engajamentoscore` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `data` datetime NOT NULL,
  `valor` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_engajamentoscore_config`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_engajamentoscore_config` (
  `id_engajamentoscore` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_secao_engajamentoscore` int(11) DEFAULT NULL,
  `id_modulo_engajamentoscore` int(11) DEFAULT NULL,
  `secao_engajamentoscore` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modulo_engajamentoscore` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `peso_engajamentoscore` int(11) DEFAULT NULL,
  `data_cad_engajamentoscore` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_engajamentoscore` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `usuario_cad_engajamentoscore` int(11) DEFAULT NULL,
  `usuario_mod_engajamentoscore` int(11) DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_engajamentoscore`),
  KEY `id_engajamentoscore` (`id_engajamentoscore`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_engajamentoscore_detalhes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_engajamentoscore_detalhes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `modulo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantidade_acessos` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_healthscore`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_healthscore` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `data` datetime NOT NULL,
  `valor` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_healthscore_config`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_healthscore_config` (
  `id_healthscore` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `chave_healthscore` char(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc_healthscore` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `maximo_healthscore` int(11) NOT NULL DEFAULT '0',
  `minimo_healthscore` int(11) NOT NULL DEFAULT '0',
  `peso_healthsocore` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_healthscore`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_healthscore_detalhes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_healthscore_detalhes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `indicador` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_leads`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_leads` (
  `id_lead` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_parceiro` int(11) NOT NULL DEFAULT '0',
  `id_contabilidade` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `code_lead` int(11) NOT NULL DEFAULT '0',
  `empresa_lead` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `responsavel_lead` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_lead` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone_lead` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `celular_lead` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cidade_lead` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estado_lead` char(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc_situacao` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `primeira_conversao_lead` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ultima_conversao_lead` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversao_numero_lead` int(11) NOT NULL,
  `pontuacao_lead` int(11) NOT NULL DEFAULT '0',
  `etapa_lead` int(11) NOT NULL DEFAULT '0',
  `campos_lead` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `origem_primeira_conversao` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `origem_ultima_conversao` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_score` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_mod_lead` datetime DEFAULT NULL,
  `data_cad_lead` datetime NOT NULL,
  `trial` tinyint(1) NOT NULL DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_lead`),
  KEY `id_parceiro` (`id_parceiro`),
  KEY `id_contabilidade` (`id_contabilidade`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_leads_config`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_leads_config` (
  `id_config` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `limite_discador_novo` smallint(6) NOT NULL DEFAULT '1',
  `limite_discador_agendamento` smallint(6) NOT NULL DEFAULT '1',
  `limite_tentativas_dia` smallint(6) NOT NULL DEFAULT '1',
  `limite_tentativas_cadastro` smallint(6) NOT NULL DEFAULT '1',
  `reagendar_congest` tinyint(1) NOT NULL DEFAULT '0',
  `ligacoes_simultaneas_novo` smallint(6) NOT NULL DEFAULT '1',
  `ligacoes_simultaneas_agendamento` smallint(6) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_config`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_leads_conversas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_leads_conversas` (
  `id_conversa` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_lead` int(11) NOT NULL DEFAULT '0',
  `desc_conversa` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `situacao_conversa` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_prox_conversa` date NOT NULL,
  `hora_prox_conversa` time NOT NULL,
  `usuario_conversa` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_conversa` datetime NOT NULL,
  `unique_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_conversa`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_lead`),
  KEY `situacao_conversa` (`situacao_conversa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_leads_conversoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_leads_conversoes` (
  `id_conversao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_lead` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `conversao` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_conversao` datetime NOT NULL,
  PRIMARY KEY (`id_conversao`),
  KEY `id_lead` (`id_lead`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_leads_discador`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_leads_discador` (
  `id_discador` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_lead` int(11) NOT NULL DEFAULT '0',
  `id_usuario` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_discador`),
  KEY `id_lead` (`id_lead`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_potenciais`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_potenciais` (
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `potencial_cliente` tinyint(1) NOT NULL DEFAULT '0',
  `data_atualizacao` datetime NOT NULL,
  KEY `id_empresa` (`id_empresa`),
  KEY `potencial_cliente` (`potencial_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_potenciais_bkp`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_potenciais_bkp` (
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `potencial_cliente` tinyint(1) NOT NULL DEFAULT '0',
  `data_atualizacao` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_potenciais_tmp`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_potenciais_tmp` (
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `potencial_cliente` tinyint(1) NOT NULL DEFAULT '0',
  `data_atualizacao` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_qualificacao`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_qualificacao` (
  `id_empresa` int(11) DEFAULT NULL,
  `cluster` int(11) DEFAULT NULL,
  `score` int(11) DEFAULT NULL,
  `data` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_rota_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_rota_log` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `numero` char(15) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `rota` char(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `retorno_rota` text COLLATE utf8mb4_unicode_ci,
  `rediscado` double NOT NULL DEFAULT '0',
  `data_cad_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`),
  KEY `id_log` (`id_log`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_situacoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_situacoes` (
  `id_situacao` tinyint(1) NOT NULL,
  `desc_situacao` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cor_situacao` char(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#000000',
  `ordem` tinyint(1) NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  KEY `desc_situacao` (`desc_situacao`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_situacoes_permissao`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_situacoes_permissao` (
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `id_situacao` tinyint(1) NOT NULL DEFAULT '0',
  KEY `id_permissao` (`id_situacao`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `crm_usuarios_online`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `crm_usuarios_online` (
  `id_acesso` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `id_lead` int(11) NOT NULL,
  `usuario` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tempo` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_acesso`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_lead` (`id_lead`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cs_config`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `cs_config` (
  `id_config` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tempo_1_contato` int(11) NOT NULL DEFAULT '1',
  `limite_tentativas_dia` tinyint(1) NOT NULL DEFAULT '1',
  `limite_tentativas_cadastro` tinyint(1) NOT NULL DEFAULT '1',
  `limite_discador` tinyint(1) NOT NULL DEFAULT '1',
  `abrir_chamado` tinyint(1) NOT NULL DEFAULT '1',
  `situacoes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mensagem_chamado` mediumtext COLLATE utf8mb4_unicode_ci,
  `espera_discador` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_config`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cs_discador`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `cs_discador` (
  `id_discador` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `situacao_conversa` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_discador`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cs_discador_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `cs_discador_log` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `desc_log` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`),
  KEY `id_log` (`id_log`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cs_relatorio_diazero`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `cs_relatorio_diazero` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `situacao_conversa` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` date NOT NULL,
  `numero_contato` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `situacao_conversa` (`situacao_conversa`),
  KEY `data` (`data`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cte_mdfe_qrcode`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `cte_mdfe_qrcode` (
  `id_estado_qr` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `estado` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cte_amb_1` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL,
  `cte_amb_2` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL,
  `mdfe_amb_1` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL,
  `mdfe_amb_2` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_linha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_linha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_estado_qr`),
  KEY `estado` (`estado`),
  KEY `id_estado_qr` (`id_estado_qr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cte_nt_pput`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `cte_nt_pput` (
  `id_estado_nt` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `estado` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cte_amb_1` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL,
  `cte_amb_2` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_linha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_linha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_estado_nt`),
  KEY `estado` (`estado`),
  KEY `id_estado_nt` (`id_estado_nt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `despesa_recorrente_agendamento`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `despesa_recorrente_agendamento` (
  `id_agendamento` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_custo_fixo` bigint(20) unsigned NOT NULL,
  `id_conta_pag` bigint(20) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 = preview, 2 = lançado, 3 = estornado, 4 = excluído',
  `valor_custo` decimal(10,2) NOT NULL DEFAULT '0.00',
  `data_agendamento` datetime NOT NULL,
  `data_cad_agendamento` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_agendamento` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_agendamento`),
  KEY `despesa_recorrente_agendamento_id_custo_fixo_foreign` (`id_custo_fixo`),
  CONSTRAINT `despesa_recorrente_agendamento_id_custo_fixo_foreign` FOREIGN KEY (`id_custo_fixo`) REFERENCES `nfe_financeiro_custos_fixos` (`id_custo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dw_empresas_modelo`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `dw_empresas_modelo` (
  `id_empresa` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feedback`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `feedback` (
  `id_feedback` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `nome_usuario` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modulo_feedback` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `satisfacao` tinyint(1) DEFAULT '1',
  `feedback` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resolvido` tinyint(1) NOT NULL DEFAULT '0',
  `data_cad_feedback` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_feedback`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feedback_old`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `feedback_old` (
  `id_feedback` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `nome_usuario` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modulo_feedback` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resolvido` tinyint(1) NOT NULL DEFAULT '0',
  `data_cad_feedback` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `satisfacao` tinyint(1) NOT NULL DEFAULT '1',
  `feedback` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_feedback`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feriados`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `feriados` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` date DEFAULT NULL,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fornecedores_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `fornecedores_produtos` (
  `Pro_Codigo` int(11) NOT NULL DEFAULT '0',
  `For_Codigo` int(11) NOT NULL DEFAULT '0',
  `For_ProCodigo` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `For_ProTributacao` int(11) DEFAULT NULL,
  `For_PercICMS` double DEFAULT NULL,
  `For_CSTIPI` int(11) DEFAULT NULL,
  `For_PercIPI` double DEFAULT NULL,
  `For_CSTPIS` int(11) DEFAULT NULL,
  `For_PercPIS` double DEFAULT NULL,
  `For_CSTCOFINS` int(11) DEFAULT NULL,
  `For_PercCOFINS` double DEFAULT NULL,
  `Pro_Referencia` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `UnMed_Codigo` int(11) DEFAULT NULL,
  KEY `Fornecedores_Produto_Fornecedor` (`For_Codigo`),
  KEY `Fornecedores_Produtos_UnidadeMedida` (`UnMed_Codigo`),
  KEY `Fornecedores_Produto_ProdRefere` (`Pro_Referencia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=713 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_anp`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_anp` (
  `id_anp` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo_anp` char(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `descricao_anp` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_anp`),
  UNIQUE KEY `codigo_anp` (`codigo_anp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_aprovacao_fatura`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_aprovacao_fatura` (
  `id_aprovacao_fatura` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario_adm` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL,
  `aprovada` enum('Sim','Nao','Pendente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pendente',
  `nome_empresa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_fatura` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vencimento_fatura` date NOT NULL,
  `obs_descritivo` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_pagamento` enum('Boleto','Cartao','Creditos') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Boleto',
  `nota_fiscal` int(11) NOT NULL DEFAULT '0',
  `parcelamento_fatura` tinyint(1) DEFAULT '1',
  `obs_pagamento` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `periodicidade_pagamento` tinyint(1) NOT NULL DEFAULT '1',
  `primeira_fatura` tinyint(1) NOT NULL DEFAULT '0',
  `gerado_por` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sistema',
  `data_cad_aprovacao_fatura` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_aprovacao_fatura`),
  KEY `id_usuario_adm` (`id_usuario_adm`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_aprovacao_fatura_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_aprovacao_fatura_log` (
  `id_aprovacao_fatura_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `id_aprovacao_fatura` int(11) NOT NULL,
  `descricao` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_aprovacao_fatura_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_aprovacao_fatura_log`),
  KEY `id_aprovacao_fatura_log` (`id_aprovacao_fatura_log`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_aprovacao_servico`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_aprovacao_servico` (
  `id_aprovacao_servico` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_servico` int(11) DEFAULT '0',
  `id_usuario_adm` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_plano` int(11) NOT NULL DEFAULT '0',
  `aprovada` enum('Sim','Nao','Pendente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pendente',
  `valor_servico` decimal(10,2) DEFAULT NULL,
  `valor_acrescimo` tinyint(1) DEFAULT '0',
  `tipo_pagamento` tinyint(1) DEFAULT NULL,
  `parcelamento_servico` tinyint(1) DEFAULT NULL,
  `obs_servico` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proximo_mes` date DEFAULT NULL,
  `data_expiracao` date DEFAULT NULL,
  `data_cad_aprovacao_servico` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_aprovacao_servico`),
  KEY `id_usuario_adm` (`id_usuario_adm`),
  KEY `id_plano` (`id_plano`),
  KEY `id_aprovacao_servico` (`id_aprovacao_servico`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_aprovacao_servico_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_aprovacao_servico_log` (
  `id_aprovacao_servico_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `id_aprovacao_servico` int(11) NOT NULL,
  `descricao` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_aprovacao_servico_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_aprovacao_servico_log`),
  KEY `id_aprovacao_servico_log` (`id_aprovacao_servico_log`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_bancos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_bancos` (
  `id_banco` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `numero_banco` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_banco` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icone_banco` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icone_simple` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icone_codificado` text COLLATE utf8mb4_unicode_ci,
  `arquivo_banco` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `boleto` tinyint(1) NOT NULL DEFAULT '0',
  `com_registro` tinyint(1) NOT NULL DEFAULT '0',
  `layout_cobranca` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `OutroDadoConfiguracao1` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `OutroDadoConfiguracao2` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_banco` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Inativo',
  PRIMARY KEY (`id_banco`),
  UNIQUE KEY `numero_banco_com_registro` (`numero_banco`,`com_registro`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_bancos_carteiras`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_bancos_carteiras` (
  `id_carteira` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `id_banco` smallint(6) NOT NULL DEFAULT '0',
  `com_registro` tinyint(1) NOT NULL DEFAULT '0',
  `cod_carteira` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `desc_carteira` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mascara_agencia` char(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mascara_conta` char(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mascara_convenio` char(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mascara_cedente` char(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dig_agencia` tinyint(1) NOT NULL DEFAULT '0',
  `dig_conta` tinyint(1) NOT NULL DEFAULT '0',
  `dig_convenio` tinyint(1) NOT NULL DEFAULT '0',
  `dig_cedente` tinyint(1) NOT NULL DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_carteira`),
  KEY `id_banco` (`id_banco`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_bancos_layout_operacoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_bancos_layout_operacoes` (
  `id_banco` tinyint(1) NOT NULL,
  `layout_cobranca` char(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_operacao` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exibir_instrucao` tinyint(1) NOT NULL DEFAULT '1',
  KEY `idx_banco_layout_operacao` (`id_banco`,`layout_cobranca`,`codigo_operacao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_bancos_remessa`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_bancos_remessa` (
  `id_operacao` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `banco_operacao` smallint(6) NOT NULL,
  `codigo_operacao` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao_operacao` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visivel` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_operacao`),
  KEY `codigo_operacao` (`codigo_operacao`),
  KEY `banco_operacao` (`banco_operacao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_bancos_retorno`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_bancos_retorno` (
  `id_operacao` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `banco_operacao` smallint(6) NOT NULL,
  `codigo_operacao` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao_operacao` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_operacao`),
  KEY `banco_operacao` (`banco_operacao`),
  KEY `codigo_operacao` (`codigo_operacao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_bancos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_bancos` (
  `id_banco_cad` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT '0',
  `id_banco` smallint(6) DEFAULT '0',
  `nome_banco_cad` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `saldo_inicial` decimal(10,2) DEFAULT '0.00',
  `saldo_inicial_data` date DEFAULT NULL,
  `gerar_boletos` tinyint(1) DEFAULT '1',
  `id_carteira` smallint(6) DEFAULT '0',
  `carteira_banco` char(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `convenio_banco` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cedente_banco` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codcliente_banco` char(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agencia_banco` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agencia_dv_banco` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conta_banco` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conta_dv_banco` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_cedente` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instrucoes_boleto` longtext COLLATE utf8mb4_unicode_ci,
  `local_pagamento` char(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Pagável em qualquer banco até o vencimento.',
  `atualizar_dados_boleto` tinyint(1) DEFAULT '1',
  `atualizar_boletos` tinyint(1) DEFAULT '0',
  `modalidade_banco` tinyint(1) DEFAULT '1',
  `variacao_carteira` char(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_carteira` tinyint(1) NOT NULL DEFAULT '1',
  `multa_atrazo` decimal(10,2) DEFAULT '0.00',
  `dias_multa` int(11) DEFAULT '1',
  `correcao_dia` decimal(10,3) DEFAULT '0.000',
  `taxa_boleto` decimal(10,2) DEFAULT '0.00',
  `cobrar_juros` tinyint(1) DEFAULT '0',
  `dias_juros` int(11) DEFAULT '1',
  `msg_juros` tinyint(1) NOT NULL DEFAULT '0',
  `conceder_desconto` tinyint(1) DEFAULT '0',
  `data_limite_desconto` tinyint(1) DEFAULT '0',
  `tipo_desconto` enum('P','V') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'P',
  `percentual_desconto` decimal(10,2) DEFAULT '0.00',
  `status_banco` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Inativo',
  `numero_boleto` int(11) DEFAULT '0',
  `com_registro` tinyint(1) DEFAULT '0',
  `dias_protesto` smallint(6) DEFAULT '0',
  `baixa_codigo` tinyint(1) DEFAULT '2',
  `baixa_dias` smallint(6) DEFAULT '0',
  `emissaoCodigo` tinyint(1) DEFAULT '2',
  `distribuicaoCodigo` tinyint(1) DEFAULT '2',
  `sacadorAvalistaNome` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sacadorAvalistaCpfCnpj` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `outra_configuracao` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `outra_configuracao2` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_banco` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_banco` datetime DEFAULT NULL,
  `homologado` tinyint(1) DEFAULT '0',
  `sequencia` int(11) DEFAULT '0',
  `padrao_receita` tinyint(1) DEFAULT '0',
  `padrao_despesa` tinyint(1) DEFAULT '0',
  `boletofacil` tinyint(1) DEFAULT '0',
  `gerencianet` tinyint(1) DEFAULT '0',
  `layout_cobranca_cad` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `protesto_codigo` tinyint(1) DEFAULT '1',
  `juros_codigo` tinyint(1) DEFAULT '1',
  `multa_codigo` tinyint(1) DEFAULT '1',
  `aceite_banco` char(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  `sync_user` int(11) DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  `id_conta_ob` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `consentimento_ob` char(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `hash_ob` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `liquida_taxa` tinyint(1) DEFAULT '1',
  `id_especie_titulo` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id_banco_cad`),
  KEY `ix_nfe_cadastros_bancos_id_empresa_lixeira` (`id_empresa`,`lixeira`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`),
  KEY `ix_nfe_cadastros_bancos_id_empresa_nome_banco_cad` (`id_empresa`,`nome_banco_cad`),
  KEY `ix_nfe_cadastros_bancos_id_empresa_data_cad_banco` (`id_empresa`,`data_cad_banco`),
  KEY `id_banco` (`id_banco`),
  KEY `sync` (`sync`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_bancos_cnab_temp`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_bancos_cnab_temp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_bancos_sync`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_bancos_sync` (
  `id_banco_cad` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  UNIQUE KEY `id_cliente_id_usuario_uniq` (`id_banco_cad`,`id_usuario`),
  KEY `id_cliente_id_usuario` (`id_banco_cad`,`id_usuario`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_categorias`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_categorias` (
  `id_categoria` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `atalho_categoria` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_categoria` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_categoria` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Ativo',
  `data_cad_categoria` datetime DEFAULT NULL,
  `data_mod_categoria` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_categoria`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_categorias_sub`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_categorias_sub` (
  `id_subcategoria` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `id_categoria` bigint(20) NOT NULL DEFAULT '0',
  `atalho_subcategoria` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_subcategoria` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_subcategoria` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Ativo',
  `data_cad_subcategoria` datetime DEFAULT NULL,
  `data_mod_subcategoria` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_subcategoria`),
  KEY `id_categoria` (`id_categoria`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_clientes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_clientes` (
  `id_cliente` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_registro` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `tipo_pessoa` enum('PJ','PF') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PJ',
  `tipo_cadastro` enum('Cliente','Fornecedor','Ambos') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Cliente',
  `cnpj_cliente` char(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rg_cliente` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_emissao_rg_cliente` date DEFAULT NULL,
  `orgao_expedidor_rg_cliente` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `passaporte_cliente` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estrangeiro_cliente` tinyint(1) DEFAULT NULL,
  `razao_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fantasia_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endereco_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_cliente` char(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro_cliente` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complemento_cliente` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep_cliente` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pais_cliente` char(45) COLLATE utf8mb4_unicode_ci DEFAULT 'Brasil',
  `pais_cliente_cod` char(4) COLLATE utf8mb4_unicode_ci DEFAULT '1058',
  `cidade_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_cliente_cod` int(11) DEFAULT NULL,
  `uf_cliente` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contato_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fone_cliente` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fone_contato_cliente` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fone_ramal_cliente` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax_cliente` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `celular_cliente` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_contato_cliente` varchar(400) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `celular_contato_cliente` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado_civil_cliente` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aposentado_cliente` tinyint(1) DEFAULT NULL,
  `empregador_cliente` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profissao_cliente` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `genero_cliente` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `insc_estadual_cliente` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `insc_municipal_cliente` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `insc_produtor_cliente` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `insc_suframa_cliente` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_categoria` int(11) DEFAULT '0',
  `situacao_cliente` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci DEFAULT 'Ativo',
  `vendedor_cliente` char(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendedor_cliente_id` bigint(20) DEFAULT NULL,
  `vendedor2_cliente` char(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendedor2_cliente_id` bigint(20) DEFAULT NULL,
  `modalidade_frete` tinyint(1) DEFAULT '9',
  `id_transportadora` int(11) DEFAULT NULL,
  `desc_transportadora` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes_cliente` longtext COLLATE utf8mb4_unicode_ci,
  `foto_cliente` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `listapreco_cliente` int(11) NOT NULL DEFAULT '0',
  `condicaopag_cliente` int(11) NOT NULL DEFAULT '0',
  `limite_credito` decimal(10,2) DEFAULT '0.00',
  `ultrapassar_limite_credito` tinyint(1) DEFAULT '1',
  `obs_notafiscal_cliente` longtext COLLATE utf8mb4_unicode_ci,
  `consumidor_final` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contribuinte_icms` int(11) NOT NULL DEFAULT '1',
  `regime_tributario` tinyint(1) NOT NULL DEFAULT '0',
  `ramo_atividade` tinyint(1) NOT NULL DEFAULT '0',
  `data_inicio_cliente` date DEFAULT NULL,
  `data_final_cliente` date DEFAULT NULL,
  `data_nasc_cliente` date DEFAULT NULL,
  `data_cad_cliente` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_cliente` datetime DEFAULT NULL,
  `usuario_cad_cliente` bigint(20) DEFAULT '0',
  `usuario_mod_cliente` bigint(20) DEFAULT '0',
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  `sync_user` int(11) DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_cliente`),
  KEY `ix_nfe_cadastros_clientes_id_empresa_tipo_cadastro` (`id_empresa`,`tipo_cadastro`),
  KEY `ix_nfe_cadastros_clientes_id_empresa_razao_cliente` (`id_empresa`,`razao_cliente`),
  KEY `ix_nfe_cadastros_clientes_id_empresa_situacao_cliente` (`id_empresa`,`situacao_cliente`),
  KEY `ix_nfe_cadastros_clientes_id_empresa_fantasia_cliente` (`id_empresa`,`fantasia_cliente`),
  KEY `ix_nfe_cadastros_clientes_id_empresa_id_categoria` (`id_empresa`,`id_categoria`),
  KEY `lixeira` (`lixeira`),
  KEY `ix_nfe_cadastros_clientes_id_empresa_fone_cliente` (`id_empresa`,`fone_cliente`),
  KEY `ix_nfe_cadastros_clientes_id_empresa_vendedor_cliente` (`id_empresa`,`vendedor_cliente`),
  KEY `sync` (`sync`),
  KEY `ix_nfe_cadastros_clientes_id_empresa_cidade_cliente` (`id_empresa`,`cidade_cliente`),
  KEY `ix_nfe_cadastros_clientes_id_empresa_data_cad_cliente` (`id_empresa`,`data_cad_cliente`),
  KEY `ix_nfe_cadastros_clientes_id_empresa_email_cliente` (`id_empresa`,`email_cliente`),
  KEY `ix_nfe_cadastros_clientes_id_empresa_lixeira` (`id_empresa`,`lixeira`),
  KEY `ix_nfe_cadastros_clientes_id_empresa_id_registro` (`id_empresa`,`id_registro`),
  KEY `id_empresa` (`id_empresa`),
  KEY `situacao_cliente` (`situacao_cliente`),
  KEY `ix_nfe_cadastros_clientes_id_empresa_cnpj_cliente` (`id_empresa`,`cnpj_cliente`),
  KEY `data_nasc_cliente` (`data_nasc_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_clientes_campos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_clientes_campos` (
  `id_campo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT NULL,
  `nome_campo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_campo` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tamanho_campo` int(11) DEFAULT '5',
  `obrigatorio` tinyint(1) DEFAULT '0',
  `data_cad_campo` datetime DEFAULT NULL,
  `data_mod_cadastro` datetime DEFAULT NULL,
  `lixeira` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_campo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_clientes_campos_valores`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_clientes_campos_valores` (
  `id_valor` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT NULL,
  `id_cliente` bigint(20) DEFAULT NULL,
  `id_campo` bigint(20) DEFAULT NULL,
  `valor` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_campo` datetime DEFAULT NULL,
  `data_mod_campo` datetime DEFAULT NULL,
  PRIMARY KEY (`id_valor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_clientes_categorias`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_clientes_categorias` (
  `id_categoria` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `nome_categoria` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_categoria` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Ativo',
  `data_cad_categoria` datetime NOT NULL,
  `data_mod_categoria` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_categoria`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_clientes_categorias_config`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_clientes_categorias_config` (
  `id_config` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_cliente` bigint(20) NOT NULL,
  `id_empresa` bigint(20) NOT NULL,
  `id_categoria` bigint(20) NOT NULL,
  `data_cad_campo` datetime NOT NULL,
  PRIMARY KEY (`id_config`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_clientes_contatos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_clientes_contatos` (
  `id_contato` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_cliente` int(11) NOT NULL DEFAULT '0',
  `tipo_contato` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Outros',
  `relacao_contato` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `setor_contato` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_contato` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `genero_contato` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `responsavel_legal_contato` tinyint(1) DEFAULT NULL,
  `cpf_contato` char(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes_contato` text COLLATE utf8mb4_unicode_ci,
  `data_nasc_contato` date DEFAULT NULL,
  `telefone_contato` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ramal_contato` char(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `celular_contato` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fax_contato` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_contato` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `website_contato` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_contato`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_clientes_conversas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_clientes_conversas` (
  `id_conversa` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_cliente` int(11) NOT NULL DEFAULT '0',
  `desc_conversa` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario_conversa` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_conversa` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_conversa`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_cliente` (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_clientes_enderecos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_clientes_enderecos` (
  `id_endereco` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_cliente` int(11) NOT NULL DEFAULT '0',
  `tipo_endereco` char(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_pessoa` enum('PJ','PF') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PJ',
  `razao_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnpj_endereco` char(18) COLLATE utf8mb4_unicode_ci NOT NULL,
  `insc_estadual_cliente` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endereco_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_cliente` int(11) DEFAULT NULL,
  `bairro_cliente` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complemento_cliente` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep_cliente` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_cliente_cod` int(11) DEFAULT NULL,
  `pais_cliente` char(45) COLLATE utf8mb4_unicode_ci DEFAULT 'Brasil',
  `pais_cliente_cod` char(4) COLLATE utf8mb4_unicode_ci DEFAULT '1058',
  `uf_cliente` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fone_cliente` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_endereco` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_endereco`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_clientes_sync`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_clientes_sync` (
  `id_cliente` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  UNIQUE KEY `id_cliente_id_usuario_uniq` (`id_cliente`,`id_usuario`),
  KEY `id_cliente_id_usuario` (`id_cliente`,`id_usuario`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_grades`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_grades` (
  `id_grade` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `desc_grade` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_grade`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_importacao`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_importacao` (
  `id_importacao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `arquivo_importacao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qtde_registros` int(11) DEFAULT '0',
  `json_importacao` text COLLATE utf8mb4_unicode_ci,
  `data_cad_importacao` datetime DEFAULT NULL,
  `data_impor_importacao` datetime DEFAULT NULL,
  `modulo_importacao` enum('Vendedores','Clientes','Transportadoras','Produtos') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_importacao` enum('Aberto','Andamento','Concluido') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Aberto',
  PRIMARY KEY (`id_importacao`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_listapreco`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_listapreco` (
  `id_lista` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `nome_lista` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_lista` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Ativo',
  `tipo` enum('Acrescimo','Desconto','Livre') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Livre',
  `data_cad_lista` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_lista` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_lista`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_listapreco_historico`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_listapreco_historico` (
  `id_historico` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `id_lista` int(11) NOT NULL DEFAULT '0',
  `base_atualizacao` enum('Produto','Lista','') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tipo_atualizacao` enum('Acrescimo','Desconto','') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `valor_atualizacao` decimal(10,2) NOT NULL DEFAULT '0.00',
  `data_cad_historico` datetime NOT NULL,
  PRIMARY KEY (`id_historico`),
  KEY `id_empresa_id_usuario` (`id_empresa`,`id_usuario`),
  KEY `id_lista` (`id_lista`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_listapreco_historico_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_listapreco_historico_produtos` (
  `id_historico` int(11) NOT NULL DEFAULT '0',
  `id_lista` int(11) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `valor_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  KEY `id_produto` (`id_produto`),
  KEY `id_lista` (`id_lista`),
  KEY `id_historico` (`id_historico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_listapreco_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_listapreco_produtos` (
  `id_lista` int(11) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `valor_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `data_mod_lista_produtos` datetime DEFAULT NULL,
  `data_cad_lista_produtos` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `id_lista_id_produto` (`id_lista`,`id_produto`),
  KEY `id_produto` (`id_produto`),
  KEY `id_lista` (`id_lista`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_produtos` (
  `id_produto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_registro` bigint(20) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_categoria` int(11) NOT NULL DEFAULT '0',
  `cod_produto` char(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marca_produto` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desc_produto` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `atalho_produto` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fornecedor_produto` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fornecedor_produto_id` int(11) DEFAULT NULL,
  `produto_variado` tinyint(1) NOT NULL DEFAULT '0',
  `id_produto_parent` int(11) DEFAULT '0',
  `minimo_produto` decimal(15,6) unsigned DEFAULT '0.000000',
  `maximo_produto` decimal(15,6) unsigned DEFAULT '0.000000',
  `estoque_produto` decimal(15,6) DEFAULT '0.000000',
  `unidade_produto` char(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_produto` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `valor_custo_produto` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `peso_produto` decimal(15,6) DEFAULT NULL,
  `peso_liq_produto` decimal(15,6) DEFAULT NULL,
  `icms_produto` decimal(10,2) DEFAULT NULL,
  `ipi_produto` decimal(10,2) DEFAULT NULL,
  `pis_produto` decimal(10,2) DEFAULT NULL,
  `cofins_produto` decimal(10,2) DEFAULT NULL,
  `unidade_tributavel` char(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cest_produto` char(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `beneficio_fiscal` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ncm_produto` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `origem_produto` tinyint(1) NOT NULL DEFAULT '0',
  `ordem_produto` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_barra_produto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `obs_produto` longtext COLLATE utf8mb4_unicode_ci,
  `tipo_classificacao` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tamanho_produto` char(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `localizacao_produto` char(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_produto` enum('Produto','Servico','Ambos') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Produto',
  `kit_produto` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `status_produto` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Ativo',
  `baixar_kit` tinyint(1) NOT NULL DEFAULT '1',
  `desmembrar_kit` tinyint(1) NOT NULL DEFAULT '0',
  `loja_visivel` tinyint(1) NOT NULL DEFAULT '0',
  `loja_altura` tinyint(1) NOT NULL DEFAULT '0',
  `loja_largura` tinyint(1) NOT NULL DEFAULT '0',
  `loja_profundidade` tinyint(1) NOT NULL DEFAULT '0',
  `loja_destaque` tinyint(1) NOT NULL DEFAULT '0',
  `loja_freteGratis` tinyint(1) NOT NULL DEFAULT '0',
  `loja_descricao` mediumtext COLLATE utf8mb4_unicode_ci,
  `loja_valor` decimal(10,2) DEFAULT NULL,
  `data_cad_produto` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_produto` datetime DEFAULT NULL,
  `usuario_cad_produto` bigint(20) DEFAULT '0',
  `usuario_mod_produto` bigint(20) DEFAULT '0',
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  `sync_user` int(11) DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_produto`),
  UNIQUE KEY `id_produto` (`id_produto`),
  KEY `ix_nfe_cadastros_produtos_id_empresa_status_produto` (`id_empresa`,`status_produto`),
  KEY `ix_nfe_cadastros_produtos_id_empresa_tipo_produto` (`id_empresa`,`tipo_produto`),
  KEY `ix_nfe_cadastros_produtos_id_empresa_id_registro` (`id_empresa`,`id_registro`),
  KEY `ix_nfe_cadastros_produtos_id_empresa_data_cad_produto` (`id_empresa`,`data_cad_produto`),
  KEY `ix_nfe_cadastros_produtos_id_empresa_marca_produto` (`id_empresa`,`marca_produto`),
  KEY `ix_nfe_cadastros_produtos_id_empresa_lixeira` (`id_empresa`,`lixeira`),
  KEY `atalho_produto` (`atalho_produto`),
  KEY `ix_nfe_cadastros_produtos_id_empresa_desc_produto` (`id_empresa`,`desc_produto`),
  KEY `id_produto_parent_idx` (`id_produto_parent`),
  KEY `lixeira` (`lixeira`),
  KEY `ix_nfe_cadastros_produtos_id_empresa_cod_produto` (`id_empresa`,`cod_produto`),
  KEY `status_produto` (`status_produto`),
  KEY `ix_nfe_cadastros_produtos_id_empresa_codigo_barra_produto` (`id_empresa`,`codigo_barra_produto`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_categoria` (`id_categoria`),
  KEY `id_produto_parent_lixeira_idx` (`id_produto_parent`,`lixeira`),
  KEY `loja_visivel` (`loja_visivel`),
  KEY `sync` (`sync`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_produtos_estoque`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_produtos_estoque` (
  `id_estoque` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `identificacao` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `tipo_estoque` enum('Saida','Entrada') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Entrada',
  `qtde_estoque` decimal(15,6) DEFAULT '0.000000',
  `valor_estoque` decimal(10,4) DEFAULT '0.0000',
  `obs_estoque` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_usuario_cad_estoque` int(11) NOT NULL DEFAULT '0',
  `data_cad_estoque` date DEFAULT NULL,
  PRIMARY KEY (`id_estoque`),
  KEY `id_empresa` (`id_empresa`),
  KEY `ix_nfe_cadastros_produtos_estoque_id_produto_tipo_estoque` (`id_produto`,`tipo_estoque`),
  KEY `identificacao` (`identificacao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_produtos_estrutura`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_produtos_estrutura` (
  `id_estrutura` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `id_produto_vinculado` bigint(20) NOT NULL DEFAULT '0',
  `nome_produto` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qtde_estrutura` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_estrutura` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_estrutura`),
  KEY `id_produto` (`id_produto`),
  KEY `id_produto_vinculado` (`id_produto_vinculado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_produtos_formador_precos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_produtos_formador_precos` (
  `id_formador_precos` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_produto` bigint(20) DEFAULT NULL,
  `credito_icms` decimal(10,2) DEFAULT NULL,
  `credito_icms_resultado` decimal(10,2) DEFAULT NULL,
  `frete` decimal(10,2) DEFAULT NULL,
  `frete_resultado` decimal(10,2) DEFAULT NULL,
  `ipi` decimal(10,2) DEFAULT NULL,
  `ipi_resultado` decimal(10,2) DEFAULT NULL,
  `icmsst` decimal(10,2) DEFAULT NULL,
  `icmsst_resultado` decimal(10,2) DEFAULT NULL,
  `margem_lucro` decimal(10,2) DEFAULT NULL,
  `margem_lucro_resultado` decimal(10,2) DEFAULT NULL,
  `valor_venda` decimal(10,2) DEFAULT NULL,
  `custo_adicional` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_formador_precos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_produtos_fotos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_produtos_fotos` (
  `id_foto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_produto` bigint(20) DEFAULT '0',
  `foto_grande` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foto_thumb` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `capa_foto` tinyint(1) NOT NULL DEFAULT '0',
  `data_cad_foto` datetime DEFAULT NULL,
  PRIMARY KEY (`id_foto`),
  KEY `id_produto` (`id_produto`),
  KEY `capa_foto` (`capa_foto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_produtos_grade`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_produtos_grade` (
  `id_produto_grade` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_grade` int(11) NOT NULL,
  `id_produto` int(11) NOT NULL,
  PRIMARY KEY (`id_produto_grade`),
  KEY `id_grade` (`id_grade`),
  KEY `id_grade_id_produto` (`id_grade`,`id_produto`),
  KEY `id_produto` (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_produtos_parametros`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_produtos_parametros` (
  `id_parametro` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `cst_icms` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '40',
  `modalidade_icms` tinyint(1) NOT NULL DEFAULT '3',
  `pICMS_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ICMS_automatico` tinyint(1) NOT NULL DEFAULT '0',
  `pRedBC_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `motDesICMS_icms` tinyint(1) NOT NULL DEFAULT '9',
  `pCredSN_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pFCPUFDest_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pDif_icms` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `cst_ipi` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '52',
  `classe_enquadramento` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cEnq_enquadramento` char(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pIPI_ipi` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cst_pis` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '08',
  `pPIS_pis` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cst_cofins` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '08',
  `pCOFINS_cofins` decimal(10,2) NOT NULL DEFAULT '0.00',
  `modalidade_st` tinyint(1) NOT NULL DEFAULT '4',
  `pMVAST_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pRedBCST_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pICMSST_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pPIS_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pCOFINS_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cfop_vendadentro` int(11) DEFAULT NULL,
  `cfop_vendafora` int(11) DEFAULT NULL,
  `cfop_entrada` int(11) DEFAULT NULL,
  `cfop_importacao` int(11) DEFAULT NULL,
  `cfop_exportacao` int(11) DEFAULT NULL,
  `cfop_nfce` int(11) NOT NULL,
  `valor_tributos_produto` decimal(10,2) DEFAULT NULL,
  `valor_tributosEst_produto` decimal(10,2) DEFAULT NULL,
  `info_adicional` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cod_anp_comb` char(9) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cod_codif_comb` char(21) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qTemp_comb` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `descANP_comb` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `UFCons_comb` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qBCProd_comb` decimal(10,4) DEFAULT '0.0000',
  `vAliqProd_comb` decimal(10,4) DEFAULT '0.0000',
  `vCIDE_comb` decimal(10,2) DEFAULT '0.00',
  `pGLP_comb` decimal(10,4) DEFAULT NULL,
  `pGNn_comb` decimal(10,4) DEFAULT NULL,
  `pGNi_comb` decimal(10,4) DEFAULT NULL,
  `vPart_comb` decimal(10,4) DEFAULT NULL,
  PRIMARY KEY (`id_parametro`),
  KEY `id_produto` (`id_produto`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_produtos_parametros_nfce`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_produtos_parametros_nfce` (
  `id_parametro` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `cfop_nfce` int(11) NOT NULL,
  `nfce_cst_icms` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '40',
  `nfce_modalidade_icms` tinyint(1) NOT NULL DEFAULT '3',
  `nfce_pRedBC_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `nfce_motDesICMS_icms` tinyint(1) NOT NULL DEFAULT '9',
  `nfce_cst_pis` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '08',
  `nfce_cst_cofins` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '08',
  `nfce_valor_tributos_produto` decimal(10,2) DEFAULT NULL,
  `nfce_valor_tributosEst_produto` decimal(10,2) DEFAULT NULL,
  `nfce_info_adicional` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nfce_cod_anp_comb` char(9) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nfce_cod_codif_comb` char(21) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nfce_qTemp_comb` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `nfce_descANP_comb` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nfce_UFCons_comb` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nfce_qBCProd_comb` decimal(10,4) DEFAULT '0.0000',
  `nfce_vAliqProd_comb` decimal(10,4) DEFAULT '0.0000',
  `nfce_vCIDE_comb` decimal(10,2) DEFAULT '0.00',
  `nfce_pGLP_comb` decimal(10,4) DEFAULT NULL,
  `nfce_pGNn_comb` decimal(10,4) DEFAULT NULL,
  `nfce_pGNi_comb` decimal(10,4) DEFAULT NULL,
  `nfce_vPart_comb` decimal(10,4) DEFAULT NULL,
  PRIMARY KEY (`id_parametro`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_produto` (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_produtos_subcategoria`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_produtos_subcategoria` (
  `id_vinculo` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `id_subcategoria` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_vinculo`),
  KEY `id_produto` (`id_produto`),
  KEY `id_subcategoria` (`id_subcategoria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_produtos_sync`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_produtos_sync` (
  `id_produto` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  UNIQUE KEY `id_produto_id_usuario_uniq` (`id_produto`,`id_usuario`),
  KEY `id_cliente_id_usuario` (`id_produto`,`id_usuario`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_produtos_variacao`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_produtos_variacao` (
  `id_produto_variacao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_variacao` int(11) NOT NULL,
  `id_produto` int(11) NOT NULL,
  PRIMARY KEY (`id_produto_variacao`),
  KEY `id_produto` (`id_produto`),
  KEY `id_variacao` (`id_variacao`),
  KEY `id_variacao_id_produto` (`id_variacao`,`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_transportadoras`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_transportadoras` (
  `id_transportadora` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_registro` bigint(20) unsigned NOT NULL DEFAULT '0',
  `id_empresa` bigint(20) unsigned NOT NULL DEFAULT '0',
  `tipo_pessoa` enum('PJ','PF') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PJ',
  `desc_transportadora` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fantasia_transportadora` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnpj_transportadora` char(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ie_transportadora` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endereco_transportadora` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_transportadora` char(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep_transportadora` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro_transportadora` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complemento_transportadora` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_transportadora` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_transportadora_cod` int(11) DEFAULT NULL,
  `estado_transportadora` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fone_transportadora` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_transportadora` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes_transportadora` longtext COLLATE utf8mb4_unicode_ci,
  `data_cad_transportadora` datetime DEFAULT NULL,
  `data_mod_transportadora` datetime DEFAULT NULL,
  `usuario_cad_transportadora` bigint(20) DEFAULT '0',
  `usuario_mod_transportadora` bigint(20) DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_transportadora`),
  UNIQUE KEY `id_transportadora` (`id_transportadora`),
  KEY `ix_nfe_cadastros_transportadoras_id_empresa_email_transportadora` (`id_empresa`,`email_transportadora`),
  KEY `ix_nfe_cadastros_transportadoras_id_empresa_data_cad` (`id_empresa`,`data_cad_transportadora`),
  KEY `id_empresa` (`id_empresa`),
  KEY `ix_nfe_cadastros_transportadoras_id_empresa_lixeira` (`id_empresa`,`lixeira`),
  KEY `ix_nfe_cadastros_transportadoras_id_empresa_id_registro` (`id_empresa`,`id_registro`),
  KEY `ix_nfe_cadastros_transportadoras_id_empresa_desc_transportadorao` (`id_empresa`,`desc_transportadora`),
  KEY `ix_nfe_cadastros_transportadoras_id_empresa_cnpj_transportadora` (`id_empresa`,`cnpj_transportadora`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_transportadoras_conversas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_transportadoras_conversas` (
  `id_conversa` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_transportadora` int(11) NOT NULL DEFAULT '0',
  `desc_conversa` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario_conversa` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_conversa` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_conversa`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_cliente` (`id_transportadora`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_variacoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_variacoes` (
  `id_variacao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_grade` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `desc_variacao` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_variacao`),
  KEY `id_grade` (`id_grade`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cadastros_vendedores`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cadastros_vendedores` (
  `id_vendedor` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_registro` int(11) NOT NULL DEFAULT '0',
  `tipo_pessoa` enum('PJ','PF') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PJ',
  `cnpj_vendedor` char(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `razao_vendedor` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fantasia_vendedor` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endereco_vendedor` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_vendedor` char(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro_vendedor` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complemento_vendedor` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep_vendedor` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_vendedor` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_vendedor_cod` int(11) DEFAULT NULL,
  `uf_vendedor` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contato_vendedor` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fone_vendedor` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fone_ramal_vendedor` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax_vendedor` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `celular_vendedor` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_vendedor` char(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website_vendedor` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `listapreco_vendedor` int(11) DEFAULT NULL,
  `banco_vendedor` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banco_agencia` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banco_conta` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banco_salario` decimal(10,2) DEFAULT NULL,
  `situacao_vendedor` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci DEFAULT 'Ativo',
  `comissao_usuario` decimal(10,2) NOT NULL DEFAULT '0.00',
  `comissao_regra` tinyint(1) NOT NULL DEFAULT '1',
  `usuario_vendedor` bigint(20) DEFAULT NULL,
  `observacoes_vendedor` longtext COLLATE utf8mb4_unicode_ci,
  `data_cad_vendedor` datetime DEFAULT NULL,
  `data_mod_vendedor` datetime DEFAULT NULL,
  `usuario_cad_vendedor` bigint(20) DEFAULT '0',
  `usuario_mod_vendedor` bigint(20) DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_vendedor`),
  KEY `ix_nfe_cadastros_vendedores_id_empresa_cnpj_vendedor` (`id_empresa`,`cnpj_vendedor`),
  KEY `ix_nfe_cadastros_vendedores_id_empresa_data_cad_vendedor` (`id_empresa`,`data_cad_vendedor`),
  KEY `usuario_vendedor` (`usuario_vendedor`),
  KEY `ix_nfe_cadastros_vendedores_id_empresa_lixeira` (`id_empresa`,`lixeira`),
  KEY `lixeira` (`lixeira`),
  KEY `ix_nfe_cadastros_vendedores_id_empresa_razao_vendedor` (`id_empresa`,`razao_vendedor`),
  KEY `ix_nfe_cadastros_vendedores_id_empresa_fantasia_vendedor` (`id_empresa`,`fantasia_vendedor`),
  KEY `id_empresa` (`id_empresa`),
  KEY `situacao_vendedor` (`situacao_vendedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_carta_correcao`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_carta_correcao` (
  `id_cce` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `nome_usuario` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chave_nfe` char(44) COLLATE utf8mb4_unicode_ci NOT NULL,
  `correcao_cce` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chave_cce` char(54) COLLATE utf8mb4_unicode_ci NOT NULL,
  `protocolo_cce` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sequencia_cce` tinyint(1) NOT NULL DEFAULT '1',
  `ambiente` tinyint(1) NOT NULL DEFAULT '2',
  `data_cad_cce` datetime NOT NULL,
  PRIMARY KEY (`id_cce`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cfop`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cfop` (
  `operacao` varchar(9) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc_cfop` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descricao` varchar(1100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tp_nfe` tinyint(1) DEFAULT '0',
  `finalidade_nfe` tinyint(1) DEFAULT '1',
  `tributa_st` tinyint(1) DEFAULT '0',
  `nfce` tinyint(1) DEFAULT '0',
  `classificacao` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  KEY `operacao` (`operacao`),
  KEY `desc_cfop` (`desc_cfop`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cidades`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cidades` (
  `id_cidade` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uf_cidade` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_cidade` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_ibge` int(11) NOT NULL,
  `codigo_siafi` char(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_setec` char(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nfs_e` tinyint(1) NOT NULL DEFAULT '0',
  `nfs_e_padrao` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_ultima_homologacao` date DEFAULT NULL,
  `nfs_e_homologacao` tinyint(1) NOT NULL DEFAULT '0',
  `cpom_cidade` tinyint(1) NOT NULL DEFAULT '0',
  `versao_api` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1.00',
  `data_cad_cidade` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_cidade` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cidade`),
  KEY `codigo_ibge` (`codigo_ibge`),
  KEY `codigo_setec` (`codigo_setec`),
  KEY `idx_uf` (`uf_cidade`),
  KEY `codigo_siafi` (`codigo_siafi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cidades_sistemas_observacoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cidades_sistemas_observacoes` (
  `id_observacoes` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_nfs_sistema` char(20) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `observacao` longtext COLLATE utf8mb4_unicode_ci,
  `cidade` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_cadastro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_cadastro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `usuario_cad_observacao` char(20) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `usuario_mod_observacao` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_observacoes`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_comissoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_comissoes` (
  `id_comissao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_vendedor` bigint(20) NOT NULL DEFAULT '0',
  `id_conta_rec` bigint(20) NOT NULL DEFAULT '0',
  `id_parcela` int(11) DEFAULT NULL,
  `data_lancamento` date NOT NULL,
  `desc_lancamento` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_lancamento` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_lancamento` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tipo_lancamento` tinyint(1) NOT NULL DEFAULT '1',
  `data_cad_comissao` datetime NOT NULL,
  `identificacao` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_comissao`),
  KEY `id_empresa` (`id_empresa`),
  KEY `identificacao` (`identificacao`),
  KEY `id_parcela` (`id_parcela`),
  KEY `id_vendedor` (`id_vendedor`),
  KEY `id_conta_rec` (`id_conta_rec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas` (
  `id_empresa` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_parceiro` smallint(6) NOT NULL DEFAULT '0',
  `id_contabilidade` smallint(6) NOT NULL DEFAULT '0',
  `id_academico` smallint(6) NOT NULL DEFAULT '0',
  `tipo_pessoa` enum('PJ','PF') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PJ',
  `certificado_tipo` enum('A1','A3') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'A1',
  `tipo_faturamento` enum('Boleto','Cartao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Boleto',
  `cnpj_empresa` char(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `razao_empresa` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fantasia_empresa` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endereco_empresa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_empresa` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro_empresa` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complemento_empresa` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep_empresa` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_empresa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_empresa_cod` int(11) DEFAULT NULL,
  `uf_empresa` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fone_empresa` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `celular_empresa` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_empresa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_empresa_nota` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_empresa_cte` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website_empresa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `insc_estadual_empresa` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `insc_municipal_empresa` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnae_empresa` char(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes_empresa` longtext COLLATE utf8mb4_unicode_ci,
  `regime_empresa` tinyint(1) NOT NULL DEFAULT '1',
  `contabilidade_cnpj` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contabilidade_cpf` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contabilidade_crc` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contabilidade_cep` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contabilidade_endereco` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contabilidade_endereco_numero` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contabilidade_bairro` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contabilidade_complemento` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contabilidade_cidade` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contabilidade_cidade_cod` int(11) DEFAULT NULL,
  `contabilidade_uf` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contabilidade_responsavel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contabilidade_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contabilidade_telefone` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contabilidade_sefaz` tinyint(1) NOT NULL DEFAULT '0',
  `responsavel_empresa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `responsavel_celular` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo_empresa` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `certificado_empresa` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `certificado_senha_empresa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `certificado_expiracao` date DEFAULT NULL,
  `certificado_instalado` tinyint(1) NOT NULL DEFAULT '0',
  `serie_nota` int(11) NOT NULL DEFAULT '1',
  `serie_nfse` char(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `serie_nfce` int(11) NOT NULL DEFAULT '1',
  `serie_cte` int(11) NOT NULL DEFAULT '0',
  `serie_mdfe` int(11) NOT NULL DEFAULT '0',
  `bloqueado` tinyint(1) NOT NULL DEFAULT '0',
  `bloqueado_desc` longtext COLLATE utf8mb4_unicode_ci,
  `bloqueado_data` datetime DEFAULT NULL,
  `bloqueado_fatura` bigint(20) DEFAULT NULL,
  `gerar_faturas` tinyint(1) NOT NULL DEFAULT '1',
  `gerar_nfs` tinyint(1) NOT NULL DEFAULT '0',
  `faturas_todos` tinyint(1) NOT NULL DEFAULT '1',
  `dia_vencimento` tinyint(1) NOT NULL DEFAULT '5',
  `nota_webservice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `nota_limite` int(11) NOT NULL DEFAULT '0',
  `nota_ambiente` tinyint(1) NOT NULL DEFAULT '1',
  `cte_ambiente` tinyint(1) NOT NULL DEFAULT '1',
  `usuarios_limite` int(11) NOT NULL,
  `alterar_cnpj` tinyint(1) NOT NULL DEFAULT '0',
  `modulo_nfe` tinyint(1) NOT NULL DEFAULT '1',
  `modulo_nfse` tinyint(1) NOT NULL DEFAULT '0',
  `modulo_nfse_exportar` tinyint(1) NOT NULL DEFAULT '0',
  `modulo_pdv` tinyint(1) NOT NULL DEFAULT '0',
  `modulo_cte` tinyint(1) NOT NULL DEFAULT '0',
  `modulo_loja` tinyint(1) NOT NULL DEFAULT '0',
  `modulo_boleto` tinyint(1) NOT NULL DEFAULT '0',
  `boleto_usuario` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `boleto_senha` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `boleto_padrao` tinyint(1) DEFAULT '1',
  `creditos_empresa` decimal(10,2) NOT NULL DEFAULT '0.00',
  `espaco_empresa` bigint(20) unsigned NOT NULL DEFAULT '104857600',
  `espaco_consumido` bigint(20) unsigned NOT NULL DEFAULT '0',
  `termos_uso` tinyint(1) NOT NULL DEFAULT '0',
  `termos_data` datetime DEFAULT NULL,
  `termos_usuario` char(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Assinar',
  `white_label` tinyint(1) NOT NULL DEFAULT '0',
  `cliente_stone` tinyint(1) DEFAULT '0',
  `prospecto` tinyint(1) NOT NULL DEFAULT '0',
  `freemium` tinyint(1) DEFAULT '0',
  `prospecto_expiracao` date NOT NULL,
  `prospecto_degustacao` date NOT NULL,
  `prospecto_ativado` datetime DEFAULT NULL,
  `prospecto_cupom` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prospecto_origem` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prospecto_situacao` char(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Novo',
  `prospecto_prioridade` tinyint(1) NOT NULL DEFAULT '0',
  `prospecto_repasse` tinyint(1) NOT NULL DEFAULT '0',
  `boasvindas` tinyint(1) NOT NULL DEFAULT '0',
  `intro_boasvindas` tinyint(1) NOT NULL DEFAULT '0',
  `intro_lojaapps` tinyint(1) NOT NULL DEFAULT '0',
  `intro_meusapps` tinyint(1) NOT NULL DEFAULT '0',
  `intro_pagante` tinyint(1) NOT NULL DEFAULT '0',
  `intro_primeiroAcesso` tinyint(1) NOT NULL DEFAULT '1',
  `dre_configurado` tinyint(1) NOT NULL DEFAULT '0',
  `suporte_plus` tinyint(1) NOT NULL DEFAULT '0',
  `publicidade` tinyint(1) NOT NULL DEFAULT '1',
  `visivel_marketplace` tinyint(1) NOT NULL DEFAULT '0',
  `receber_spam` tinyint(1) NOT NULL DEFAULT '1',
  `limite_email_marketing` int(11) NOT NULL DEFAULT '1000',
  `limite_sms` int(11) NOT NULL DEFAULT '1000',
  `limite_consulta_serasa` int(11) NOT NULL DEFAULT '10',
  `data_cad_empresa` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_empresa` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `rntrc_empresa` varchar(14) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ocultar_sped_fiscal` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id_empresa`),
  KEY `prospecto_prospecto_expiracao` (`prospecto`,`prospecto_expiracao`),
  KEY `id_academico` (`id_academico`),
  KEY `id_parceiro` (`id_parceiro`),
  KEY `lixeira` (`lixeira`),
  KEY `creditos_empresa` (`creditos_empresa`),
  KEY `data_cad_empresa` (`data_cad_empresa`),
  KEY `id_contabilidade` (`id_contabilidade`),
  KEY `bloqueado` (`bloqueado`),
  KEY `espaco_empresa` (`espaco_empresa`),
  KEY `prospecto_situacao` (`prospecto_situacao`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_cadastros`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_cadastros` (
  `id_contratacao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `endereco_cadastro` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_cadastro` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hostname_cadastro` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_cadastro` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_cadastro` datetime NOT NULL,
  PRIMARY KEY (`id_contratacao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_cadastros_interno`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_cadastros_interno` (
  `id_cad_interno` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) DEFAULT NULL,
  `id_empresa` int(11) DEFAULT NULL,
  `data_cad_cadastro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cad_interno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_cancelamentos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_cancelamentos` (
  `id_cancelamento` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `tipo_cancelamento` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_cancelamento_2` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `motivo_cancelamento` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `numero_chamado` int(11) NOT NULL,
  `valor_devolucao` decimal(10,2) NOT NULL,
  `usuario_cancelamento` char(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cancelamento` datetime NOT NULL,
  PRIMARY KEY (`id_cancelamento`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_cartoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_cartoes` (
  `id_cartao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `token_cielo` char(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_cielo` tinyint(1) DEFAULT '0',
  `num_cartao` char(50) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `ano_cartao` char(4) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `mes_cartao` char(2) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `bandeira_cartao` enum('visa','mastercard','diners','discover','elo','amex','jcb','aura','master','hipercard','hiper') COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_pagamento` tinyint(1) NOT NULL DEFAULT '0',
  `origem` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Externa',
  `data_cad_cartao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `numero_Identificador` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1427bdb8d29e88405a3a489348d0f2e70956d9be3b01890b2916bc4e11392f8d',
  PRIMARY KEY (`id_cartao`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_chat`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_chat` (
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `chat` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ZOPIM'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_contatos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_contatos` (
  `id_contato` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `motivo_atualizacao` tinyint(1) NOT NULL DEFAULT '0',
  `nome` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `celular` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `expira_em` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_cad_contato` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_contato`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_contratacoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_contratacoes` (
  `id_contratacao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_fatura` int(11) NOT NULL DEFAULT '0',
  `tipo_pagamento` enum('Boleto','Cartao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Boleto',
  `id_cartao` int(11) NOT NULL DEFAULT '0',
  `obs_pagamento` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_pagamento` tinyint(1) DEFAULT NULL,
  `cod_pagamento` char(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_contratacao` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ip_contratacao` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_contratacao` datetime NOT NULL,
  PRIMARY KEY (`id_contratacao`),
  KEY `id_fatura` (`id_fatura`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_conversas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_conversas` (
  `id_conversa` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `usuario_conversa` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `situacao_conversa` char(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc_conversa` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_situacao_conversa` char(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_prox_conversa` date DEFAULT NULL,
  `hora_prox_conversa` time DEFAULT NULL,
  `unique_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `url_discagem` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `tipo_conversa` enum('Suporte','Comercial','CRM','Usuario','Financeiro') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CRM',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `data_conversa` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_conversa`),
  KEY `lixeira` (`lixeira`),
  KEY `situacao_conversa` (`situacao_conversa`),
  KEY `hora_prox_conversa` (`hora_prox_conversa`),
  KEY `usuario_conversa` (`usuario_conversa`),
  KEY `id_empresa` (`id_empresa`),
  KEY `tipo_conversa` (`tipo_conversa`),
  KEY `data_prox_conversa` (`data_prox_conversa`),
  KEY `data_conversa` (`data_conversa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_conversas_adicionais`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_conversas_adicionais` (
  `id_conversa_adicional` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_conversa` int(11) DEFAULT NULL,
  `chamado_numero` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `possui_chamado` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `tratativa` enum('Bug','Simples','Complexa','Historico','Apoio') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_conversa_adicional`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_conversas_modulos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_conversas_modulos` (
  `id_conversa_modulo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_conversa` int(11) NOT NULL,
  `id_modulo` int(11) NOT NULL,
  PRIMARY KEY (`id_conversa_modulo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_excluidas_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_excluidas_log` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) DEFAULT NULL,
  `login_usuario` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_empresas` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_log` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_historico`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_historico` (
  `dia_historico` date NOT NULL,
  `cadastros` smallint(6) NOT NULL,
  `contratacoes` smallint(6) NOT NULL,
  `cancelamentos` smallint(6) NOT NULL,
  `logins` int(11) NOT NULL,
  `clientes_ativos` int(11) NOT NULL,
  `clientes_bloqueados` int(11) NOT NULL,
  `clientes_total` int(11) NOT NULL,
  `total_usuarios_ativos` int(11) NOT NULL,
  `total_clientes_login` int(11) NOT NULL,
  `total_hard_users` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_iap`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_iap` (
  `id_iap` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `tipo` enum('Apple','Android') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Apple',
  `transactionId` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_transaction` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_iap`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_iap_log_webhook`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_iap_log_webhook` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `json` longtext COLLATE utf8mb4_unicode_ci,
  `data_cad_log` datetime DEFAULT NULL,
  PRIMARY KEY (`id_log`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_intro`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_intro` (
  `id_intro` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `qtd_notas` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qtd_funcionarios` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_empresa` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ramo_atividade` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `funcionalidades` text COLLATE utf8mb4_unicode_ci,
  `planoAtual` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cargo` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `persona` enum('Marilia','Caio','Marta','ND') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ND',
  `formalizada` enum('Sim','Nao','Abrindo','Contador') COLLATE utf8mb4_unicode_ci NOT NULL,
  `cidade` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_cod` int(11) DEFAULT NULL,
  `possui_certificado` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `setor` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_intro`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_logins`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_logins` (
  `id_login` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `id_usuario_parceiro` smallint(6) NOT NULL DEFAULT '0',
  `id_usuario_adm` smallint(6) NOT NULL DEFAULT '0',
  `data_criado` datetime NOT NULL,
  `data_login` datetime NOT NULL,
  `ip_login` char(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_criado` char(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logado` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_login`),
  KEY `id_usuario_adm` (`id_usuario_adm`),
  KEY `id_usuario_parceiro` (`id_usuario_parceiro`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_logs`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_logs` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `id_registro` int(11) NOT NULL DEFAULT '0',
  `tabela` char(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `acao` enum('cadastrou','alterou','excluiu') COLLATE utf8mb4_unicode_ci NOT NULL,
  `restaurado` tinyint(1) NOT NULL DEFAULT '0',
  `restaurado_por` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `restaurado_data` datetime DEFAULT NULL,
  `data_log` datetime NOT NULL,
  PRIMARY KEY (`id_log`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=171 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_numeracao`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_numeracao` (
  `id_empresa` bigint(20) unsigned NOT NULL DEFAULT '0',
  `numeracao_cliente` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_produto` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_transportadora` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_vendedor` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_contas_pag` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_contas_rec` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_boleto` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_nota` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_notah` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_scan` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_nfs` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_nfc` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_nfch` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_orcamento` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_pedido` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_frente` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_entrada` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_ordemservico` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_ordemcompra` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_cte` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_cteh` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_mdfe` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_mdfeh` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_servico_rec` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_cotacao` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_app_bens` int(10) unsigned NOT NULL DEFAULT '0',
  `numeracao_app_funcionarios` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `id_empresa` (`id_empresa`),
  KEY `id_empresai` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_oportunidade_historico`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_oportunidade_historico` (
  `id_oportunidade_historico` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `oportunidade_de` int(11) DEFAULT NULL,
  `oportunidade_de_desc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oportunidade_para` int(11) DEFAULT NULL,
  `oportunidade_para_desc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_trial` decimal(10,2) DEFAULT NULL,
  `exibir_relatorio` tinyint(1) DEFAULT NULL,
  `data_cad_historico` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_oportunidade_historico`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_origens`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_origens` (
  `id_origem` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `url_acessada` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trial_referrer` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_referencia` datetime NOT NULL,
  PRIMARY KEY (`id_origem`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_parametros`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_parametros` (
  `id_parametro` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `cst_icms` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '40',
  `modalidade_icms` tinyint(1) NOT NULL DEFAULT '3',
  `pICMS_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ICMS_automatico` tinyint(1) NOT NULL DEFAULT '0',
  `pRedBC_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `motDesICMS_icms` tinyint(1) NOT NULL DEFAULT '9',
  `pCredSN_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pFCP_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pFCPST_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pFCPSTRet_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pDif_icms` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `cst_ipi` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '53',
  `classe_enquadramento` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cEnq_enquadramento` char(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pIPI_ipi` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cst_pis` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '08',
  `pPIS_pis` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cst_cofins` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '08',
  `pCOFINS_cofins` decimal(10,2) NOT NULL DEFAULT '0.00',
  `modalidade_st` tinyint(1) NOT NULL DEFAULT '4',
  `pMVAST_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pRedBCST_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pICMSST_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pPIS_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pCOFINS_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cfop_vendadentro` int(11) NOT NULL,
  `cfop_vendafora` int(11) NOT NULL,
  `cfop_entrada` int(11) NOT NULL,
  `cfop_importacao` int(11) NOT NULL,
  `cfop_exportacao` int(11) NOT NULL,
  `cfop_venda_st_dentro` int(11) NOT NULL,
  `cfop_venda_st_fora` int(11) NOT NULL,
  `cfop_nfce` int(11) NOT NULL,
  `cfop_nfce_st` int(11) NOT NULL,
  `grupo_nf_medicamento` tinyint(1) NOT NULL DEFAULT '0',
  `grupo_nf_arma` tinyint(1) NOT NULL DEFAULT '0',
  `grupo_nf_combustivel` tinyint(1) NOT NULL DEFAULT '0',
  `desconto_condicionado` tinyint(1) NOT NULL DEFAULT '0',
  `indPres_nf` tinyint(1) NOT NULL DEFAULT '9',
  `nota_conjugada` tinyint(1) NOT NULL DEFAULT '0',
  `nota_xml_email` tinyint(1) NOT NULL DEFAULT '0',
  `cte_xml_email` tinyint(1) NOT NULL DEFAULT '0',
  `mdfe_xml_email` tinyint(1) NOT NULL DEFAULT '0',
  `nota_ultimo_nsu` int(11) NOT NULL DEFAULT '0',
  `nota_cad_fornecedores` tinyint(1) NOT NULL DEFAULT '0',
  `nota_cad_produtos` tinyint(1) NOT NULL DEFAULT '0',
  `nota_cad_transportadoras` tinyint(1) NOT NULL DEFAULT '0',
  `bc_icms_ipi` tinyint(1) NOT NULL DEFAULT '0',
  `bc_icms_frete` tinyint(1) NOT NULL DEFAULT '0',
  `bc_icms_seguro` tinyint(1) DEFAULT '0',
  `bc_icms_outros` tinyint(1) NOT NULL DEFAULT '0',
  `bc_icms_desconto` tinyint(1) NOT NULL DEFAULT '0',
  `bc_ipi_frete` tinyint(1) NOT NULL DEFAULT '0',
  `bc_ipi_seguro` tinyint(1) DEFAULT '0',
  `bc_pis_frete` tinyint(1) NOT NULL DEFAULT '0',
  `bc_pis_outros` tinyint(1) NOT NULL DEFAULT '0',
  `bc_pis_desconto` tinyint(1) NOT NULL DEFAULT '0',
  `bc_cofins_frete` tinyint(1) NOT NULL DEFAULT '0',
  `bc_cofins_outros` tinyint(1) NOT NULL DEFAULT '0',
  `bc_cofins_desconto` tinyint(1) NOT NULL DEFAULT '0',
  `nfce_cst_icms` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '40',
  `nfce_modalidade_icms` tinyint(1) NOT NULL DEFAULT '3',
  `nfce_pRedBC_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `nfce_motDesICMS_icms` tinyint(1) NOT NULL DEFAULT '9',
  `nfce_cst_pis` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '08',
  `nfce_pPIS_pis` decimal(10,2) NOT NULL DEFAULT '0.00',
  `nfce_cst_cofins` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '08',
  `nfce_pCOFINS_cofins` decimal(10,2) NOT NULL DEFAULT '0.00',
  `nfce_indPres_nf` tinyint(1) NOT NULL DEFAULT '1',
  `nfce_bc_icms_frete` tinyint(1) NOT NULL DEFAULT '0',
  `nfce_bc_icms_outros` tinyint(1) NOT NULL DEFAULT '0',
  `nfce_bc_icms_desconto` tinyint(1) NOT NULL DEFAULT '0',
  `nfce_bc_pis_frete` tinyint(1) NOT NULL DEFAULT '0',
  `nfce_bc_pis_outros` tinyint(1) NOT NULL DEFAULT '0',
  `nfce_bc_pis_desconto` tinyint(1) NOT NULL DEFAULT '0',
  `nfce_bc_cofins_frete` tinyint(1) NOT NULL DEFAULT '0',
  `nfce_bc_cofins_outros` tinyint(1) NOT NULL DEFAULT '0',
  `nfce_bc_cofins_desconto` tinyint(1) NOT NULL DEFAULT '0',
  `nfce_token` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nfce_token_id` int(11) NOT NULL DEFAULT '1',
  `nfce_layout` char(6) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal',
  `nfce_observacoes` tinyint(1) NOT NULL DEFAULT '0',
  `nfce_grupo_combustivel` tinyint(1) NOT NULL DEFAULT '0',
  `nfse_natureza_pedido` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `nfse_regime_pedido` tinyint(1) NOT NULL DEFAULT '1',
  `nfse_regime_especial` tinyint(1) NOT NULL DEFAULT '1',
  `nfse_valor_aliquota` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `nfse_valor_aliquota_iss_sn_ip` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `nfse_itemLista_servico` smallint(6) NOT NULL DEFAULT '0',
  `nfse_aliq_cofins` decimal(10,2) NOT NULL DEFAULT '0.00',
  `nfse_aliq_pis` decimal(10,2) NOT NULL DEFAULT '0.00',
  `nfse_aliq_contribuicao` decimal(10,2) NOT NULL DEFAULT '0.00',
  `nfse_aliq_ir` decimal(10,2) NOT NULL DEFAULT '0.00',
  `nfse_aliq_iss` decimal(10,2) NOT NULL DEFAULT '0.00',
  `nfse_reter_cofins` tinyint(1) NOT NULL DEFAULT '0',
  `nfse_reter_pis` tinyint(1) NOT NULL DEFAULT '0',
  `nfse_reter_csll` tinyint(1) NOT NULL DEFAULT '0',
  `nfse_reter_ir` tinyint(1) NOT NULL DEFAULT '0',
  `nfse_reter_inss` tinyint(1) NOT NULL DEFAULT '0',
  `nfse_autenticacao_login` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nfse_autenticacao_senha` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pdv_estoque` tinyint(1) NOT NULL DEFAULT '1',
  `pdv_contas` tinyint(1) NOT NULL DEFAULT '1',
  `pdv_contas_dias` tinyint(1) NOT NULL DEFAULT '0',
  `pdv_contas_dias_debito` tinyint(1) NOT NULL DEFAULT '1',
  `pdv_comissao` tinyint(1) NOT NULL DEFAULT '0',
  `pdv_desconto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pdv_acrescimo` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pdv_valebrinde` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pdv_alterarpreco` tinyint(1) NOT NULL DEFAULT '1',
  `pdv_emitirnfc` tinyint(1) NOT NULL DEFAULT '0',
  `pdv_alteraroperador` tinyint(1) NOT NULL DEFAULT '0',
  `pdv_listapreco` int(11) NOT NULL DEFAULT '0',
  `pdv_cupom_topo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pdv_cupom_rodape` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pdv_cupom_layout` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '50_Colunas',
  `pdv_evo_default_terminal` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pdv_evoluservices` int(11) NOT NULL DEFAULT '0',
  `bal_digitos_iniciais` int(11) NOT NULL DEFAULT '2',
  `bal_tamanho_codigo` int(11) DEFAULT '13',
  `bal_id_cod_prod_inicio` int(11) DEFAULT '2',
  `bal_id_cod_prod_fim` int(11) DEFAULT '7',
  `bal_id_valor_inicio` int(11) DEFAULT '8',
  `bal_id_valor_fim` int(11) DEFAULT '12',
  `bal_casas_decimais` int(11) DEFAULT '2',
  `msg_orcamento` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pdf_orcamento` tinyint(1) NOT NULL DEFAULT '0',
  `msg_pedido` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pdf_pedido` tinyint(1) NOT NULL DEFAULT '0',
  `msg_notafiscal` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `msg_ordemservico` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pdf_ordemservico` tinyint(1) NOT NULL DEFAULT '0',
  `msg_ordemservico_termos` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `msg_notaservico` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `msg_ordemcompra` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pdf_ordemcompra` tinyint(1) NOT NULL DEFAULT '0',
  `msg_boleto` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `msg_envio_conta_bancaria` text COLLATE utf8mb4_unicode_ci,
  `geral_estoque` tinyint(1) NOT NULL DEFAULT '0',
  `geral_estoqueminimo` tinyint(1) NOT NULL DEFAULT '0',
  `geral_bloquearestoque` tinyint(1) NOT NULL DEFAULT '0',
  `geral_bloquearagrupamento` tinyint(1) NOT NULL DEFAULT '1',
  `geral_casas` tinyint(1) NOT NULL DEFAULT '2',
  `geral_ocultarmenu` tinyint(1) NOT NULL DEFAULT '0',
  `geral_vendedores` tinyint(1) NOT NULL DEFAULT '1',
  `geral_comissionamento` tinyint(1) NOT NULL DEFAULT '1',
  `geral_limitepag` tinyint(1) NOT NULL DEFAULT '20',
  `geral_limiteautocomplete` tinyint(1) NOT NULL DEFAULT '10',
  `geral_tipo_busca_autocomplete` tinyint(1) NOT NULL DEFAULT '1',
  `geral_exibir_unidade_autocomplete` tinyint(1) NOT NULL DEFAULT '1',
  `geral_exibir_estoque_autocomplete` tinyint(1) NOT NULL DEFAULT '0',
  `geral_listapreco` tinyint(1) NOT NULL DEFAULT '0',
  `geral_dia_util` tinyint(1) NOT NULL DEFAULT '0',
  `geral_desconsidera` tinyint(1) NOT NULL DEFAULT '0',
  `geral_dados_pedido` tinyint(1) NOT NULL DEFAULT '1',
  `geral_dados_pedido_nf` tinyint(1) NOT NULL DEFAULT '0',
  `geral_dados_gtin_nf` tinyint(1) NOT NULL DEFAULT '1',
  `geral_dados_os` tinyint(1) DEFAULT '1',
  `geral_data_lancarestoque` tinyint(1) DEFAULT '0',
  `geral_impressao_capa_produto` tinyint(1) DEFAULT '0',
  `geral_impressao_capa_produto_tamanho` int(11) DEFAULT '50',
  `geral_impressao_capa_orcamento` tinyint(1) DEFAULT '0',
  `geral_categoria_receita_id` int(11) DEFAULT '58',
  `geral_categoria_receita` char(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Outras Receitas',
  `geral_categoria_despesa_id` int(11) DEFAULT '57',
  `geral_categoria_despesa` char(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Outras Despesas',
  `geral_categoria_vendas_id` int(11) DEFAULT '4',
  `geral_categoria_vendas` char(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Vendas',
  `geral_categoria_servicos_id` int(11) DEFAULT '724',
  `geral_categoria_servicos` char(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Serviços',
  `geral_categoria_compras_id` int(11) DEFAULT '43',
  `geral_categoria_compras` char(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Fornecedor',
  `geral_categoria_padrao_dre` tinyint(1) DEFAULT '1',
  `geral_centro_receitas` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `geral_centro_receitas_id` int(11) DEFAULT NULL,
  `geral_centro_despesas` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `geral_centro_despesas_id` int(11) DEFAULT NULL,
  `geral_centro_vendas` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `geral_centro_vendas_id` int(11) DEFAULT NULL,
  `geral_centro_servicos` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `geral_centro_servicos_id` int(11) DEFAULT NULL,
  `geral_centro_compras` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `geral_centro_compras_id` int(11) DEFAULT NULL,
  `geral_smtp_host` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `geral_smtp_email` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `geral_smtp_senha` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `geral_smtp_porta` char(50) COLLATE utf8mb4_unicode_ci DEFAULT '587',
  `geral_smtp_cript` char(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `geral_cnpj_duplicado` tinyint(1) DEFAULT '0',
  `geral_atualizar_custo` tinyint(1) DEFAULT '0',
  `dashboard_faturamento_tipo` tinyint(1) DEFAULT '1',
  `dashboard_faturamento_cfop` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dashboard_faturamento_status` char(15) COLLATE utf8mb4_unicode_ci DEFAULT 'Atendido',
  `dashboard_faturamento_regra` tinyint(1) DEFAULT '0',
  `dashboard_contaspag_status` char(15) COLLATE utf8mb4_unicode_ci DEFAULT 'Aberto',
  `dashboard_contaspag_periodo` char(7) COLLATE utf8mb4_unicode_ci DEFAULT '3',
  `dashboard_contasrec_status` char(15) COLLATE utf8mb4_unicode_ci DEFAULT 'Aberto',
  `dashboard_contasrec_periodo` char(7) COLLATE utf8mb4_unicode_ci DEFAULT '3',
  `ord_contaspag` char(1) COLLATE utf8mb4_unicode_ci DEFAULT 'D',
  `ord_contasrec` char(1) COLLATE utf8mb4_unicode_ci DEFAULT 'D',
  `foto_lista_produto` tinyint(1) DEFAULT '0',
  `replica_valores` tinyint(1) DEFAULT '0',
  `data_mod_parametros` datetime DEFAULT NULL,
  `usuario_mod_parametros` int(11) DEFAULT NULL,
  `nfce_integracao_pagamento` smallint(5) unsigned NOT NULL DEFAULT '2',
  `nfce_token_homolog` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nfce_token_homolog_id` int(11) NOT NULL DEFAULT '1',
  `pdv_categoria_receita` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Ajuste Caixa',
  `pdv_categoria_receita_id` int(11) NOT NULL DEFAULT '2',
  `pdv_categoria_despesa` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Ajuste Caixa',
  `pdv_categoria_despesa_id` int(11) NOT NULL DEFAULT '53',
  `gerar_boleto` smallint(6) DEFAULT '1',
  `pdv_parametrizar_boleto` tinyint(1) NOT NULL DEFAULT '0',
  `xml_entradas_receita_aguardando` longtext COLLATE utf8mb4_unicode_ci,
  `ultima_verificacao_xml_entrada_receita` datetime DEFAULT NULL,
  `grupo_nf_veiculos` tinyint(1) DEFAULT '0',
  `nota_scan_manual` enum('Auto','Scan','Producao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Auto',
  `cte_scan_manual` enum('Auto','Scan','Producao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Auto',
  `mdfe_scan_manual` enum('Auto','Scan','Producao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Auto',
  `orientacao_logo_nf` enum('L','C','R') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'C',
  `pdv_tipo_acrescimo` enum('R','P') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'R',
  `pdv_tipo_desconto` enum('R','P','A') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'R',
  `pdv_cupom_impressao` enum('Direta','PDF','POS') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PDF',
  `pdv_impressao_item` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sim',
  `pdv_impressao_codigo` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sim',
  `pdv_impressao_desc` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sim',
  `pdv_impressao_valor` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sim',
  `pdv_impressao_qtde` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `pdv_caixa` enum('2','1','0') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '2',
  `pdv_tela_alterar_emit_nota` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `bal_status` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `bal_tipo_codigo` enum('Valor','Peso') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Valor',
  `geral_tipo_impressao_carne` enum('carnet','triplo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'carnet',
  `geral_tipo_conciliacao_ofx` enum('Ambos','Valor','Data') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Ambos',
  `geral_lancarcontas` enum('Ambos','Nota','Pedido') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Ambos',
  `geral_lancarcontas_serv` enum('Ambos','Nota','OS') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Ambos',
  `geral_lancarcontas_comp` enum('Ambos','Nota','OC') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Ambos',
  `geral_lancarestoque` enum('Ambos','Nota','Pedido') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Ambos',
  PRIMARY KEY (`id_parametro`),
  UNIQUE KEY `id_empresa_uni` (`id_empresa`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_parametros_atividades`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_parametros_atividades` (
  `id_param` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_lista` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id_param`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_parametros_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_parametros_log` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned DEFAULT NULL,
  `id_usuario` int(10) unsigned DEFAULT NULL,
  `form` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parametros_antigos` text COLLATE utf8mb4_unicode_ci,
  `parametros_novos` text COLLATE utf8mb4_unicode_ci,
  `data_cad_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_parametros_mensagens`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_parametros_mensagens` (
  `id_mensagem` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `descricao_mensagem` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fixa_mensagem` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id_mensagem`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_empresas_servicos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_empresas_servicos` (
  `id_servico` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_plano` bigint(20) DEFAULT '0',
  `valor_servico` decimal(10,2) DEFAULT '0.00',
  `valor_acrescimo` tinyint(1) DEFAULT '0',
  `tipo_pagamento` tinyint(1) DEFAULT '1',
  `parcelamento_servico` tinyint(1) DEFAULT '1',
  `obs_servico` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_servico` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_cancelamento` datetime DEFAULT NULL,
  `proximo_mes` date DEFAULT NULL,
  `data_expiracao` date DEFAULT NULL,
  `id_cupom` int(11) DEFAULT '0',
  `id_usuario` int(11) DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_servico`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_cupom` (`id_cupom`),
  KEY `id_plano` (`id_plano`),
  KEY `lixeira` (`lixeira`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=199420 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_usuarios`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_usuarios` (
  `id_usuario` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `nome_usuario` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_usuario` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `celular_usuario` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `login_usuario` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_usuario_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `senha_usuario` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_usuario` enum('Administrador','Usuario') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Administrador',
  `master_usuario` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `dados_usuario` tinyint(1) NOT NULL DEFAULT '0',
  `dados_usuario_cad` tinyint(1) NOT NULL DEFAULT '0',
  `cargo_usuario` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tomador_decisao` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  `home_esquerda` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `home_direita` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `restricoes_usuario` tinyint(1) NOT NULL,
  `hash_recuperar` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `restricoes_ip` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sync` tinyint(1) NOT NULL DEFAULT '0',
  `sync_data` datetime NOT NULL,
  `data_cad_usuario` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `exibicao_clientes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_usuario`),
  KEY `tipo_usuario` (`tipo_usuario`),
  KEY `ix_nfe_config_usuarios_login_usuario_senha_usuario` (`login_usuario`,`senha_usuario`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_usuarios_aplicativos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_usuarios_aplicativos` (
  `id_permissao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT '0',
  `id_usuario` int(11) DEFAULT '0',
  `id_aplicativo` smallint(6) DEFAULT '0',
  PRIMARY KEY (`id_permissao`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_usuarios_permissoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_usuarios_permissoes` (
  `id_permissao` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT '0',
  `id_usuario` bigint(20) DEFAULT '0',
  `id_sub_menu` int(11) DEFAULT '0',
  PRIMARY KEY (`id_permissao`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_usuarios_permissoes_mobile`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_usuarios_permissoes_mobile` (
  `id_permissao_mobile` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `permissao_vendas` int(11) NOT NULL DEFAULT '0',
  `permissao_financeiro` int(11) NOT NULL DEFAULT '0',
  `permissao_servicos` int(11) NOT NULL DEFAULT '0',
  `permissao_edit_val_unit_prod` int(11) NOT NULL DEFAULT '0',
  `permissao_edit_produtos` int(11) NOT NULL DEFAULT '0',
  `permissao_contas_bancarias` int(11) NOT NULL DEFAULT '0',
  `permissao_orcamentos` int(11) NOT NULL DEFAULT '0',
  `permissao_faturas` int(11) DEFAULT '0',
  PRIMARY KEY (`id_permissao_mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_usuarios_recuperar`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_usuarios_recuperar` (
  `id_recuperar` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `ip_usuario` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_recuperar` datetime DEFAULT NULL,
  `recuperado` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id_recuperar`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_usuarios_relatorios`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_usuarios_relatorios` (
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) DEFAULT NULL,
  `id_parceiro` int(11) DEFAULT NULL,
  `relatorio` char(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coluna` char(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordem` enum('','asc','desc') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `display` enum('','none') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_usuarios_restricoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_usuarios_restricoes` (
  `id_restricao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_usuario` bigint(20) NOT NULL DEFAULT '0',
  `dia` tinyint(1) NOT NULL DEFAULT '0',
  `horario_entrada` time NOT NULL DEFAULT '00:00:00',
  `horario_saida` time NOT NULL DEFAULT '00:00:00',
  PRIMARY KEY (`id_restricao`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_usuarios_widgets`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_usuarios_widgets` (
  `id_usuario` int(11) NOT NULL,
  `id_widget` int(11) NOT NULL,
  `ordem` int(11) DEFAULT NULL,
  `coluna` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `id_usuario_id_widget` (`id_usuario`,`id_widget`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_whitelabel`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_whitelabel` (
  `id_whitelabel` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` longtext COLLATE utf8mb4_unicode_ci,
  `genero_whitelabel` tinyint(1) NOT NULL DEFAULT '0',
  `nome_whitelabel` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `titulo_whitelabel` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `titulo_curto_whitelabel` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_whitelabel` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_portal_whitelabel` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone_whitelabel` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone_suporte_whitelabel` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone_vendas_whitelabel` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone_celular_whitelabel` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `twitter_whitelabel` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `youtube_whitelabel` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `facebook_whitelabel` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `googleplus_whitelabel` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `linkedin_whitelabel` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `css_email_whitelabel` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_whitelabel` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `sso_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `sso_realm` longtext COLLATE utf8mb4_unicode_ci,
  `sso_key_backend` longtext COLLATE utf8mb4_unicode_ci,
  `sso_key_auth` longtext COLLATE utf8mb4_unicode_ci,
  `sso_audience` longtext COLLATE utf8mb4_unicode_ci,
  `sso_url` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id_whitelabel`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_widgets`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_widgets` (
  `id_widget` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome_widget` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imagem_widget` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descricao_widget` text COLLATE utf8mb4_unicode_ci,
  `trigger_widget` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `categoria_widget` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_widget`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_config_widgets_permissoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_config_widgets_permissoes` (
  `id_widget` int(11) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  UNIQUE KEY `id_widget_id_usuario` (`id_widget`,`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_consumidor`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_consumidor` (
  `id_nfc` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `serie_nota` int(11) NOT NULL DEFAULT '1',
  `id_pedido` int(11) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) NOT NULL DEFAULT '0',
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cliente_inexistente` tinyint(1) NOT NULL DEFAULT '0',
  `id_local_retirada` int(11) NOT NULL DEFAULT '0',
  `id_local_entrega` int(11) NOT NULL DEFAULT '0',
  `id_local_cobranca` int(11) NOT NULL DEFAULT '0',
  `vendedor_pedido` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendedor_pedido_id` bigint(20) DEFAULT '0',
  `listapreco_produtos` int(11) NOT NULL DEFAULT '0',
  `valor_total_produtos` decimal(10,2) DEFAULT '0.00',
  `desconto_pedido` decimal(10,2) DEFAULT '0.00',
  `desconto_pedido_porc` decimal(10,2) DEFAULT '0.00',
  `peso_total_nota` decimal(10,4) DEFAULT '0.0000',
  `peso_total_nota_liq` decimal(10,4) DEFAULT '0.0000',
  `frete_pedido` decimal(10,2) DEFAULT '0.00',
  `valor_total_nota` decimal(10,2) DEFAULT '0.00',
  `valor_baseICMS` decimal(10,2) DEFAULT '0.00',
  `valor_ICMS` decimal(10,2) DEFAULT '0.00',
  `valor_despesas` decimal(10,2) DEFAULT '0.00',
  `valor_serv_pis` decimal(10,2) DEFAULT '0.00',
  `valor_serv_cofins` decimal(10,2) DEFAULT '0.00',
  `valor_serv_csll` decimal(10,2) DEFAULT '0.00',
  `valor_serv_irrf` decimal(10,2) DEFAULT '0.00',
  `valor_serv_prev` decimal(10,2) DEFAULT '0.00',
  `valor_total_servicos` decimal(10,2) DEFAULT '0.00',
  `condicao_pagamento_id` int(11) DEFAULT '0',
  `condicao_pagamento` tinyint(1) DEFAULT NULL,
  `frete_por_pedido` tinyint(1) DEFAULT '9',
  `transportadora_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_transportadora` int(11) DEFAULT NULL,
  `volumes_transporta` int(11) DEFAULT NULL,
  `especie_transporta` char(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marca_transporta` char(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numeracao_transporta` char(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `placa_transporta` char(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `indPres_pedido` tinyint(1) DEFAULT '9',
  `natureza_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cfop_pedido` char(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `obs_pedido` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `obs_interno_pedido` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_pedido` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Em Aberto',
  `contas_pedido` tinyint(1) NOT NULL DEFAULT '0',
  `comissao_pedido` tinyint(1) NOT NULL DEFAULT '0',
  `estoque_pedido` tinyint(1) NOT NULL DEFAULT '0',
  `nota_emitida` tinyint(1) NOT NULL DEFAULT '0',
  `nota_chave` char(44) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nota_protocolo` char(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nota_recibo` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nota_data_autorizacao` datetime DEFAULT NULL,
  `nota_usuario_autorizacao` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nota_data_cancelamento` datetime DEFAULT NULL,
  `nota_usuario_cancelamento` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nota_motivo_cancelamento` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nota_denegada` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario_cad_pedido` bigint(20) NOT NULL DEFAULT '0',
  `pdv_emitido` int(11) NOT NULL DEFAULT '0',
  `data_cad_pedido` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_pedido` datetime DEFAULT NULL,
  `ambiente` tinyint(1) NOT NULL DEFAULT '2',
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  `sync_user` int(11) DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `url_qr_code` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id_nfc`),
  KEY `ix_nfe_consumidor_id_empresa_lixeira` (`id_empresa`,`lixeira`),
  KEY `ix_nfe_consumidor_id_empresa_status_pedido` (`id_empresa`,`status_pedido`),
  KEY `ix_nfe_consumidor_id_empresa_nota_data_autorizacao` (`id_empresa`,`nota_data_autorizacao`),
  KEY `id_empresa` (`id_empresa`),
  KEY `ix_nfe_consumidor_id_empresa_valor_total_nota` (`id_empresa`,`valor_total_nota`),
  KEY `lixeira` (`lixeira`),
  KEY `ix_nfe_consumidor_id_empresa_id_pedido` (`id_empresa`,`id_pedido`),
  KEY `nota_emitida` (`nota_emitida`),
  KEY `ix_nfe_consumidor_id_empresa_nome_cliente` (`id_empresa`,`nome_cliente`),
  KEY `ix_nfe_consumidor_id_empresa_vendedor_pedido` (`id_empresa`,`vendedor_pedido`),
  KEY `status_pedido` (`status_pedido`),
  KEY `nota_chave` (`nota_chave`),
  KEY `sync` (`sync`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_consumidor_mensagens`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_consumidor_mensagens` (
  `id_mensagem` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_nfc` bigint(20) DEFAULT '0',
  `descricao_mensagem` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_mensagem`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_venda` (`id_nfc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_consumidor_parcelas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_consumidor_parcelas` (
  `id_parcela` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_nfc` bigint(20) DEFAULT '0',
  `data_parcela` date DEFAULT NULL,
  `valor_parcela` decimal(10,2) DEFAULT '0.00',
  `forma_pagamento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes_parcela` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_parcela`),
  KEY `id_venda` (`id_nfc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_consumidor_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_consumidor_produtos` (
  `id_ped_produto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_nfc` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `cod_produto` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desc_produto` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qtde_produto` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `icms_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_unit_produto` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `valor_custo_produto` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `valor_total_produto` decimal(15,2) NOT NULL DEFAULT '0.00',
  `vBC_produto` decimal(15,2) NOT NULL DEFAULT '0.00',
  `vICMS_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cfop_produto` int(11) NOT NULL DEFAULT '0',
  `ncm_produto` char(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unidade_produto` char(6) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'UN',
  `unidade_tributavel` char(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `beneficio_fiscal` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `origem_produto` tinyint(1) NOT NULL DEFAULT '0',
  `peso_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `peso_liq_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tipo_produto` tinyint(1) NOT NULL DEFAULT '1',
  `info_adicional` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ordem_produto` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_barras` char(14) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_tributos_unit` decimal(15,2) NOT NULL DEFAULT '0.00',
  `valor_tributos_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_tributosEst_unit` decimal(15,2) NOT NULL DEFAULT '0.00',
  `valor_tributosEst_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `xPed_produto` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nItem_produto` smallint(6) DEFAULT NULL,
  `codigo_cest` char(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_ped_produto`),
  KEY `id_produto` (`id_produto`),
  KEY `id_venda` (`id_nfc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_consumidor_produtos_COFINS`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_consumidor_produtos_COFINS` (
  `id_cofins` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_nfc` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `cst_cofins` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '08',
  `vBC_cofins` decimal(10,2) DEFAULT '0.00',
  `pCOFINS_cofins` decimal(10,2) DEFAULT '0.00',
  `vCOFINS_cofins` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id_cofins`),
  UNIQUE KEY `id_produto` (`id_produto`),
  KEY `id_venda` (`id_nfc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_consumidor_produtos_COMB`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_consumidor_produtos_COMB` (
  `id_comb` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_nfc` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `cod_anp_comb` char(9) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cod_codif_comb` char(21) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qTemp_comb` decimal(10,4) DEFAULT '0.0000',
  `UFCons_comb` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qBCProd_comb` decimal(10,4) DEFAULT '0.0000',
  `vAliqProd_comb` decimal(10,4) DEFAULT '0.0000',
  `vCIDE_comb` decimal(10,2) DEFAULT '0.00',
  `descANP_comb` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pGLP_comb` decimal(10,4) DEFAULT NULL,
  `pGNn_comb` decimal(10,4) DEFAULT NULL,
  `pGNi_comb` decimal(10,4) DEFAULT NULL,
  `vPart_comb` decimal(10,4) DEFAULT NULL,
  PRIMARY KEY (`id_comb`),
  UNIQUE KEY `id_produto` (`id_produto`),
  KEY `id_venda` (`id_nfc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_consumidor_produtos_ICMS`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_consumidor_produtos_ICMS` (
  `id_icms` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_nfc` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `cst_icms` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '40',
  `origem_mercadoria` tinyint(1) NOT NULL DEFAULT '0',
  `modalidade_icms` tinyint(1) NOT NULL DEFAULT '3',
  `vBC_icms` decimal(10,2) DEFAULT '0.00',
  `pICMS_icms` decimal(10,2) DEFAULT '0.00',
  `vICMS_icms` decimal(10,2) DEFAULT '0.00',
  `pRedBC_icms` decimal(10,2) DEFAULT '0.00',
  `vICMSDeson_icms` decimal(10,2) DEFAULT '0.00',
  `motDesICMS_icms` tinyint(1) DEFAULT '9',
  `pCredSN_icms` decimal(10,2) DEFAULT '0.00',
  `vCredICMSSN_icms` decimal(10,2) DEFAULT '0.00',
  `pST_icms` decimal(10,2) DEFAULT '0.00',
  `vBCSTRet_icms` decimal(10,2) DEFAULT '0.00',
  `vICMSSTRet_icms` decimal(10,2) DEFAULT '0.00',
  `pDif_icms` decimal(10,4) DEFAULT '0.0000',
  `vICMSSubstituto` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id_icms`),
  UNIQUE KEY `id_produto` (`id_produto`),
  KEY `id_venda` (`id_nfc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_consumidor_produtos_ISSQN`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_consumidor_produtos_ISSQN` (
  `id_issqn` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_nfc` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `tributacao_issqn` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'I',
  `vBC_issqn` decimal(10,2) DEFAULT '0.00',
  `pISSQN_issqn` decimal(10,2) DEFAULT '0.00',
  `vISSQN_issqn` decimal(10,2) DEFAULT '0.00',
  `cListServ_issqn` char(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_issqn` char(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_issqn_cod` int(11) DEFAULT NULL,
  `estado_issqn` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_issqn`),
  UNIQUE KEY `id_produto` (`id_produto`),
  KEY `id_venda` (`id_nfc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_consumidor_produtos_PIS`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_consumidor_produtos_PIS` (
  `id_pis` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_nfc` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `cst_pis` char(2) COLLATE utf8mb4_unicode_ci DEFAULT '08',
  `vBC_pis` decimal(10,2) DEFAULT '0.00',
  `pPIS_pis` decimal(10,2) DEFAULT '0.00',
  `vPIS_pis` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id_pis`),
  UNIQUE KEY `id_produto` (`id_produto`),
  KEY `id_venda` (`id_nfc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_consumidor_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_consumidor_status` (
  `id_status` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_nfc` bigint(20) DEFAULT '0',
  `data_status` date DEFAULT NULL,
  `obs_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_status` char(15) COLLATE utf8mb4_unicode_ci DEFAULT 'Em Aberto',
  PRIMARY KEY (`id_status`),
  KEY `id_venda` (`id_nfc`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_empresa_id_nfc` (`id_empresa`,`id_nfc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_consumidor_sync`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_consumidor_sync` (
  `id_nfc` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  UNIQUE KEY `id_nfc_id_usuario_uniq` (`id_nfc`,`id_usuario`),
  KEY `id_nfc_id_usuario` (`id_nfc`,`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_contas_bancarias_email`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_contas_bancarias_email` (
  `id_email` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) unsigned NOT NULL DEFAULT '0',
  `id_banco` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_email` datetime NOT NULL,
  PRIMARY KEY (`id_email`),
  KEY `id_empresa` (`id_empresa`),
  KEY `identificacao` (`id_banco`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_controle_email`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_controle_email` (
  `id_email` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) unsigned NOT NULL DEFAULT '0',
  `identificacao` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_email` enum('E','L') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'E',
  `usuario` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_email` datetime NOT NULL,
  PRIMARY KEY (`id_email`),
  KEY `identificacao` (`identificacao`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_creditos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_creditos` (
  `id_credito` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `qtde_credito` decimal(10,2) DEFAULT '0.00',
  `obs_credito` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_credito` datetime NOT NULL,
  `usuario_credito` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_credito`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_creditos_recarga`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_creditos_recarga` (
  `id_recarga` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `valor_recarga` decimal(10,2) NOT NULL DEFAULT '0.00',
  `fatura_recarga` bigint(20) NOT NULL DEFAULT '0',
  `data_cad_recarga` datetime NOT NULL,
  `usuario_recarga` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recarregado` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_recarga`),
  KEY `id_empresa` (`id_empresa`),
  KEY `recarregado` (`recarregado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cte`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cte` (
  `id_cte` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned NOT NULL DEFAULT '0',
  `id_pedido` int(10) unsigned NOT NULL DEFAULT '0',
  `serie_cte` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ambiente` tinyint(3) unsigned NOT NULL DEFAULT '2',
  `tipo_cte` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `tipo_servico` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `data_hora_emissao` datetime NOT NULL,
  `cfop` int(10) unsigned NOT NULL,
  `desc_natureza` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cod_cidade_inicio` int(10) unsigned NOT NULL,
  `cidade_inicio` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uf_cidade_inicio` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cod_cidade_final` int(10) unsigned NOT NULL,
  `cidade_final` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uf_cidade_final` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tomador_servico` tinyint(1) NOT NULL,
  `razao_remetente` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_remetente` int(10) unsigned NOT NULL,
  `razao_destinatario` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_destinatario` int(11) NOT NULL,
  `razao_expedidor` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_expedidor` int(10) unsigned NOT NULL,
  `razao_recebedor` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_recebedor` int(10) unsigned NOT NULL,
  `razao_tomador` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_tomador` int(10) unsigned NOT NULL,
  `valor_carga` decimal(10,2) NOT NULL,
  `produto_predominante` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `outras_caracteristicas` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rntrc` char(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_servico_documento` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_total_prestacao_servico` decimal(16,6) NOT NULL,
  `valor_receber` decimal(16,6) NOT NULL,
  `forma_pagamento` tinyint(1) NOT NULL,
  `valor_aproximado_tributos` decimal(16,6) NOT NULL,
  `cst_icms` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_calculo_icms` decimal(16,6) NOT NULL,
  `valor_bc_icms_retido` decimal(16,6) NOT NULL,
  `aliquota_icms` decimal(16,6) NOT NULL,
  `valor_icms` decimal(16,6) NOT NULL,
  `valor_icms_st_retido` decimal(16,6) NOT NULL,
  `percentual_reducao_base_calculo_icms` decimal(16,6) NOT NULL,
  `credito_icms` decimal(16,6) NOT NULL,
  `valor_base_calculo_icms` decimal(16,6) NOT NULL,
  `aliquoa_interna_uf_termino` decimal(16,6) NOT NULL,
  `aliquota_interestadual` decimal(16,6) NOT NULL,
  `porcentagem_partilha_uf_termino` decimal(16,6) NOT NULL,
  `valor_icms_partilha_uf_inicio` decimal(16,6) NOT NULL,
  `valor_icms_partilha_uf_termino` decimal(16,6) NOT NULL,
  `porcentagem_icms_fcp_uf_termino` decimal(16,6) NOT NULL,
  `valor_icms_fcp_uf_termino` decimal(16,6) NOT NULL,
  `observacoes_adicionais` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `numero_fatura` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_origem` decimal(16,6) NOT NULL,
  `valor_desconto` decimal(16,6) NOT NULL,
  `valor` decimal(16,6) NOT NULL,
  `condicao_pagamento_id` int(11) NOT NULL DEFAULT '0',
  `condicao_pagamento` tinyint(1) NOT NULL,
  `cte_chave` char(44) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `cte_recibo` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `cte_protocolo` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `cte_emitida` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `contas_cte` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `nota_scan` int(10) unsigned NOT NULL,
  `cte_usuario_autorizacao` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cte_data_autorizacao` datetime NOT NULL,
  `cte_usuario_cancelamento` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cte_data_cancelamento` datetime NOT NULL,
  `cte_motivo_cancelamento` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cte_denegada` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_cte` char(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Em Aberto',
  `data_cad_cte` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_cte` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_usuario_cad` int(10) unsigned NOT NULL DEFAULT '0',
  `id_usuario_mod` int(10) unsigned NOT NULL DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_cte`),
  KEY `id_pedido` (`id_pedido`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cte_carta_correcao`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cte_carta_correcao` (
  `id_cce` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `nome_usuario` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chave_cte` char(44) COLLATE utf8mb4_unicode_ci NOT NULL,
  `correcao_cce` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `chave_cce` char(54) COLLATE utf8mb4_unicode_ci NOT NULL,
  `protocolo_cce` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sequencia_cce` tinyint(1) NOT NULL DEFAULT '1',
  `ambiente` tinyint(1) NOT NULL DEFAULT '2',
  `data_cad_cce` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cce`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cte_comprovante_entrega`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cte_comprovante_entrega` (
  `id_comprovante_entrega` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cte_id_pedido` int(11) NOT NULL,
  `cte_chave` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cte_protocolo` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cte_protocolo_ce` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cte_chave_ce` char(54) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `cte_obs_text` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cte_nome_recebedor` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cte_doc_recebedor` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cte_lat_recebedor` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cte_long_recebedor` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cte_data_hora_entrega` datetime NOT NULL,
  `cte_data_hora_autorizacao` datetime NOT NULL,
  `cte_chaves_vinculadas` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cte_indentificador_vhdrive` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancelado` smallint(6) DEFAULT '0',
  `lixeira` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `id_cte` int(11) NOT NULL,
  `cte_sequencial_comp` int(10) unsigned DEFAULT '1',
  `id_empresa` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_comprovante_entrega`),
  UNIQUE KEY `id_comprovante_entrega_UNIQUE` (`id_comprovante_entrega`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cte_documentos_anteriores`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cte_documentos_anteriores` (
  `id_documento_anterior` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_cte` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL,
  `razao_social_nome_documento_anterior` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cpf_cnpj_documento_anterior` char(18) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inscricao_estadual_documento_anterior` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uf_documento_anterior` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_documento_anterior` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_documento_anterior`),
  KEY `id_cte` (`id_cte`),
  KEY `id_documento_anterior` (`id_documento_anterior`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cte_documentos_anteriores_eletronico`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cte_documentos_anteriores_eletronico` (
  `id_documento_anterior_eletronico` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_documento_anterior` int(11) NOT NULL,
  `id_cte` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `chave_acesso_documento_anterior_eletronico` varchar(44) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_documento_anterior_eletronico` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_documento_anterior_eletronico`),
  KEY `id_documento_anterior_eletronico` (`id_documento_anterior_eletronico`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_documento_anterior` (`id_documento_anterior`),
  KEY `id_cte` (`id_cte`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cte_documentos_anteriores_papel`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cte_documentos_anteriores_papel` (
  `id_documento_anterior_papel` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_cte` int(11) NOT NULL,
  `id_documento_anterior` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `tipo_documento_anterior_papel` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serie_documento_anterior_papel` char(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_serie_documento_anterior_papel` char(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_documento_anterior_papel` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_emissao_documento_anterior_papel` date DEFAULT NULL,
  `data_cad_documento_anterior_papel` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_documento_anterior_papel`),
  KEY `id_documento_anterior` (`id_documento_anterior`),
  KEY `id_cte` (`id_cte`),
  KEY `id_documento_anterior_papel` (`id_documento_anterior_papel`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cte_documentos_notas_fiscais`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cte_documentos_notas_fiscais` (
  `id_documentos_nota_fiscal` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_cte` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `serie` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `numero` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `data_emissao` date DEFAULT NULL,
  `cfop` smallint(6) DEFAULT '0',
  `desc_natureza` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bc_icms` decimal(10,2) DEFAULT '0.00',
  `bc_icms_st` decimal(10,2) DEFAULT '0.00',
  `valor_icms` decimal(10,2) DEFAULT '0.00',
  `valor_icms_st` decimal(10,2) DEFAULT '0.00',
  `valor_produtos` decimal(10,2) DEFAULT '0.00',
  `valor_nota` decimal(10,2) NOT NULL DEFAULT '0.00',
  `data_cad_documentos_nota_fiscal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_documentos_nota_fiscal`),
  KEY `id_cte_documentos_nota_fiscal` (`id_documentos_nota_fiscal`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_cte` (`id_cte`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cte_documentos_notas_fiscais_eletronica`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cte_documentos_notas_fiscais_eletronica` (
  `id_documentos_nota_fiscal_eletronica` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_cte` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `chave_acesso` char(44) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_mod_documentos_nota_fiscal_eletronica` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_cad_documentos_nota_fiscal_eletronica` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_documentos_nota_fiscal_eletronica`),
  KEY `id_cte_documentos_nota_fiscal_eletronica` (`id_documentos_nota_fiscal_eletronica`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_cte` (`id_cte`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cte_documentos_outros_documentos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cte_documentos_outros_documentos` (
  `id_documentos_outro_documento` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_cte` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `origem_documento` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descricao_documento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_documento` int(11) NOT NULL,
  `emissao_documento` date DEFAULT NULL,
  `valor_documento` decimal(10,2) DEFAULT NULL,
  `previsao_data_documento` date DEFAULT NULL,
  `data_cad_documentos_outro_documento` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_documentos_outro_documento`),
  KEY `id_cte_documentos_outro_documento` (`id_documentos_outro_documento`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_cte` (`id_cte`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cte_informacoes_carga`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cte_informacoes_carga` (
  `id_informacao_carga` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_cte` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `unidade_medida` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_medida` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantidade_carga` decimal(16,6) NOT NULL,
  `data_cad_informacao_carga` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_informacao_carga`),
  KEY `id_informacao_carga` (`id_informacao_carga`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_cte` (`id_cte`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cte_parcelas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cte_parcelas` (
  `id_parcela` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_cte` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `data_parcela` date NOT NULL,
  `valor_parcela` decimal(16,6) NOT NULL,
  `forma_pagamento` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `observacoes_parcela` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_parcela` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_parcela`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_cte` (`id_cte`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cte_prestacoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cte_prestacoes` (
  `id_prestacao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_cte` int(10) unsigned NOT NULL,
  `id_empresa` int(10) unsigned NOT NULL,
  `prestacao_nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prestacao_valor` decimal(16,6) NOT NULL,
  `data_cad_prestacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_prestacao`),
  KEY `id_cte` (`id_cte`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_cte_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_cte_status` (
  `id_status` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `id_cte` int(11) DEFAULT NULL,
  `data_status` date DEFAULT NULL,
  `obs_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_status` char(15) COLLATE utf8mb4_unicode_ci DEFAULT 'Em Aberto',
  `data_cad_status` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `id_usuario_cad_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_status`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_cte` (`id_cte`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_discador`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_discador` (
  `id_discador` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned NOT NULL,
  `id_usuario` int(10) unsigned DEFAULT NULL,
  `fila` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `3cx_unique_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_chamada` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_discador`),
  KEY `id_empresa` (`id_empresa`),
  KEY `fila` (`fila`),
  KEY `id_usuario` (`id_usuario`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_discador_usuarios_online`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_discador_usuarios_online` (
  `id_online` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) DEFAULT NULL,
  `id_empresa` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_online`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_entradas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_entradas` (
  `id_entrada` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_pedido` int(11) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) DEFAULT '0',
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendedor_pedido` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_total_produtos` decimal(10,2) DEFAULT '0.00',
  `desconto_pedido` decimal(10,2) DEFAULT '0.00',
  `desconto_pedido_porc` decimal(10,2) DEFAULT '0.00',
  `peso_total_nota` decimal(10,2) DEFAULT '0.00',
  `frete_pedido` decimal(10,2) DEFAULT '0.00',
  `valor_total_nota` decimal(10,2) DEFAULT '0.00',
  `valor_baseICMS` decimal(10,2) DEFAULT '0.00',
  `valor_ICMS` decimal(10,2) DEFAULT '0.00',
  `valor_baseST` decimal(10,2) DEFAULT '0.00',
  `valor_ST` decimal(10,2) DEFAULT '0.00',
  `valor_IPI` decimal(10,2) DEFAULT '0.00',
  `valor_PIS` decimal(10,2) DEFAULT '0.00',
  `valor_COFINS` decimal(10,2) DEFAULT '0.00',
  `condicao_pagamento` tinyint(1) DEFAULT NULL,
  `frete_por_pedido` tinyint(1) DEFAULT '9',
  `transportadora_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_transportadora` int(11) DEFAULT '0',
  `data_pedido` date DEFAULT NULL,
  `aplicacao_pedido` tinyint(1) DEFAULT '1',
  `id_centro_custos` bigint(20) unsigned NOT NULL DEFAULT '0',
  `centro_custos_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `obs_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `obs_interno_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `status_pedido` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Em Aberto',
  `contas_pedido` tinyint(1) NOT NULL DEFAULT '0',
  `estoque_pedido` tinyint(1) NOT NULL DEFAULT '0',
  `nota_numero` char(9) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nota_chave` varchar(44) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nota_protocolo` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nota_data_autorizacao` datetime DEFAULT NULL,
  `nota_caminho` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nota_entrada` tinyint(1) NOT NULL DEFAULT '0',
  `nota_baixada` tinyint(1) NOT NULL DEFAULT '0',
  `data_cad_pedido` datetime DEFAULT NULL,
  `data_mod_pedido` datetime DEFAULT NULL,
  `modelo_nota` char(9) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serie_nota` char(9) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `importacao` tinyint(1) DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_entrada`),
  KEY `ix_nfe_entradas_id_empresa_nota_numero` (`id_empresa`,`nota_numero`),
  KEY `ix_nfe_entradas_id_empresa_id_pedido` (`id_empresa`,`id_pedido`),
  KEY `ix_nfe_entradas_id_empresa_nome_cliente` (`id_empresa`,`nome_cliente`),
  KEY `status_pedido` (`status_pedido`),
  KEY `ix_nfe_entradas_id_empresa_vendedor_pedido` (`id_empresa`,`vendedor_pedido`),
  KEY `ix_nfe_entradas_id_empresa_lixeira` (`id_empresa`,`lixeira`),
  KEY `ix_nfe_entradas_id_empresa_status_pedido` (`id_empresa`,`status_pedido`),
  KEY `ix_nfe_entradas_id_empresa_nota_data_autorizacao` (`id_empresa`,`nota_data_autorizacao`),
  KEY `ix_nfe_entradas_id_empresa_data_pedido` (`id_empresa`,`data_pedido`),
  KEY `ix_nfe_entradas_id_empresa_valor_total_nota` (`id_empresa`,`valor_total_nota`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_entradas_conversoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_entradas_conversoes` (
  `id_conversao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_produto` int(11) NOT NULL DEFAULT '0',
  `de_unidade` char(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `de_qtde` decimal(10,2) DEFAULT NULL,
  `para_unidade` char(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `para_qtde` decimal(15,10) DEFAULT NULL,
  PRIMARY KEY (`id_conversao`),
  KEY `id_empresa_id_produto` (`id_empresa`,`id_produto`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_entradas_parcelas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_entradas_parcelas` (
  `id_parcela` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_entrada` bigint(20) DEFAULT '0',
  `data_parcela` date DEFAULT NULL,
  `valor_parcela` decimal(10,2) DEFAULT '0.00',
  `forma_pagamento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes_parcela` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_parcela`),
  KEY `id_entrada` (`id_entrada`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_entradas_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_entradas_produtos` (
  `id_ped_produto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_entrada` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `desc_produto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `substituido` tinyint(1) NOT NULL DEFAULT '0',
  `qtde_produto` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `unidade_produto` char(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qtde_entrada_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `unidade_entrada_produto` char(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desconto_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ipi_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `icms_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cfop_produto` char(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ncm_produto` char(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_unit_produto` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `valor_entrada_unit_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_total_produto` decimal(15,2) NOT NULL DEFAULT '0.00',
  `valor_entrada_total_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `peso_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `peso_liq_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_ped_produto`),
  KEY `id_entrada` (`id_entrada`),
  KEY `id_produto` (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_entradas_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_entradas_status` (
  `id_status` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_entrada` bigint(20) DEFAULT '0',
  `data_status` date DEFAULT NULL,
  `obs_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_status` char(15) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Em Aberto',
  PRIMARY KEY (`id_status`),
  KEY `id_entrada` (`id_entrada`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_empresa_id_entrada` (`id_empresa`,`id_entrada`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_enviar_email`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_enviar_email` (
  `id_email` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `enviar_email` tinyint(1) NOT NULL DEFAULT '0',
  `assunto_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conteudo_email` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_email` datetime NOT NULL,
  PRIMARY KEY (`id_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_enviosms`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_enviosms` (
  `id_sms` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `tipo_envio` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dias_sms` tinyint(1) NOT NULL,
  `hora_envio` tinyint(1) NOT NULL,
  `numeros_envio` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_sms` datetime NOT NULL,
  `usuario_cad_sms` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_sms`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_enviosms_ativacao`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_enviosms_ativacao` (
  `id_ativacao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo` int(11) DEFAULT NULL,
  `data_ativacao` datetime DEFAULT NULL,
  PRIMARY KEY (`id_ativacao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_enviosms_avulso`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_enviosms_avulso` (
  `id_sms` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `nome_usuario` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `destino_sms` longtext COLLATE utf8mb4_unicode_ci,
  `mensagem_sms` varchar(160) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_envio` datetime DEFAULT NULL,
  PRIMARY KEY (`id_sms`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_enviosms_black_list`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_enviosms_black_list` (
  `id_sms_black_list` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `numero` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_sms_black_list`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_sms_black_list` (`id_sms_black_list`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_enviosms_palavras_black_list`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_enviosms_palavras_black_list` (
  `id_palavra` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `palavra` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `match` int(11) NOT NULL DEFAULT '0',
  `data_cad_palavra` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_palavra` datetime DEFAULT NULL,
  PRIMARY KEY (`id_palavra`),
  KEY `idx_nfe_enviosms_msg_black_list_palavra` (`palavra`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_estados`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_estados` (
  `id_uf` tinyint(1) NOT NULL,
  `valor_uf` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao_uf` char(19) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_ibge` int(11) DEFAULT NULL,
  `scan_nfe` tinyint(1) DEFAULT '0',
  `scan_cte` tinyint(1) DEFAULT '0',
  `scan_mdfe` tinyint(1) DEFAULT '0',
  `icmsst` tinyint(1) DEFAULT '0',
  UNIQUE KEY `codigo_ibge` (`codigo_ibge`),
  KEY `valor_uf` (`valor_uf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_evo_bearers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_evo_bearers` (
  `id_bearer` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `bearer` char(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `data_cad` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_bearer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_evo_config`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_evo_config` (
  `id_config` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `merchantId` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apikey` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_config` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_config` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_config`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_evo_terminals`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_evo_terminals` (
  `id_terminal` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `macAddress` char(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `computerName` char(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `terminalId` char(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_terminal`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_evo_transactions`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_evo_transactions` (
  `id_transaction` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `id_conta_rec` int(11) NOT NULL DEFAULT '0',
  `id_parcela` int(11) NOT NULL DEFAULT '0',
  `success` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transactionId` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `error` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_transaction` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_transaction` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_del_transaction` datetime DEFAULT NULL,
  PRIMARY KEY (`id_transaction`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_evo_transactions_callback`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_evo_transactions_callback` (
  `id_transactions_callback` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_transaction` int(11) NOT NULL DEFAULT '0',
  `remoteTransactionId` char(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status` char(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `merchantId` char(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `value` decimal(10,2) NOT NULL DEFAULT '0.00',
  `paymentBrand` char(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `transactionNumber` char(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `paymentQuantity` int(11) NOT NULL DEFAULT '0',
  `clientName` char(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_transactions_callback`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_evo_transactions_callback_payments`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_evo_transactions_callback_payments` (
  `id_transactions_callback_payments` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_transactions_callback` int(10) unsigned NOT NULL DEFAULT '0',
  `status` char(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `value` decimal(10,2) NOT NULL DEFAULT '0.00',
  `number` int(11) NOT NULL,
  `date` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_transactions_callback_payments`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_faturas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_faturas` (
  `id_fatura` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL,
  `id_fatura_integral` bigint(20) NOT NULL,
  `id_cartao` int(11) NOT NULL DEFAULT '0',
  `nome_empresa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_fatura` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_taxa` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_pago` decimal(10,2) NOT NULL DEFAULT '0.00',
  `juros` decimal(10,2) NOT NULL DEFAULT '0.00',
  `periodicidade_pagamento` tinyint(1) NOT NULL DEFAULT '1',
  `vencimento_fatura` date NOT NULL,
  `obs_descritivo` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_pagamento` date DEFAULT NULL,
  `data_recebimento` date DEFAULT NULL,
  `parcelamento_fatura` tinyint(1) DEFAULT '1',
  `obs_pagamento` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_pagamento` tinyint(1) DEFAULT NULL,
  `cod_pagamento` char(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cod_autorizacao` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `liquidado` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `cancelado` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `comissao_parceiro` decimal(10,2) NOT NULL DEFAULT '0.00',
  `gerado_por` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sistema',
  `tipo_pagamento` enum('Boleto','Cartao','Creditos') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Boleto',
  `url_boleto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linha_digitavel` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nosso_numero` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_pagamento` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000.000.000.000',
  `primeira_fatura` tinyint(1) NOT NULL DEFAULT '0',
  `indicado_por` int(11) DEFAULT '0',
  `views` smallint(6) NOT NULL DEFAULT '0',
  `nota_fiscal` int(11) NOT NULL DEFAULT '0',
  `criacao_pagamento` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `data_cad_fatura` datetime NOT NULL,
  `data_mod_fatura` datetime NOT NULL,
  `usuario_cancelamento` char(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usuario_alteracao` char(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cancelamento` datetime DEFAULT NULL,
  `lixeira_motivo` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_fatura`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_empresa_vencimento_fatura` (`id_empresa`,`vencimento_fatura`),
  KEY `ix_nazar_nfe_faturas_liquidado` (`liquidado`),
  KEY `lixeira` (`lixeira`),
  KEY `nota_fiscal` (`nota_fiscal`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_faturas_alteracoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_faturas_alteracoes` (
  `id_fatura` bigint(20) NOT NULL DEFAULT '0',
  `id_empresa` bigint(20) NOT NULL,
  `id_fatura_integral` bigint(20) NOT NULL,
  `id_cartao` int(11) NOT NULL DEFAULT '0',
  `nome_empresa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_fatura` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_taxa` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_pago` decimal(10,2) NOT NULL DEFAULT '0.00',
  `juros` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vencimento_fatura` date NOT NULL,
  `obs_descritivo` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_pagamento` date DEFAULT NULL,
  `data_recebimento` date DEFAULT NULL,
  `parcelamento_fatura` tinyint(1) DEFAULT '1',
  `obs_pagamento` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_pagamento` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cod_pagamento` char(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `liquidado` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `cancelado` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `comissao_parceiro` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `gerado_por` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sistema',
  `tipo_pagamento` enum('Boleto','Cartao','Creditos') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Boleto',
  `url_boleto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_pagamento` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000.000.000.000',
  `primeira_fatura` tinyint(1) NOT NULL DEFAULT '0',
  `indicado_por` int(11) NOT NULL DEFAULT '0',
  `views` smallint(6) NOT NULL DEFAULT '0',
  `nota_fiscal` int(11) NOT NULL DEFAULT '0',
  `data_cad_fatura` datetime NOT NULL,
  `data_mod_fatura` datetime NOT NULL,
  `usuario_cancelamento` char(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usuario_alteracao` char(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cancelamento` datetime DEFAULT NULL,
  `lixeira_motivo` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `data_alteracao_fatura` datetime DEFAULT NULL,
  KEY `id_fatura` (`id_fatura`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_faturas_comissoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_faturas_comissoes` (
  `id_comissao` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_fatura` bigint(20) NOT NULL DEFAULT '0',
  `id_contabilidade` int(11) NOT NULL DEFAULT '0',
  `id_parceiro` int(11) NOT NULL DEFAULT '0',
  `id_empresa` bigint(20) NOT NULL,
  `nome_empresa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_pago` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_comissao` decimal(10,2) DEFAULT '0.00',
  `vencimento_fatura` date NOT NULL,
  `data_liquidacao` datetime NOT NULL,
  PRIMARY KEY (`id_comissao`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_fatura` (`id_fatura`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_faturas_logs`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_faturas_logs` (
  `id_fatura_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_fatura` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `fatura_log` char(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Criada',
  `data_cad_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_fatura_log`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_fatura_log` (`id_fatura_log`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_faturas_processar_cartao_historia`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_faturas_processar_cartao_historia` (
  `id_historia` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descricao` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `enviado_para` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_historia` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_historia`),
  KEY `id_historia` (`id_historia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_faturas_processar_cartao_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_faturas_processar_cartao_log` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_fatura` int(11) NOT NULL,
  `id_cartao` int(11) NOT NULL,
  `desc_log` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `erro_cielo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_fatura` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`),
  KEY `id_log` (`id_log`),
  KEY `id_fatura` (`id_fatura`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_faturas_servicos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_faturas_servicos` (
  `id_serv` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `id_fatura` bigint(20) NOT NULL DEFAULT '0',
  `id_plano` bigint(20) DEFAULT '0',
  `valor_servico` decimal(10,2) DEFAULT '0.00',
  `obs_servico` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_serv`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_fatura` (`id_fatura`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_faturas_transactions`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_faturas_transactions` (
  `id_transaction` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_fatura` int(11) NOT NULL,
  `id_payment` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `return_code` char(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tid` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nsu` char(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `authorization_code` char(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_transaction` datetime DEFAULT NULL,
  PRIMARY KEY (`id_transaction`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_faturas_views`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_faturas_views` (
  `id_views` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_fatura` bigint(20) NOT NULL DEFAULT '0',
  `data_views` datetime NOT NULL,
  `usuario_views` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_views` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_views`),
  KEY `id_fatura` (`id_fatura`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_categorias`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_categorias` (
  `id_categoria` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_grupo` int(11) DEFAULT NULL,
  `id_categoria_pai` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `tipo_categoria` enum('Receita','Despesa') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Receita',
  `visivel_dre` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sim',
  `desc_categoria` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  `sync_user` int(11) DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_categoria`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_categorias_sync`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_categorias_sync` (
  `id_categoria` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  UNIQUE KEY `id_cliente_id_usuario_uniq` (`id_categoria`,`id_usuario`),
  KEY `id_cliente_id_usuario` (`id_categoria`,`id_usuario`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_centro`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_centro` (
  `id_centro_custos` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `desc_centro_custos` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_centro_custos` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Inativo',
  `data_cad_centro` datetime DEFAULT NULL,
  `data_mod_centro` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_centro_custos`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_clientes_creditos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_clientes_creditos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `id_frente` bigint(20) DEFAULT NULL,
  `id_usuario` int(11) NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `valor_saldo` decimal(10,2) NOT NULL,
  `dt_credito` datetime DEFAULT NULL,
  `dt_criacao` datetime DEFAULT NULL,
  `dt_atualizacao` datetime DEFAULT NULL,
  `situacao` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'A',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_clientes_creditos_baixa`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_clientes_creditos_baixa` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `id_frente` bigint(20) DEFAULT NULL,
  `id_credito` bigint(20) unsigned NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `dt_baixa` datetime DEFAULT NULL,
  `dt_criacao` datetime DEFAULT NULL,
  `dt_atualizacao` datetime DEFAULT NULL,
  `mensagem_baixa` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_clientes_creditos_saldos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_clientes_creditos_saldos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `valor_saldo` decimal(10,2) NOT NULL,
  `valor_total_creditos` decimal(10,2) NOT NULL,
  `valor_total_baixas` decimal(10,2) NOT NULL,
  `possui_saldo` tinyint(1) NOT NULL DEFAULT '0',
  `dt_criacao` datetime DEFAULT NULL,
  `dt_atualizacao` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_condicoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_condicoes` (
  `id_condicao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `nome_condicao` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `intervalo_pagamento` smallint(5) unsigned NOT NULL,
  `primeira_parcela_pagamento` smallint(5) unsigned NOT NULL,
  `qtde_parcelas` tinyint(1) NOT NULL,
  `juros_parcelas` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tipo_juros` tinyint(1) NOT NULL DEFAULT '2',
  `status_condicao` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Inativo',
  `forma_pagamento` char(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_condicao` datetime NOT NULL,
  `data_mod_condicao` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_condicao`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`),
  KEY `status_condicao` (`status_condicao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_contas_pag`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_contas_pag` (
  `id_conta_pag` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) unsigned NOT NULL DEFAULT '0',
  `id_registro` bigint(20) unsigned NOT NULL DEFAULT '0',
  `identificacao` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nome_conta` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_categoria` int(11) DEFAULT '0',
  `categoria_pag` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_banco` bigint(20) DEFAULT '0',
  `id_fornecedor` bigint(20) unsigned NOT NULL DEFAULT '0',
  `nome_fornecedor` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vencimento_pag` date DEFAULT NULL,
  `valor_pag` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `valor_pago` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `data_emissao` date DEFAULT NULL,
  `n_documento_pag` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes_pag` longtext COLLATE utf8mb4_unicode_ci,
  `id_centro_custos` bigint(20) unsigned DEFAULT NULL,
  `centro_custos_pag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_pagamento` date DEFAULT NULL,
  `obs_pagamento` longtext COLLATE utf8mb4_unicode_ci,
  `forma_pagamento` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_juros` decimal(10,2) DEFAULT '0.00',
  `valor_desconto` decimal(10,2) DEFAULT '0.00',
  `valor_acrescimo` decimal(10,2) DEFAULT '0.00',
  `data_cad_pag` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_pag` datetime DEFAULT NULL,
  `agrupado` tinyint(1) DEFAULT '0',
  `agrupado_data` datetime DEFAULT NULL,
  `agrupado_user` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agrupamento` tinyint(1) DEFAULT '0',
  `fluxo` tinyint(1) NOT NULL DEFAULT '0',
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  `sync_user` int(11) DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `situacao` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `id_pagamento_ob` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_barras` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `liquidado_pag` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_conta_pag`),
  KEY `ix_nfe_financeiro_contas_pag_id_empresa_categoria_pag` (`id_empresa`,`categoria_pag`),
  KEY `ix_nfe_financeiro_contas_pag_id_empresa_nome_fornecedor_lixeira` (`id_empresa`,`nome_fornecedor`,`lixeira`),
  KEY `id_fornecedor` (`id_fornecedor`),
  KEY `ix_nfe_financeiro_contas_pag_id_empresa_n_documento_pag_lixeira` (`id_empresa`,`n_documento_pag`,`lixeira`),
  KEY `lixeira` (`lixeira`),
  KEY `identificacao` (`identificacao`),
  KEY `ix_nfe_financeiro_contas_pag_id_empresa_nome_fornecedor` (`id_empresa`,`nome_fornecedor`),
  KEY `ix_nfe_financeiro_contas_pag_id_empresa_agrupado` (`id_empresa`,`agrupado`),
  KEY `ix_nfe_financeiro_contas_pag_id_empresa_nome_conta` (`id_empresa`,`nome_conta`),
  KEY `ix_nfe_financeiro_contas_pag_id_empresa_data_cad_pag` (`id_empresa`,`data_cad_pag`),
  KEY `id_empresa` (`id_empresa`),
  KEY `ix_nfe_financeiro_contas_pag_id_empresa_valor_pag` (`id_empresa`,`valor_pag`),
  KEY `idx_id_pagamento_ob` (`id_pagamento_ob`),
  KEY `ix_nfe_financeiro_contas_pag_id_empresa_forma_pagamento` (`id_empresa`,`forma_pagamento`),
  KEY `fluxo` (`fluxo`),
  KEY `ix_nfe_financeiro_contas_pag_id_empresa_id_banco` (`id_empresa`,`id_banco`),
  KEY `sync` (`sync`),
  KEY `ix_nfe_financeiro_contas_pag_id_empresa_lixeira` (`id_empresa`,`lixeira`),
  KEY `ix_nfe_financeiro_contas_pag_id_empresa_nome_conta_lixeira` (`id_empresa`,`nome_conta`,`lixeira`),
  KEY `ix_nfe_financeiro_contas_pag_id_empresa_vencimento_pag` (`id_empresa`,`vencimento_pag`),
  KEY `ix_nfe_financeiro_contas_pag_id_empresa_liquidado_pag` (`id_empresa`,`liquidado_pag`)
) ENGINE=InnoDB AUTO_INCREMENT=218 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;

/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `nfe_financeiro_contas_pag_agrupamentos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_contas_pag_agrupamentos` (
  `id_agrupamento` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_conta_pag` bigint(20) unsigned NOT NULL,
  `id_conta_pag_agrupada` bigint(20) unsigned NOT NULL,
  `dt_criacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dt_atualizacao` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_agrupamento`),
  KEY `nfe_financeiro_contas_pag_agrupamentos_id_conta_pag_foreign` (`id_conta_pag`),
  CONSTRAINT `nfe_financeiro_contas_pag_agrupamentos_id_conta_pag_foreign` FOREIGN KEY (`id_conta_pag`) REFERENCES `nfe_financeiro_contas_pag` (`id_conta_pag`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_contas_pag_historico`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_contas_pag_historico` (
  `id_conta_pag_historico` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_conta_pag` int(10) unsigned NOT NULL,
  `situacao` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `dt_historico` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_pagamento` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_empresa` int(10) unsigned DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `nome_conta` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_pag` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_pago` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_juros` decimal(10,2) DEFAULT '0.00',
  `valor_desconto` decimal(10,2) DEFAULT '0.00',
  `valor_acrescimo` decimal(10,2) DEFAULT '0.00',
  `dt_agendamento` datetime DEFAULT NULL,
  `codigo_barras` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_taxa` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id_conta_pag_historico`),
  UNIQUE KEY `id_conta_pag_hitorico_id_conta_pag_unique` (`id_conta_pag_historico`,`id_conta_pag`),
  KEY `nfe_financeiro_contas_pag_historico_dt_historico_index` (`dt_historico`),
  KEY `nfe_financeiro_contas_pag_historico_situacao_index` (`situacao`),
  KEY `nfe_financeiro_contas_pag_historico_status_index` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=448 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_contas_pag_recebimentos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_contas_pag_recebimentos` (
  `id_recebimento` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_conta_pag` bigint(20) NOT NULL DEFAULT '0',
  `data_pagamento` date DEFAULT NULL,
  `valor_pago` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `valor_juros` decimal(10,2) DEFAULT NULL,
  `valor_desconto` decimal(10,2) DEFAULT NULL,
  `valor_acrescimo` decimal(10,2) DEFAULT NULL,
  `forma_pagamento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `obs_pagamento` longtext COLLATE utf8mb4_unicode_ci,
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  `sync_user` int(11) DEFAULT '0',
  `id_pagamento_ob` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_banco_cad` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id_recebimento`),
  KEY `id_conta_pag` (`id_conta_pag`),
  KEY `idx_nfe_financeiro_contas_pag_recebimnetos_id_pagamento_ob` (`id_pagamento_ob`),
  KEY `sync` (`sync`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;

/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `nfe_financeiro_contas_pag_recebimentos_sync`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_contas_pag_recebimentos_sync` (
  `id_recebimento` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  UNIQUE KEY `id_pedido_id_usuario_uniq` (`id_recebimento`,`id_usuario`),
  KEY `id_cliente_id_usuario` (`id_recebimento`,`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_contas_pag_sync`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_contas_pag_sync` (
  `id_conta_pag` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  UNIQUE KEY `id_pedido_id_usuario_uniq` (`id_conta_pag`,`id_usuario`),
  KEY `id_cliente_id_usuario` (`id_conta_pag`,`id_usuario`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_contas_rec`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_contas_rec` (
  `id_conta_rec` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) unsigned NOT NULL DEFAULT '0',
  `id_registro` bigint(20) unsigned NOT NULL DEFAULT '0',
  `identificacao` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nome_conta` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_categoria` int(11) DEFAULT '0',
  `categoria_rec` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_banco` bigint(20) unsigned NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) unsigned NOT NULL DEFAULT '0',
  `id_boleto` bigint(20) unsigned NOT NULL DEFAULT '0',
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vencimento_rec` date DEFAULT NULL,
  `valor_rec` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `valor_pago` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `data_emissao` date DEFAULT NULL,
  `vencimento_original` date DEFAULT NULL,
  `n_documento_rec` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes_rec` longtext COLLATE utf8mb4_unicode_ci,
  `id_centro_custos` bigint(20) unsigned NOT NULL DEFAULT '0',
  `centro_custos_rec` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `praca_pagamento` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `liquidado_rec` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `data_pagamento` date DEFAULT NULL,
  `obs_pagamento` longtext COLLATE utf8mb4_unicode_ci,
  `forma_pagamento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_juros` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_desconto` decimal(10,2) DEFAULT NULL,
  `valor_acrescimo` decimal(10,2) DEFAULT NULL,
  `retorno_pagamento` tinyint(1) DEFAULT '0',
  `tipo_conta` char(20) COLLATE utf8mb4_unicode_ci DEFAULT 'Conta',
  `data_cad_rec` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_rec` datetime DEFAULT NULL,
  `boleto_enviado` tinyint(1) NOT NULL DEFAULT '0',
  `boleto_original` tinyint(1) NOT NULL DEFAULT '0',
  `duplicata_enviado` tinyint(1) NOT NULL DEFAULT '0',
  `remetido` tinyint(1) NOT NULL DEFAULT '0',
  `registrado` tinyint(1) NOT NULL DEFAULT '0',
  `protestar` tinyint(1) DEFAULT '0',
  `dias_protestar` tinyint(1) DEFAULT '0',
  `NossoNumero` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agrupado` tinyint(1) DEFAULT '0',
  `agrupado_data` datetime DEFAULT NULL,
  `agrupado_user` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agrupamento` tinyint(1) DEFAULT '0',
  `fluxo` tinyint(1) NOT NULL DEFAULT '0',
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  `sync_user` int(11) DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `id_pagamento_ob` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `situacao` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id_conta_rec`),
  KEY `id_cliente` (`id_cliente`),
  KEY `data_pagamento` (`data_pagamento`),
  KEY `lixeira` (`lixeira`),
  KEY `NossoNumero` (`NossoNumero`),
  KEY `identificacao` (`identificacao`),
  KEY `ix_nfe_financeiro_contas_rec_id_empresa_vencimento_rec` (`id_empresa`,`vencimento_rec`),
  KEY `ix_nfe_financeiro_contas_rec_id_empresa_id_boleto` (`id_empresa`,`id_boleto`),
  KEY `ix_nfe_financeiro_contas_rec_id_empresa_lixeira` (`id_empresa`,`lixeira`),
  KEY `id_empresa_tipo_conta_registrado` (`id_empresa`,`tipo_conta`,`registrado`),
  KEY `ix_nfe_financeiro_contas_rec_id_empresa_nome_conta` (`id_empresa`,`nome_conta`),
  KEY `ix_nfe_financeiro_contas_rec_id_empresa_liquidado_rec` (`id_empresa`,`liquidado_rec`),
  KEY `id_empresa` (`id_empresa`),
  KEY `ix_nfe_financeiro_contas_rec_id_empresa_valor_rec` (`id_empresa`,`valor_rec`),
  KEY `ix_nfe_financeiro_contas_rec_id_empresa_agrupado` (`id_empresa`,`agrupado`),
  KEY `fluxo` (`fluxo`),
  KEY `ix_nfe_financeiro_contas_rec_id_empresa_forma_pagamento` (`id_empresa`,`forma_pagamento`),
  KEY `ix_nfe_financeiro_contas_rec_id_empresa_data_cad_rec` (`id_empresa`,`data_cad_rec`),
  KEY `id_boleto` (`id_boleto`),
  KEY `ix_nfe_financeiro_contas_rec_id_empresa_nome_cliente` (`id_empresa`,`nome_cliente`),
  KEY `ix_nfe_financeiro_contas_rec_id_empresa_id_banco` (`id_empresa`,`id_banco`),
  KEY `idx_nfe_financeiro_contas_rec_id_pagamento_ob` (`id_pagamento_ob`),
  KEY `sync` (`sync`),
  KEY `ix_nfe_financeiro_contas_rec_id_empresa_n_documento_rec` (`id_empresa`,`n_documento_rec`),
  KEY `ix_nfe_financeiro_contas_rec_id_empresa_categoria_rec` (`id_empresa`,`categoria_rec`)
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;

/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `nfe_financeiro_contas_rec_agrupamentos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_contas_rec_agrupamentos` (
  `id_agrupamento` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_conta_rec_agrupada` bigint(20) unsigned NOT NULL,
  `id_conta_rec` bigint(20) unsigned NOT NULL,
  `dt_criacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dt_atualizacao` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_agrupamento`),
  KEY `nfe_financeiro_contas_rec_agrupamentos_id_conta_rec_foreign` (`id_conta_rec`),
  CONSTRAINT `nfe_financeiro_contas_rec_agrupamentos_id_conta_rec_foreign` FOREIGN KEY (`id_conta_rec`) REFERENCES `nfe_financeiro_contas_rec` (`id_conta_rec`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_contas_rec_operacoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_contas_rec_operacoes` (
  `id_operacao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_conta_rec` bigint(20) NOT NULL DEFAULT '0',
  `codigo_operacao` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_operacao` datetime NOT NULL,
  `remessa` tinyint(1) NOT NULL DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_operacao`),
  KEY `codigo_operacao` (`codigo_operacao`),
  KEY `remessa` (`remessa`),
  KEY `id_conta_rec` (`id_conta_rec`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_contas_rec_recebimentos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_contas_rec_recebimentos` (
  `id_recebimento` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_contas_rec` bigint(20) NOT NULL DEFAULT '0',
  `data_pagamento` date DEFAULT NULL,
  `valor_pago` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `valor_juros` decimal(10,2) DEFAULT NULL,
  `valor_desconto` decimal(10,2) DEFAULT NULL,
  `valor_acrescimo` decimal(10,2) DEFAULT NULL,
  `forma_pagamento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `obs_pagamento` longtext COLLATE utf8mb4_unicode_ci,
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  `sync_user` int(11) DEFAULT '0',
  `id_banco_cad` bigint(20) DEFAULT '0',
  `id_pagamento_ob` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_recebimento`),
  KEY `id_contas_rec` (`id_contas_rec`),
  KEY `idx_nfe_financeiro_contas_rec_id_pagamento_ob` (`id_pagamento_ob`),
  KEY `sync` (`sync`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_contas_rec_recebimentos_sync`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_contas_rec_recebimentos_sync` (
  `id_recebimento` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  UNIQUE KEY `id_pedido_id_usuario_uniq` (`id_recebimento`,`id_usuario`),
  KEY `id_cliente_id_usuario` (`id_recebimento`,`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_contas_rec_remessas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_contas_rec_remessas` (
  `id_remessa` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `id_banco` bigint(20) NOT NULL DEFAULT '0',
  `arquivo_remessa` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario_remessa` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_remessa` datetime NOT NULL,
  PRIMARY KEY (`id_remessa`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_banco` (`id_banco`),
  KEY `data_remessa` (`data_remessa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_contas_rec_remessas_reg`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_contas_rec_remessas_reg` (
  `id_remetido` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_remessa` int(11) NOT NULL DEFAULT '0',
  `id_contas_rec` bigint(20) NOT NULL DEFAULT '0',
  `codigo_operacao` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_remetido`),
  KEY `id_remessa` (`id_remessa`),
  KEY `id_contas_rec` (`id_contas_rec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_contas_rec_retornos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_contas_rec_retornos` (
  `id_retorno` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `id_banco` bigint(20) NOT NULL DEFAULT '0',
  `arquivo_retorno` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario_retorno` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_retorno` datetime NOT NULL,
  PRIMARY KEY (`id_retorno`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_banco` (`id_banco`),
  KEY `data_retorno` (`data_retorno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_contas_rec_retornos_reg`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_contas_rec_retornos_reg` (
  `id_retornado` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_retorno` int(11) NOT NULL,
  `id_contas_rec` bigint(20) NOT NULL DEFAULT '0',
  `codigo_operacao` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_operacao_motivo` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NossoNumero` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `DataOcorrencia` date NOT NULL,
  `Pagamento` char(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `DataCredito` date NOT NULL,
  `ValorPago` decimal(10,2) unsigned NOT NULL,
  `ValorJurosPago` decimal(10,2) unsigned NOT NULL,
  `ValorMultaPaga` decimal(10,2) unsigned NOT NULL,
  `ValorTaxaCobranca` decimal(10,2) unsigned NOT NULL,
  `ValorDesconto` decimal(10,2) NOT NULL,
  `valorAbatimento` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ValorOutrosAcrescimos` decimal(10,2) unsigned NOT NULL,
  `NumeroDocumento` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `NumeroControle` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Banco` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Carteira` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Agencia` char(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ContaCorrente` char(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `CodigoCedente` char(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `MotivosOcorrencia` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_retornado`),
  KEY `id_retorno` (`id_retorno`),
  KEY `codigo_operacao` (`codigo_operacao`),
  KEY `id_contas_rec` (`id_contas_rec`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;

--
-- Table structure for table `nfe_financeiro_contas_rec_sync`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_contas_rec_sync` (
  `id_conta_rec` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  UNIQUE KEY `id_pedido_id_usuario_uniq` (`id_conta_rec`,`id_usuario`),
  KEY `id_cliente_id_usuario` (`id_conta_rec`,`id_usuario`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_custos_fixos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_custos_fixos` (
  `id_custo` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) unsigned NOT NULL DEFAULT '0',
  `nome_conta` char(45) NOT NULL,
  `id_categoria` int(9) DEFAULT '0',
  `categoria_custo` char(50) DEFAULT NULL,
  `id_banco` bigint(20) DEFAULT '0',
  `id_fornecedor` bigint(20) unsigned NOT NULL DEFAULT '0',
  `nome_fornecedor` varchar(255) NOT NULL,
  `vencimento_custo` tinyint(2) NOT NULL DEFAULT '1',
  `valor_custo` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `observacoes_custo` longtext,
  `id_centro_custos` bigint(20) unsigned NOT NULL,
  `centro_custos` varchar(255) DEFAULT NULL,
  `status_custo` enum('Ativo','Inativo') NOT NULL DEFAULT 'Inativo',
  `forma_pagamento` varchar(60) DEFAULT NULL,
  `periodicidade` tinyint(1) NOT NULL DEFAULT '3' COMMENT '1 = Semanal, 2 = quinzenal, 3 = Mensal, 4 = Bimestral, 5 = Trimestral, 6 = Semestral, 7 = Anual, 8 = Outras',
  `dia_semana_ocorrencia` tinyint(1) DEFAULT NULL,
  `dia_mes_ocorrencia` tinyint(2) DEFAULT NULL,
  `intervalo_dias_ocorrencia` tinyint(2) DEFAULT NULL,
  `data_inicio_ocorrencia` date NOT NULL,
  `data_fim_ocorrencia` date DEFAULT NULL,
  `data_cad_custo` datetime NOT NULL,
  `data_mod_custo` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_custo`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_fornecedor` (`id_fornecedor`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_favorecidos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_favorecidos` (
  `id_favorecido` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL,
  `nome` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_favorecido` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'J',
  `cnpj_cpf` varchar(14) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_banco` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agencia_banco` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agencia_dv_banco` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conta_banco` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conta_dv_banco` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_fornecedor` int(11) DEFAULT NULL,
  `id_usuario` int(11) NOT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `lixeira` tinyint(1) NOT NULL DEFAULT '0',
  `dt_criacao` datetime DEFAULT NULL,
  `dt_atualizacao` datetime DEFAULT NULL,
  PRIMARY KEY (`id_favorecido`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_fluxo`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_fluxo` (
  `id_fluxo` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_banco` bigint(20) DEFAULT '0',
  `id_conta` bigint(20) DEFAULT '0',
  `id_recebimento` int(11) DEFAULT '0',
  `nome_conta` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_cliente` bigint(20) DEFAULT '0',
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_fluxo` date DEFAULT NULL,
  `valor_fluxo` decimal(10,2) DEFAULT NULL,
  `observacoes_fluxo` longtext COLLATE utf8mb4_unicode_ci,
  `id_centro_custos` bigint(20) DEFAULT '0',
  `centro_custos_fluxo` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_categoria` int(11) DEFAULT '0',
  `categoria_fluxo` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `forma_pagamento` char(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_fluxo` enum('Saida','Entrada') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Entrada',
  `data_cad_fluxo` datetime DEFAULT NULL,
  `data_mod_fluxo` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `lixeira_location` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_transferencia` bigint(20) unsigned DEFAULT '0',
  PRIMARY KEY (`id_fluxo`),
  KEY `id_conta` (`id_conta`),
  KEY `tipo_fluxo` (`tipo_fluxo`),
  KEY `ix_nfe_financeiro_fluxo_id_empresa_tipo_fluxo_data_fluxo` (`id_empresa`,`tipo_fluxo`,`data_fluxo`),
  KEY `ix_nfe_financeiro_fluxo_id_empresa_nome_conta` (`id_empresa`,`nome_conta`),
  KEY `ix_nfe_financeiro_fluxo_id_empresa_id_banco_lixeira_data_fluxo` (`id_empresa`,`id_banco`,`lixeira`,`data_fluxo`),
  KEY `ix_nfe_financeiro_fluxo_id_empresa_tipo_fluxo` (`id_empresa`,`tipo_fluxo`),
  KEY `ix_nfe_financeiro_fluxo_id_empresa_nome_cliente` (`id_empresa`,`nome_cliente`),
  KEY `ix_nfe_financeiro_fluxo_id_empresa_data_fluxo` (`id_empresa`,`data_fluxo`),
  KEY `ix_nfe_financeiro_fluxo_id_empresa_centro_custos_fluxo` (`id_empresa`,`centro_custos_fluxo`),
  KEY `id_empresa` (`id_empresa`),
  KEY `ix_nfe_financeiro_fluxo_id_empresa_lixeira` (`id_empresa`,`lixeira`),
  KEY `ix_nfe_financeiro_fluxo_id_empresa_forma_pagamento` (`id_empresa`,`forma_pagamento`),
  KEY `lixeira` (`lixeira`),
  KEY `ix_nfe_financeiro_fluxo_id_empresa_valor_fluxo` (`id_empresa`,`valor_fluxo`),
  KEY `ix_nfe_financeiro_fluxo_id_empresa_categoria_fluxo` (`id_empresa`,`categoria_fluxo`),
  KEY `id_banco` (`id_banco`),
  KEY `ix_nfe_financeiro_fluxo_id_empresa_id_banco` (`id_empresa`,`id_banco`),
  KEY `idx_nfe_fin_fluxo_emp_cta` (`id_empresa`,`id_conta`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_grupos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_grupos` (
  `id_grupo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `desc_grupo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_grupo` enum('Receita','Despesa') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Receita',
  `ordem` tinyint(1) DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_grupo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_grupos_categorias`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_grupos_categorias` (
  `id_grupos_categorias` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `id_grupo` int(11) DEFAULT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_grupos_categorias`),
  UNIQUE KEY `unique` (`id_empresa`,`id_grupo`,`id_categoria`),
  KEY `id_grupo` (`id_grupo`),
  KEY `id_categoria` (`id_categoria`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_ofx`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_ofx` (
  `id_ofx` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_usuario` bigint(20) DEFAULT '0',
  `data_cad_ofx` datetime DEFAULT NULL,
  `pasta` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tamanho` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_ofx`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_ofx_extrato`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_ofx_extrato` (
  `id_extrato` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `id_ofx` int(11) NOT NULL DEFAULT '0',
  `nome_banco` char(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_extrato` date NOT NULL,
  `desc_extrato` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_extrato` char(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_extrato` decimal(10,2) NOT NULL DEFAULT '0.00',
  `check_extrato` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conciliado` bigint(20) NOT NULL DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `fitid` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `id_transacao_ob` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_transacao_ob` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_extrato`),
  UNIQUE KEY `importacao` (`id_empresa`,`data_extrato`,`tipo_extrato`,`valor_extrato`,`check_extrato`,`lixeira`,`desc_extrato`,`fitid`),
  KEY `id_ofx` (`id_ofx`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_transferencias`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_transferencias` (
  `id_transferencia` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL,
  `valor_pagar` decimal(10,2) NOT NULL,
  `id_banco_cad_origem` int(11) NOT NULL,
  `codigo_banco_origem` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_conta_origem` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_agencia_origem` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_banco_cad_destino` int(11) DEFAULT NULL,
  `codigo_banco_destino` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_conta_destino` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_agencia_destino` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_favorecido` bigint(20) DEFAULT NULL,
  `nome_favorecido` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_documento_favorecido` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'J',
  `numero_documento_favorecido` varchar(14) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_fornecedor` int(11) DEFAULT NULL,
  `dt_transferencia` datetime NOT NULL,
  `situacao` tinyint(1) DEFAULT NULL,
  `id_conta_pag` bigint(20) DEFAULT NULL,
  `id_recebimento` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_transferencia_ob` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `tp_transferencia` char(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'I',
  `obs_transferencia` longtext COLLATE utf8mb4_unicode_ci,
  `dt_criacao` datetime DEFAULT NULL,
  `dt_atualizacao` datetime DEFAULT NULL,
  `valor_taxa` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id_transferencia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_financeiro_transferencias_historico`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_financeiro_transferencias_historico` (
  `id_transferencia_historico` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL,
  `valor_juros` decimal(10,2) NOT NULL,
  `valor_desconto` decimal(10,2) NOT NULL,
  `valor_acrecimo` decimal(10,2) NOT NULL,
  `valor_pagar` decimal(10,2) NOT NULL,
  `valor_pago` decimal(10,2) DEFAULT NULL,
  `id_banco_cad_origem` int(11) NOT NULL,
  `codigo_banco_origem` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_conta_origem` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_agencia_origem` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_banco_cad_destino` int(11) DEFAULT NULL,
  `codigo_banco_destino` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_conta_destino` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_agencia_destino` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_favorecido` bigint(20) DEFAULT NULL,
  `nome_favorecido` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_documento_favorecido` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'J',
  `numero_documento_favorecido` varchar(14) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_fornecedor` int(11) DEFAULT NULL,
  `dt_transferencia` datetime NOT NULL,
  `dt_historico` datetime NOT NULL,
  `situacao` tinyint(1) DEFAULT NULL,
  `id_conta_pag` bigint(20) DEFAULT NULL,
  `id_recebimento` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_transferencia_ob` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `tp_transferencia` char(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'I',
  `obs_transferencia` longtext COLLATE utf8mb4_unicode_ci,
  `dt_criacao` datetime DEFAULT NULL,
  `dt_atualizacao` datetime DEFAULT NULL,
  `valor_taxa` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id_transferencia_historico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_formas_pagamento`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_formas_pagamento` (
  `id_forma` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `desc_forma` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frente_caixa` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id_forma`),
  KEY `frente_caixa` (`frente_caixa`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_frente_caixa`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_frente_caixa` (
  `id_frente` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `id_pedido` bigint(20) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) NOT NULL DEFAULT '0',
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendedor_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendedor_pedido_id` bigint(20) DEFAULT NULL,
  `valor_total_produtos` decimal(10,2) NOT NULL DEFAULT '0.00',
  `desconto_pedido` decimal(10,2) DEFAULT '0.00',
  `acrescimo_pedido` decimal(10,2) DEFAULT '0.00',
  `valor_total_nota` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tipo_pagamento` tinyint(1) NOT NULL DEFAULT '0',
  `forma_pagamento` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `doc_pagamento` longtext COLLATE utf8mb4_unicode_ci,
  `valor_recebido` decimal(10,2) DEFAULT '0.00',
  `troco_pedido` decimal(10,2) DEFAULT '0.00',
  `condicao_pagamento` tinyint(1) DEFAULT '0',
  `id_banco` int(11) DEFAULT '0',
  `obs_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_pedido` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Em Aberto',
  `contas_pedido` tinyint(1) NOT NULL DEFAULT '0',
  `estoque_pedido` tinyint(1) NOT NULL DEFAULT '0',
  `pedido_emitido` tinyint(1) NOT NULL DEFAULT '0',
  `nfce_emitido` int(11) NOT NULL DEFAULT '0',
  `agrupado` tinyint(1) DEFAULT '0',
  `agrupado_data` datetime DEFAULT NULL,
  `agrupado_user` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agrupamento` tinyint(1) DEFAULT '0',
  `versao_pdv` int(11) DEFAULT '1',
  `data_cad_pedido` datetime NOT NULL,
  `data_mod_pedido` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_frente`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`),
  KEY `ix_nfe_frente_caixa_id_empresa_obs_pedido` (`id_empresa`,`obs_pedido`),
  KEY `ix_nfe_frente_caixa_id_empresa_data_cad_pedido` (`id_empresa`,`data_cad_pedido`),
  KEY `ix_nfe_frente_caixa_id_empresa_valor_total_nota` (`id_empresa`,`valor_total_nota`),
  KEY `ix_nfe_frente_caixa_id_empresa_id_pedido` (`id_empresa`,`id_pedido`),
  KEY `status_pedido` (`status_pedido`),
  KEY `ix_nfe_frente_caixa_id_empresa_nome_cliente` (`id_empresa`,`nome_cliente`),
  KEY `ix_nfe_frente_caixa_id_empresa_vendedor_pedido` (`id_empresa`,`vendedor_pedido`),
  KEY `ix_nfe_frente_caixa_id_empresa_lixeira` (`id_empresa`,`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_frente_caixa_historico`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_frente_caixa_historico` (
  `id_historico` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_frente` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `session_id` char(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `data_abertura` datetime NOT NULL,
  `data_expiracao` datetime NOT NULL,
  PRIMARY KEY (`id_historico`),
  KEY `id_frente` (`id_frente`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_frente_caixa_observacoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_frente_caixa_observacoes` (
  `id_param` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `observacao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_param`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_frente_caixa_parcelas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_frente_caixa_parcelas` (
  `id_parcela` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_frente` bigint(20) DEFAULT '0',
  `data_parcela` date DEFAULT NULL,
  `valor_parcela` decimal(10,2) DEFAULT '0.00',
  `forma_pagamento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes_parcela` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_banco` int(11) DEFAULT '0',
  `id_conta_rec` int(11) DEFAULT '0',
  PRIMARY KEY (`id_parcela`),
  KEY `id_pedido` (`id_frente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_frente_caixa_parcelas_evo`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_frente_caixa_parcelas_evo` (
  `id_frente_caixa_parcelas_evo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_conta_rec` int(11) DEFAULT '0',
  `id_frente_caixa_parcela` int(11) DEFAULT '0',
  `id_transaction` int(11) DEFAULT '0',
  PRIMARY KEY (`id_frente_caixa_parcelas_evo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_frente_caixa_pdv`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_frente_caixa_pdv` (
  `id_pdv` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `nome` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_min` decimal(10,3) DEFAULT NULL,
  `valor_max` decimal(10,3) DEFAULT NULL,
  `data_cadastro` datetime DEFAULT NULL,
  `data_atualizacao` datetime DEFAULT NULL,
  `data_lixeira` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  `valor_min_per` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `valor_max_per` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `status` enum('Aberto','Fechado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Fechado',
  `pdv_pos_stone` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_pdv`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_frente_caixa_pdv_movimentacao`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_frente_caixa_pdv_movimentacao` (
  `id_movimentacao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_pdv` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_usuario_autorizacao` int(11) DEFAULT NULL,
  `id_frente` int(11) DEFAULT NULL,
  `id_pedido` int(11) DEFAULT NULL,
  `id_parcela` int(11) DEFAULT NULL,
  `lancado` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `tipo` enum('Entrada','Saida') COLLATE utf8mb4_unicode_ci NOT NULL,
  `acao` enum('Venda','Aberto','Fechado','Sangria','Reforco','Troca') COLLATE utf8mb4_unicode_ci NOT NULL,
  `moeda` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor` decimal(10,3) DEFAULT NULL,
  `obs_caixa` mediumtext COLLATE utf8mb4_unicode_ci,
  `data_operacao` datetime DEFAULT NULL,
  PRIMARY KEY (`id_movimentacao`),
  KEY `id_pedido` (`id_pedido`),
  KEY `lancado_comissao` (`lancado`),
  KEY `id_empresa` (`id_empresa`),
  KEY `valor` (`valor`),
  KEY `tipo` (`tipo`),
  KEY `id_frente` (`id_frente`),
  KEY `acao` (`acao`),
  KEY `id_parcela` (`id_parcela`),
  KEY `id_caixa` (`id_pdv`),
  KEY `id_usuario` (`id_usuario`),
  KEY `moeda` (`moeda`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_frente_caixa_pdv_permissao_usuario`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_frente_caixa_pdv_permissao_usuario` (
  `id_permissao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `abrir` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `fechar` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `sangria` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `reforco` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `troca` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_permissao`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_pdv` (`id_empresa`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_frente_caixa_pdv_troca_mercadorias`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_frente_caixa_pdv_troca_mercadorias` (
  `id_troca` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned DEFAULT NULL,
  `id_usuario` int(10) unsigned DEFAULT NULL,
  `id_frente` bigint(20) unsigned DEFAULT NULL,
  `id_cliente` int(10) unsigned DEFAULT NULL,
  `razao_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_troca` date DEFAULT NULL,
  `forma_pagamento` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_total_produtos_antes` decimal(10,4) unsigned DEFAULT NULL,
  `valor_total_produtos_depois` decimal(10,4) unsigned DEFAULT NULL,
  `valor_desconto` decimal(10,4) unsigned DEFAULT NULL,
  `valor_acrescimo` decimal(10,4) unsigned DEFAULT NULL,
  `credito_loja` decimal(10,4) unsigned DEFAULT NULL,
  `devolucao_dinheiro` decimal(10,4) unsigned DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Sim',
  `data_cad_troca` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_troca` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_troca`),
  KEY `id_frente` (`id_frente`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_frente_caixa_pdv_troca_mercadorias_parcelas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_frente_caixa_pdv_troca_mercadorias_parcelas` (
  `id_parcela` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_troca` int(11) DEFAULT NULL,
  `data_vencimento` datetime NOT NULL,
  `valor_parcela` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `forma_pagamento` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_banco` int(11) DEFAULT NULL,
  `id_conta_rec` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_parcela`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_frente_caixa_pdv_troca_mercadorias_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_frente_caixa_pdv_troca_mercadorias_produtos` (
  `id_troca_produto` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_troca` int(10) unsigned DEFAULT NULL,
  `id_produto` bigint(20) DEFAULT NULL,
  `cod_produto` char(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desc_produto` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_unit_produto` decimal(10,4) DEFAULT NULL,
  `valor_total_produto_antes` decimal(10,4) DEFAULT NULL,
  `valor_total_produto_depois` decimal(10,4) DEFAULT NULL,
  `qtde_produto_antes` decimal(10,4) unsigned DEFAULT NULL,
  `qtde_produto_depois` double(10,4) DEFAULT NULL,
  `diferenca` double(10,4) DEFAULT NULL,
  `tipo_movimentacao` enum('Entrada','Saida') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_troca_produto`),
  KEY `id_historico` (`id_troca`),
  KEY `id_produto` (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_frente_caixa_pdv_usuario`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_frente_caixa_pdv_usuario` (
  `id_vinculo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_pdv` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_vinculo`),
  KEY `id_pdv` (`id_pdv`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_frente_caixa_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_frente_caixa_produtos` (
  `id_ped_produto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `id_frente` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `cod_produto` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desc_produto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qtde_produto` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `valor_unit_produto` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `valor_custo_produto` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `valor_total_produto` decimal(15,2) NOT NULL DEFAULT '0.00',
  `seq` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_ped_produto`),
  KEY `id_frente` (`id_frente`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_produto` (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_frente_caixa_produtos_historico_vendas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_frente_caixa_produtos_historico_vendas` (
  `id_hist_produto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `id_pedido` bigint(20) NOT NULL DEFAULT '0',
  `id_frente` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `cod_produto` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qtde_produto` decimal(10,3) NOT NULL DEFAULT '0.000',
  `valor_unit_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `valor_total_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `desc_produto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `forma_pagamento` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_compra` datetime DEFAULT NULL,
  `vendedor_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_desconto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_acrescimo` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_pago` decimal(10,2) NOT NULL DEFAULT '0.00',
  `status_pedido` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Em Aberto',
  `data_cad_pedido` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_pedido` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_hist_produto`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_produto` (`id_produto`),
  KEY `id_frente` (`id_frente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_frente_caixa_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_frente_caixa_status` (
  `id_status` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_frente` bigint(20) DEFAULT '0',
  `data_status` date DEFAULT NULL,
  `obs_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_status` char(15) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Em Aberto',
  PRIMARY KEY (`id_status`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_empresa_id_frente` (`id_empresa`,`id_frente`),
  KEY `id_frente` (`id_frente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_icms`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_icms` (
  `UF` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `AC` decimal(10,2) NOT NULL DEFAULT '0.00',
  `AL` decimal(10,2) NOT NULL DEFAULT '0.00',
  `AM` decimal(10,2) NOT NULL DEFAULT '0.00',
  `AP` decimal(10,2) NOT NULL DEFAULT '0.00',
  `BA` decimal(10,2) NOT NULL DEFAULT '0.00',
  `CE` decimal(10,2) NOT NULL DEFAULT '0.00',
  `DF` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ES` decimal(10,2) NOT NULL DEFAULT '0.00',
  `GO` decimal(10,2) NOT NULL DEFAULT '0.00',
  `MA` decimal(10,2) NOT NULL DEFAULT '0.00',
  `MT` decimal(10,2) NOT NULL DEFAULT '0.00',
  `MS` decimal(10,2) NOT NULL DEFAULT '0.00',
  `MG` decimal(10,2) NOT NULL DEFAULT '0.00',
  `PA` decimal(10,2) NOT NULL DEFAULT '0.00',
  `PB` decimal(10,2) NOT NULL DEFAULT '0.00',
  `PR` decimal(10,2) NOT NULL DEFAULT '0.00',
  `PE` decimal(10,2) NOT NULL DEFAULT '0.00',
  `PI` decimal(10,2) NOT NULL DEFAULT '0.00',
  `RN` decimal(10,2) NOT NULL DEFAULT '0.00',
  `RS` decimal(10,2) NOT NULL DEFAULT '0.00',
  `RJ` decimal(10,2) NOT NULL DEFAULT '0.00',
  `RO` decimal(10,2) NOT NULL DEFAULT '0.00',
  `RR` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SC` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SP` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SE` decimal(10,2) NOT NULL DEFAULT '0.00',
  `TO` decimal(10,2) NOT NULL DEFAULT '0.00',
  `EX` decimal(10,2) NOT NULL DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_indicacoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_indicacoes` (
  `id_indicacao` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `id_parceiro` bigint(20) NOT NULL DEFAULT '0',
  `id_contabilidade` bigint(20) NOT NULL DEFAULT '0',
  `login_usuario` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_indicacao` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emails_indicacao` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone_indicacao` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_indicacao` datetime NOT NULL,
  PRIMARY KEY (`id_indicacao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_intro_cnpj_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_intro_cnpj_log` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `dados_retorno` text COLLATE utf8mb4_unicode_ci,
  `data_cad_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_inutilizacao`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_inutilizacao` (
  `id_inut` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `tipo_inut` enum('NFe','NFCe') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NFe',
  `ano_inut` tinyint(1) NOT NULL DEFAULT '0',
  `serie_inut` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `inicial_inut` int(11) NOT NULL DEFAULT '0',
  `final_inut` int(11) NOT NULL DEFAULT '0',
  `motivo_inut` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `protocolo_inut` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chave_inut` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_inut` datetime NOT NULL,
  PRIMARY KEY (`id_inut`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_log_consulta_cnpj_soa`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_log_consulta_cnpj_soa` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cnpj` varchar(22) COLLATE utf8mb4_unicode_ci NOT NULL,
  `erro_consulta_stone` longtext COLLATE utf8mb4_unicode_ci,
  `data_cad_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `erro_consulta_soa` longtext COLLATE utf8mb4_unicode_ci,
  `erro_stone` tinyint(1) DEFAULT '1',
  `erro_soa` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_log_emissao`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_log_emissao` (
  `id_emissao_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned DEFAULT NULL,
  `id_usuario` int(10) unsigned DEFAULT NULL,
  `id_pedido` int(10) unsigned DEFAULT NULL,
  `codigo_rejeicao` char(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chave` char(44) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_hora_rejeicao` datetime DEFAULT NULL,
  `link_xml` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uf` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_evento` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_nota` enum('NFe','NFCe','NFSe','CTe','MDFe') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NFe',
  `origem` enum('A1','A3') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'A1',
  `fonte_erro` enum('XSD','SEFAZ','Exception','API') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'SEFAZ',
  `observacoes` text COLLATE utf8mb4_unicode_ci,
  `causa_erro_a3` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_emissao_log` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_emissao_log`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_log_entrada_mercadoria`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_log_entrada_mercadoria` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) DEFAULT '0',
  `url` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `metodo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `xml_envio` longtext COLLATE utf8mb4_unicode_ci,
  `xml_retorno` longtext COLLATE utf8mb4_unicode_ci,
  `data_cad_log_entrada` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_logins`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_logins` (
  `id_login` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `login_usuario` char(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `senha_usuario` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip` char(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `session_id` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `servidor` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `navegador` char(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_login` datetime DEFAULT NULL,
  PRIMARY KEY (`id_login`),
  KEY `data_login` (`data_login`),
  KEY `login_usuario` (`login_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_logins_block`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_logins_block` (
  `id_block` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ip_block` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hostname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_block` datetime DEFAULT NULL,
  PRIMARY KEY (`id_block`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_logins_online`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_logins_online` (
  `id_acesso` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `ip_user` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `navegador` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tempo` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_acesso`),
  KEY `tempo` (`tempo`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_logins_teste`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_logins_teste` (
  `id_login` bigint(20) NOT NULL DEFAULT '0',
  `login_usuario` char(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `senha_usuario` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip` char(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `session_id` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `servidor` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `navegador` char(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_login` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_mdfe`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_mdfe` (
  `id_mdfe` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned DEFAULT '0',
  `ambiente` tinyint(3) unsigned DEFAULT '2',
  `tipo_emitente` tinyint(3) unsigned DEFAULT '1',
  `tipo_transportador` tinyint(3) unsigned DEFAULT '1',
  `serie_mdfe` tinyint(3) unsigned DEFAULT '1',
  `data_hora_emissao` datetime NOT NULL,
  `id_pedido` int(10) unsigned DEFAULT '0',
  `uf_carregamento` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uf_descarregamento` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantidade_total_cte` int(11) NOT NULL DEFAULT '0',
  `quantidade_total_nfe` int(11) NOT NULL DEFAULT '0',
  `valor_total_carga_transportada` decimal(13,2) NOT NULL DEFAULT '0.00',
  `peso_bruto_total_carga_transportada` decimal(11,4) NOT NULL DEFAULT '0.0000',
  `unidade` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `condicao_pagamento` tinyint(1) NOT NULL,
  `condicao_pagamento_id` int(11) NOT NULL DEFAULT '0',
  `rntrc` char(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cod_agendamento_porto` char(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_carroceria` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_rodado_veiculo_tracao` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `placa_veiculo_tracao` char(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uf_veiculo_tracao` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tara_veiculo_tracao` char(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `outro_proprietario` tinyint(1) DEFAULT '0',
  `razao_social_proprietario` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cpf_cnpj_proprietario` varchar(18) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ie_proprietario` varchar(18) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ie_isento_proprietario` tinyint(1) NOT NULL DEFAULT '0',
  `rntrc_proprietario` char(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uf_proprietario` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_proprietario` tinyint(1) NOT NULL,
  `observacoes` text COLLATE utf8mb4_unicode_ci,
  `status_mdfe` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Em Aberto',
  `mdfe_chave` char(44) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mdfe_recibo` char(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mdfe_protocolo` char(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mdfe_emitido` tinyint(3) unsigned DEFAULT '0',
  `mdfe_denegada` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mdfe_usuario_autorizacao` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mdfe_data_autorizacao` datetime DEFAULT NULL,
  `mdfe_usuario_cancelamento` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mdfe_data_cancelamento` datetime DEFAULT NULL,
  `mdfe_motivo_cancelamento` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `municipio_encerramento` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cod_municipio_encerramento` int(11) DEFAULT NULL,
  `uf_encerramento` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_encerramento` date DEFAULT NULL,
  `mdfe_protocolo_encerramento` char(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_hora_encerramento` datetime DEFAULT NULL,
  `mdfe_usuario_encerramento` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contas_mdfe` tinyint(3) unsigned DEFAULT '0',
  `nota_scan` int(10) unsigned DEFAULT NULL,
  `nota_importada` tinyint(3) unsigned DEFAULT '0',
  `nota_confirmada` tinyint(3) unsigned DEFAULT '0',
  `data_cad_mdfe` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_mdfe` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_usuario_cad` int(10) unsigned DEFAULT '0',
  `id_usuario_mod` int(10) unsigned DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_mdfe`),
  KEY `placa_veiculo_tracao` (`placa_veiculo_tracao`),
  KEY `idx_id_empresa_lixeira_status_mdfe` (`id_empresa`,`lixeira`,`status_mdfe`),
  KEY `idx_id_mdfe_id_empresa_lixeira` (`id_mdfe`,`id_empresa`,`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_mdfe_ciot`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_mdfe_ciot` (
  `id_ciot` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned DEFAULT NULL,
  `id_mdfe` int(10) unsigned DEFAULT NULL,
  `ciot` char(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cpf_cnpj_ciot` char(18) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_ciot` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_ciot`),
  KEY `idx_id_mdfe_id_empresa` (`id_mdfe`,`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_mdfe_condutores`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_mdfe_condutores` (
  `id_contratante` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned DEFAULT NULL,
  `id_mdfe` int(10) unsigned DEFAULT NULL,
  `nome_condutor` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cpf_condutor` varchar(14) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_condutor` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_contratante`),
  KEY `idx_id_mdfe_id_empresa` (`id_mdfe`,`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_mdfe_contratantes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_mdfe_contratantes` (
  `id_contratante` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned DEFAULT NULL,
  `id_mdfe` int(10) unsigned DEFAULT NULL,
  `nome_contratante` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cpf_cnpj_contratante` char(18) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identificador_contratante` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_contratante` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_contratante`),
  KEY `idx_id_mdfe_id_empresa` (`id_mdfe`,`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_mdfe_documentos_cte`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_mdfe_documentos_cte` (
  `id_documento_cte` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned NOT NULL DEFAULT '0',
  `id_mdfe` int(10) unsigned NOT NULL DEFAULT '0',
  `id_municipio_descarregamento` int(10) unsigned NOT NULL DEFAULT '0',
  `chave_acesso_cte` varchar(44) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `segundo_codigo_barras_cte` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_chave__acesso_cte` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_documento_cte`),
  KEY `idx_id_empresa_id_mdfe_id_municipio_descarregamento` (`id_empresa`,`id_mdfe`,`id_municipio_descarregamento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_mdfe_documentos_nfe`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_mdfe_documentos_nfe` (
  `id_documento_nfe` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned NOT NULL DEFAULT '0',
  `id_mdfe` int(10) unsigned NOT NULL DEFAULT '0',
  `id_municipio_descarregamento` int(10) unsigned NOT NULL DEFAULT '0',
  `chave_acesso_nfe` varchar(44) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `segundo_codigo_barras_nfe` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_chave__acesso_nfe` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_documento_nfe`),
  KEY `idx_id_empresa_id_mdfe_id_municipio_descarregamento` (`id_empresa`,`id_mdfe`,`id_municipio_descarregamento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_mdfe_informacao_pagamento`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_mdfe_informacao_pagamento` (
  `id_informacao_pagamento` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_mdfe` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `informado` smallint(6) DEFAULT '0',
  `responsavel` varchar(155) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cpf_cnpj` varchar(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `identificador_estrangeiro` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_total` decimal(10,2) DEFAULT NULL,
  `forma_pagamento` smallint(6) DEFAULT NULL,
  `numero_banco` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agencia_banco` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnpj_banco` varchar(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_informacao_pagamento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_mdfe_informacao_pagamento_componentes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_mdfe_informacao_pagamento_componentes` (
  `id_componente` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_informacao_pagamento` int(11) NOT NULL,
  `tipo` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor` decimal(13,2) DEFAULT NULL,
  `descricao` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_componente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_mdfe_informacao_pagamento_parcelas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_mdfe_informacao_pagamento_parcelas` (
  `id_parcela` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_informacao_pagamento` int(11) NOT NULL,
  `data` date DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT NULL,
  `observacao` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_parcela`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_mdfe_municipios_carregamento`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_mdfe_municipios_carregamento` (
  `id_municipio_carregamento` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_mdfe` int(11) NOT NULL DEFAULT '0',
  `cod_municipio_carregamento` int(11) NOT NULL DEFAULT '0',
  `municipio_carregamento` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_municipio` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_municipio_carregamento`),
  KEY `idx_id_mdfe_id_empresa` (`id_mdfe`,`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_mdfe_municipios_descarregamento`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_mdfe_municipios_descarregamento` (
  `id_municipio_descarregamento` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_mdfe` int(11) NOT NULL DEFAULT '0',
  `cod_municipio_descarregamento` int(11) NOT NULL DEFAULT '0',
  `municipio_descarregamento` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_municipio` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_municipio_descarregamento`),
  KEY `idx_id_mdfe_id_empresa` (`id_mdfe`,`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_mdfe_pagamento_operacao_transporte`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_mdfe_pagamento_operacao_transporte` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_mdfe` int(11) DEFAULT NULL,
  `chave_mdfe` varchar(65) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `protocolo` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_viagens` int(11) DEFAULT NULL,
  `referencia_viagem` int(11) DEFAULT NULL,
  `data_evento` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_mdfe_parcelas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_mdfe_parcelas` (
  `id_parcela` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_mdfe` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `data_parcela` date NOT NULL,
  `valor_parcela` decimal(16,6) NOT NULL,
  `forma_pagamento` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `observacoes_parcela` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_parcela` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_parcela`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_mdfe_produto_predominante`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_mdfe_produto_predominante` (
  `id_produto_predominante` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_mdfe` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `desc_produto` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_barra_produto` varchar(14) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ncm_produto` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_carga` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `info_carga_lotacao` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep_carregamento` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude_carregamento` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `longitude_carregamento` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep_descarregamento` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude_descarregamento` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `longitude_descarregamento` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_produto_predominante`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_mdfe_reboque`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_mdfe_reboque` (
  `id_reboque` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned NOT NULL DEFAULT '0',
  `id_mdfe` int(10) unsigned NOT NULL DEFAULT '0',
  `placa_reboque` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_carroceria_reboque` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uf_veiculo_reboque` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `capacidade_reboque` char(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tara_reboque` char(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `proprietario_reboque` tinyint(1) NOT NULL DEFAULT '1',
  `razao_social_proprietario_reboque` char(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cpf_cnpj_proprietario_reboque` char(18) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ie_proprietario_reboque` char(18) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ie_isento_proprietario_reboque` tinyint(1) NOT NULL DEFAULT '0',
  `rntrc_proprietario_reboque` char(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uf_proprietario_reboque` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_proprietario_reboque` tinyint(1) NOT NULL,
  `data_cad_reboque` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_reboque`),
  KEY `idx_id_mdfe_id_empresa` (`id_mdfe`,`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_mdfe_seguros`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_mdfe_seguros` (
  `id_seguro` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned DEFAULT NULL,
  `id_mdfe` int(10) unsigned DEFAULT NULL,
  `responsavel_seguro` tinyint(1) NOT NULL,
  `cpf_cnpj_responsavel_seguro` char(18) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_seguradora` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cnpj_seguradora` char(18) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numero_apolice` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numero_averbacao` char(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_seguro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_seguro`),
  KEY `idx_id_mdfe_id_empresa` (`id_mdfe`,`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_mdfe_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_mdfe_status` (
  `id_status` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `id_mdfe` int(11) DEFAULT NULL,
  `data_status` date DEFAULT NULL,
  `obs_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_status` char(15) COLLATE utf8mb4_unicode_ci DEFAULT 'Em Aberto',
  `id_usuario_cad_status` int(11) DEFAULT NULL,
  `data_cad_status` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_status`),
  KEY `idx_id_empresa_id_mdfe` (`id_empresa`,`id_mdfe`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_mdfe_uf_percurso`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_mdfe_uf_percurso` (
  `id_percurso` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned DEFAULT NULL,
  `id_mdfe` int(10) unsigned DEFAULT NULL,
  `uf` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_percurso` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_percurso`),
  KEY `idx_id_empresa_id_mdfe` (`id_empresa`,`id_mdfe`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_mdfe_vale_pedagio`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_mdfe_vale_pedagio` (
  `id_contratante` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(10) unsigned DEFAULT NULL,
  `id_mdfe` int(10) unsigned DEFAULT NULL,
  `cnpj_fornecedor_vale` char(18) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cpf_cnpj_resp_pgto_vale` char(18) COLLATE utf8mb4_unicode_ci NOT NULL,
  `num_comprovante_pgto_vale` int(10) unsigned DEFAULT NULL,
  `valor_pgto_vale` decimal(15,2) unsigned DEFAULT NULL,
  `data_cad_contratante` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_contratante`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_menu`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_menu` (
  `id_menu` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `desc_menu` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordenacao` int(11) NOT NULL,
  `status_menu` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Inativo',
  `tipo_menu` enum('Plano','WebService','Ambos') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Plano',
  `visivel_menu` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `local_menu` enum('Sistema','Sistema.Ajuda.Config','Parceiro','Admin') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sistema',
  PRIMARY KEY (`id_menu`),
  UNIQUE KEY `id_menu` (`id_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_menu_sub`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_menu_sub` (
  `id_sub_menu` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_menu` int(11) NOT NULL,
  `desc_sub_menu` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secao_menu` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modulo_menu` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_menu` int(11) NOT NULL DEFAULT '0',
  `ordenacao` int(10) unsigned NOT NULL,
  `blank_sub_menu` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `status_sub_menu` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Inativo',
  `visivel_sub_menu` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `tipo_sub_menu` enum('Plano','WebService','Ambos') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Plano',
  `sub_menu_principal` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_sub_menu`),
  UNIQUE KEY `id_sub_menu` (`id_sub_menu`),
  KEY `id_menu` (`id_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=432 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_meses`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_meses` (
  `id_mes` tinyint(1) NOT NULL,
  `numero` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mes` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `abreviado` char(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_modulos_sistema`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_modulos_sistema` (
  `id_modulo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tag` text COLLATE utf8mb4_unicode_ci,
  `modulo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario_responsavel` int(11) DEFAULT NULL,
  `data_cad_modulo` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `usuario_cad` int(11) NOT NULL,
  `data_mod_modulo` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `usuario_mod` int(11) NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_modulo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_ncm`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_ncm` (
  `id_ncm` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo_ncm` char(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `descricao_ncm` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unidade_ncm` char(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `imposto_nac` decimal(10,2) NOT NULL DEFAULT '0.00',
  `imposto_inter` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_ncm`),
  UNIQUE KEY `codigo_ncm` (`codigo_ncm`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_ncm_imposto`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_ncm_imposto` (
  `id_ncm` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo_ncm` char(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `estado_origem` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nacional` decimal(10,2) NOT NULL DEFAULT '0.00',
  `importado` decimal(10,2) NOT NULL DEFAULT '0.00',
  `estadual` decimal(10,2) NOT NULL DEFAULT '0.00',
  `municipal` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_ncm`),
  KEY `codigo_ncm` (`codigo_ncm`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_nota_nt`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_nota_nt` (
  `id_nota_nt` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `estado` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ambiente_1` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sim',
  `ambiente_2` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sim',
  `nfce_1` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sim',
  `nfce_2` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sim',
  PRIMARY KEY (`id_nota_nt`),
  KEY `id_nota_nt` (`id_nota_nt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_nps_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_nps_log` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `id_pergunta` int(11) DEFAULT NULL,
  `data_exibir` date DEFAULT NULL,
  `data_ocultar` date DEFAULT NULL,
  `data_cad_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_nps_perguntas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_nps_perguntas` (
  `id_pergunta` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_pesquisa` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `nps_pergunta` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_pergunta` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_pergunta` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_pergunta`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_pesquisa` (`id_pesquisa`),
  KEY `id_pesquisa_id_usuario` (`id_pesquisa`,`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_nps_pesquisas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_nps_pesquisas` (
  `id_pesquisa` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `pesquisa_nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pesquisa_descricao` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_inicio` date NOT NULL,
  `data_fim` date NOT NULL,
  `status_pesquisa` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Ativo',
  `data_cad_pesquisa` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_pesquisa` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_pesquisa`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_nps_respostas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_nps_respostas` (
  `id_resposta` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_pergunta` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `nps_nota` tinyint(1) NOT NULL,
  `nps_nota_motivo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_resposta` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_resposta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_nps_respostas_canceladas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_nps_respostas_canceladas` (
  `id_resposta_cancelada` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_pesquisa` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `data_cad_resposta_cancelada` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_resposta_cancelada`),
  KEY `id_resposta_cancelada` (`id_resposta_cancelada`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_openbanking_webhook_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_openbanking_webhook_log` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `log` longtext COLLATE utf8mb4_unicode_ci,
  `data_cad_log` datetime DEFAULT '2019-10-09 23:09:41',
  PRIMARY KEY (`id_log`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_orcamentos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_orcamentos` (
  `id_orcamento` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_pedido` int(11) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) DEFAULT '0',
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_local_entrega` int(11) DEFAULT '0',
  `id_local_retirada` int(11) DEFAULT '0',
  `id_local_cobranca` int(11) DEFAULT '0',
  `vendedor_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendedor_pedido_id` bigint(20) DEFAULT NULL,
  `listapreco_produtos` int(11) NOT NULL DEFAULT '0',
  `valor_total_produtos` decimal(10,2) DEFAULT '0.00',
  `desconto_pedido` decimal(10,2) DEFAULT '0.00',
  `desconto_pedido_porc` decimal(10,2) DEFAULT '0.00',
  `peso_total_nota` decimal(10,2) DEFAULT '0.00',
  `peso_total_nota_liq` decimal(10,4) DEFAULT '0.0000',
  `frete_pedido` decimal(10,2) DEFAULT '0.00',
  `valor_total_nota` decimal(10,2) DEFAULT '0.00',
  `valor_baseICMS` decimal(10,2) DEFAULT '0.00',
  `valor_ICMS` decimal(10,2) DEFAULT '0.00',
  `valor_baseST` decimal(10,2) DEFAULT '0.00',
  `valor_ST` decimal(10,2) DEFAULT '0.00',
  `valor_IPI` decimal(10,2) DEFAULT '0.00',
  `condicao_pagamento_id` int(11) DEFAULT '0',
  `condicao_pagamento` tinyint(1) DEFAULT NULL,
  `frete_por_pedido` tinyint(1) DEFAULT '9',
  `transportadora_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_transportadora` int(11) DEFAULT NULL,
  `data_pedido` date DEFAULT NULL,
  `validade_orcamento` char(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prazo_orcamento` char(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referencia_pedido` char(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `obs_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `obs_interno_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `status_pedido` char(20) COLLATE utf8mb4_unicode_ci DEFAULT 'Em Aberto',
  `contas_pedido` tinyint(1) DEFAULT '0',
  `comissao_pedido` tinyint(1) DEFAULT '0',
  `estoque_pedido` tinyint(1) DEFAULT '0',
  `pedido_emitido` tinyint(1) DEFAULT '0',
  `nota_emitida` tinyint(1) DEFAULT '0',
  `funil_emitido` int(11) DEFAULT '0',
  `usuario_cad_pedido` bigint(20) DEFAULT '0',
  `agrupado` tinyint(1) DEFAULT '0',
  `agrupado_data` datetime DEFAULT NULL,
  `agrupado_user` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agrupamento` tinyint(1) DEFAULT '0',
  `data_cad_pedido` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_pedido` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_orcamento`),
  KEY `ix_nazar_nfe_orcamentos_id_empresa_data_pedido` (`id_empresa`,`data_pedido`),
  KEY `ix_nfe_orcamentos_id_empresa_vendedor_pedido` (`id_empresa`,`vendedor_pedido`),
  KEY `ix_nfe_orcamentos_id_empresa_lixeira` (`id_empresa`,`lixeira`),
  KEY `ix_nfe_orcamentos_id_empresa_referencia_pedido` (`id_empresa`,`referencia_pedido`),
  KEY `ix_nfe_orcamentos_id_empresa_valor_total_nota` (`id_empresa`,`valor_total_nota`),
  KEY `ix_nfe_orcamentos_id_empresa_id_pedido` (`id_empresa`,`id_pedido`),
  KEY `status_pedido` (`status_pedido`),
  KEY `ix_nfe_orcamentos_id_empresa_nome_cliente` (`id_empresa`,`nome_cliente`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_orcamentos_parcelas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_orcamentos_parcelas` (
  `id_parcela` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_orcamento` bigint(20) DEFAULT '0',
  `data_parcela` date DEFAULT NULL,
  `valor_parcela` decimal(10,2) DEFAULT '0.00',
  `forma_pagamento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes_parcela` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_parcela`),
  KEY `id_orcamento` (`id_orcamento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_orcamentos_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_orcamentos_produtos` (
  `id_ped_produto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_orcamento` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `desc_produto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qtde_produto` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `desconto_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ipi_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `icms_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_unit_produto` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `valor_custo_produto` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `valor_total_produto` decimal(15,2) NOT NULL DEFAULT '0.00',
  `valor_desconto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `peso_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `peso_liq_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `info_adicional` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_ped_produto`),
  KEY `id_orcamento` (`id_orcamento`),
  KEY `id_produto` (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_orcamentos_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_orcamentos_status` (
  `id_status` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_orcamento` bigint(20) DEFAULT '0',
  `data_status` date DEFAULT NULL,
  `obs_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_status` char(15) COLLATE utf8mb4_unicode_ci DEFAULT 'Em Aberto',
  PRIMARY KEY (`id_status`),
  KEY `id_orcamento` (`id_orcamento`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_empresa_id_orcamento` (`id_empresa`,`id_orcamento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_ordemcompra`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_ordemcompra` (
  `id_ordem` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_pedido` int(11) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) DEFAULT '0',
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_vendedor` int(11) DEFAULT '0',
  `vendedor_pedido` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_total_produtos` decimal(10,2) DEFAULT '0.00',
  `desconto_pedido` decimal(10,2) DEFAULT '0.00',
  `desconto_pedido_porc` decimal(10,2) DEFAULT '0.00',
  `peso_total_nota` decimal(10,2) DEFAULT '0.00',
  `frete_pedido` decimal(10,2) DEFAULT '0.00',
  `valor_total_nota` decimal(10,2) DEFAULT '0.00',
  `valor_baseICMS` decimal(10,2) DEFAULT '0.00',
  `valor_ICMS` decimal(10,2) DEFAULT '0.00',
  `valor_baseST` decimal(10,2) DEFAULT '0.00',
  `valor_ST` decimal(10,2) DEFAULT '0.00',
  `valor_IPI` decimal(10,2) DEFAULT '0.00',
  `condicao_pagamento_id` int(11) DEFAULT '0',
  `condicao_pagamento` tinyint(1) DEFAULT NULL,
  `frete_por_pedido` tinyint(1) DEFAULT '9',
  `transportadora_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_transportadora` int(11) DEFAULT NULL,
  `data_pedido` date DEFAULT NULL,
  `prazo_entrega` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `obs_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `obs_interno_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `status_pedido` char(20) COLLATE utf8mb4_unicode_ci DEFAULT 'Em Aberto',
  `contas_pedido` tinyint(1) NOT NULL DEFAULT '0',
  `estoque_pedido` tinyint(1) NOT NULL DEFAULT '0',
  `entrada_emitida` tinyint(1) NOT NULL DEFAULT '0',
  `agrupado` tinyint(1) DEFAULT '0',
  `agrupado_data` datetime DEFAULT NULL,
  `agrupado_user` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agrupamento` tinyint(1) DEFAULT '0',
  `usuario_cad_pedido` int(11) DEFAULT '0',
  `usuario_mod_pedido` int(11) DEFAULT '0',
  `data_cad_pedido` datetime DEFAULT NULL,
  `data_mod_pedido` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_ordem`),
  KEY `lixeira` (`lixeira`),
  KEY `ix_nfe_ordemcompra_id_empresa_status_pedido` (`id_empresa`,`status_pedido`),
  KEY `ix_nfe_ordemcompra_id_empresa_data_cad_pedido` (`id_empresa`,`data_cad_pedido`),
  KEY `ix_nfe_ordemcompra_id_empresa_valor_total_nota` (`id_empresa`,`valor_total_nota`),
  KEY `ix_nfe_ordemcompra_id_empresa_id_pedido` (`id_empresa`,`id_pedido`),
  KEY `ix_nfe_ordemcompra_id_empresa_nome_cliente` (`id_empresa`,`nome_cliente`),
  KEY `id_empresa` (`id_empresa`),
  KEY `ix_nfe_ordemcompra_id_empresa_vendedor_pedido` (`id_empresa`,`vendedor_pedido`),
  KEY `ix_nfe_ordemcompra_id_empresa_lixeira` (`id_empresa`,`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_ordemcompra_parcelas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_ordemcompra_parcelas` (
  `id_parcela` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_ordem` bigint(20) DEFAULT '0',
  `data_parcela` date DEFAULT NULL,
  `valor_parcela` decimal(10,2) DEFAULT '0.00',
  `forma_pagamento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes_parcela` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_parcela`),
  KEY `id_ordem` (`id_ordem`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_ordemcompra_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_ordemcompra_produtos` (
  `id_ped_produto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_ordem` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `desc_produto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qtde_produto` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `desconto_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ipi_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `icms_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_unit_produto` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `valor_total_produto` decimal(15,2) NOT NULL DEFAULT '0.00',
  `peso_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `peso_liq_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_ped_produto`),
  KEY `id_produto` (`id_produto`),
  KEY `id_ordem` (`id_ordem`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_ordemcompra_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_ordemcompra_status` (
  `id_status` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_ordem` bigint(20) DEFAULT '0',
  `data_status` date DEFAULT NULL,
  `obs_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_status` char(15) COLLATE utf8mb4_unicode_ci DEFAULT 'Em Aberto',
  PRIMARY KEY (`id_status`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_empresa_id_ordem` (`id_empresa`,`id_ordem`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_paises`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_paises` (
  `id_pais` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `codigo_ibge` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_pais` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_pais`),
  KEY `codigo_ibge` (`codigo_ibge`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_parametros_menu`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_parametros_menu` (
  `id_parametro_menu` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `desc_parametro` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `atalho_parametro` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_parametro` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Ativo',
  `ordenacao_parametro` int(11) NOT NULL,
  PRIMARY KEY (`id_parametro_menu`),
  KEY `id_parametro_menu` (`id_parametro_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_parametros_menu_sub`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_parametros_menu_sub` (
  `id_parametro_submenu` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_parametro_menu` int(11) DEFAULT NULL,
  `desc_submenu_parametro` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `atalho_submenu_parametro` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_submenu_parametro` enum('Ativo','Inativo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordenacao_submenu_parametro` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_parametro_submenu`),
  KEY `id_parametro_menu` (`id_parametro_menu`),
  KEY `id_parametro_submenu` (`id_parametro_submenu`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_parceiros`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_parceiros` (
  `id_parceiro` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT NULL,
  `cod_indicacao` int(11) NOT NULL DEFAULT '0',
  `tipo_pessoa` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PJ',
  `cnpj_parceiro` char(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `razao_parceiro` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fantasia_parceiro` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endereco_parceiro` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_parceiro` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro_parceiro` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complemento_parceiro` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep_parceiro` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_parceiro` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_parceiro_cod` int(11) DEFAULT NULL,
  `uf_parceiro` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fone_parceiro` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `celular_parceiro` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_parceiro` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website_parceiro` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comissao_parceiro` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `comissao_atual` decimal(10,2) NOT NULL DEFAULT '0.00',
  `primeira_parcela` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `meta_mensal` smallint(5) unsigned NOT NULL DEFAULT '0',
  `logo_parceiro` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_parceiro` tinyint(1) NOT NULL DEFAULT '1',
  `fatura_cliente` char(15) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'VHSYS',
  `gerar_nota` tinyint(1) DEFAULT '0',
  `empresa_parceiro` bigint(20) NOT NULL,
  `imposto_nota` decimal(10,2) NOT NULL,
  `id_banco` int(11) DEFAULT '0',
  `nome_numero_banco` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `carteira_banco` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cedente_banco` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `documento_banco` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agencia_banco` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agencia_dv_banco` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conta_banco` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conta_dv_banco` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `convenio_banco` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_cedente` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_titulo` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_login_smtp` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_senha_smtp` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_host_smtp` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_endereco` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_css` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_termos` longtext COLLATE utf8mb4_unicode_ci,
  `system_termosloja` longtext COLLATE utf8mb4_unicode_ci,
  `obs_parceiro` longtext COLLATE utf8mb4_unicode_ci,
  `status_parceiro_motivo` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ramo_atuacao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_carteira` int(11) DEFAULT NULL,
  `influencer` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acesso_autorizado` tinyint(1) NOT NULL DEFAULT '0',
  `id_sistema_contabil` int(11) NOT NULL DEFAULT '0',
  `indicacoes_dia_parceiro` int(11) NOT NULL DEFAULT '100',
  `categoria` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nenhuma',
  `data_cad_parceiro` datetime NOT NULL,
  `data_mod_parceiro` datetime NOT NULL,
  `data_aprov_parceiro` datetime DEFAULT NULL,
  `usuario_aprov_parceiro` int(11) DEFAULT NULL,
  `data_envio_email` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `prospecto_origem_parceiro` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_parceiro` enum('Aprovado','Reprovado','Pendente','Aberto') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Aberto',
  `status_documentos` enum('Aprovado','Reprovado','Aberto','Pendente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Aberto',
  `modalidade_parceiro` enum('Parceiro','Contabilidade','Academico') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Parceiro',
  `classificacao_parceiro` enum('Bronze','Prata','Ouro','Diamante','Personalizado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Bronze',
  PRIMARY KEY (`id_parceiro`),
  UNIQUE KEY `cod_indicacao_modalidade_parceiro` (`cod_indicacao`,`modalidade_parceiro`),
  KEY `tipo_parceiro` (`tipo_parceiro`),
  KEY `modalidade_parceiro` (`modalidade_parceiro`),
  KEY `lixeira` (`lixeira`),
  KEY `status_parceiro` (`status_parceiro`),
  KEY `cod_indicacao` (`cod_indicacao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_parceiros_aplicativos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_parceiros_aplicativos` (
  `id_parceiro` int(11) NOT NULL,
  `id_aplicativo` smallint(6) NOT NULL,
  KEY `id_aplicativo` (`id_aplicativo`),
  KEY `id_parceiro` (`id_parceiro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_parceiros_carteira_historia`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_parceiros_carteira_historia` (
  `id_historia` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_parceiro` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_carteira` int(11) NOT NULL,
  `data_cad_historia` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_historia`),
  KEY `id_historia` (`id_historia`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_carteira` (`id_carteira`),
  KEY `id_parceiro` (`id_parceiro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_parceiros_condicoes_especiais`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_parceiros_condicoes_especiais` (
  `id_condicao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_parceiro` int(11) NOT NULL,
  `id_plano` int(11) NOT NULL,
  `mensal` decimal(18,14) DEFAULT NULL,
  `trimestral` decimal(18,14) DEFAULT NULL,
  `semestral` decimal(18,14) DEFAULT NULL,
  `anual` decimal(18,14) DEFAULT NULL,
  `id_usuario_cad` int(11) NOT NULL,
  `data_cad_condicao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_condicao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_parceiros_conversas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_parceiros_conversas` (
  `id_conversa` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_parceiro` int(11) NOT NULL DEFAULT '0',
  `desc_conversa` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario_conversa` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_conversa` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_conversa`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_parceiro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_parceiros_documentos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_parceiros_documentos` (
  `id_documento` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_parceiro` int(11) NOT NULL DEFAULT '0',
  `tipo_documento` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pasta_documento` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_documento` char(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cadastro` datetime NOT NULL,
  PRIMARY KEY (`id_documento`),
  UNIQUE KEY `id_parceiro_tipo_documento` (`id_parceiro`,`tipo_documento`),
  KEY `id_parceiro` (`id_parceiro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_parceiros_indicacoes_emails`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_parceiros_indicacoes_emails` (
  `id_indicacao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_parceiro` int(11) DEFAULT NULL,
  `emails_indicacao` longtext COLLATE utf8mb4_unicode_ci,
  `quantidade_indicacao` int(11) DEFAULT NULL,
  `data_cad_indicacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_indicacao`),
  KEY `id_parceiro` (`id_parceiro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_parceiros_integracao_arquivos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_parceiros_integracao_arquivos` (
  `id_arquivo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_parceiro` int(11) DEFAULT NULL,
  `id_empresa` int(11) DEFAULT NULL,
  `nome_arquivo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_arquivo` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_arquivo`),
  KEY `id_parceiro` (`id_parceiro`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_parceiros_integracao_bancos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_parceiros_integracao_bancos` (
  `id_integracao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_parceiro` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_banco` bigint(20) NOT NULL DEFAULT '0',
  `cod_reduzido` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id_integracao`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_parceiro` (`id_parceiro`),
  KEY `id_banco` (`id_banco`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_parceiros_integracao_categorias`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_parceiros_integracao_categorias` (
  `id_integracao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_parceiro` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_categoria` bigint(20) NOT NULL DEFAULT '0',
  `contabilizacao` tinyint(1) NOT NULL DEFAULT '1',
  `cod_reduzido` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `clientes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_integracao`),
  KEY `id_parceiro` (`id_parceiro`),
  KEY `id_categoria` (`id_categoria`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_parceiros_integracao_historicos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_parceiros_integracao_historicos` (
  `id_integracao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_parceiro` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_historico` bigint(20) NOT NULL DEFAULT '0',
  `cod_provisao` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `cod_realizacao` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id_integracao`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_parceiro` (`id_parceiro`),
  KEY `id_historico` (`id_historico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_parceiros_plano_contas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_parceiros_plano_contas` (
  `id_plano` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_parceiro` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `classificacao_contabil` varchar(24) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cod_reduzido` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `descricao` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_plano`),
  KEY `id_parceiro` (`id_parceiro`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_parceiros_resgates`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_parceiros_resgates` (
  `id_resgate` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_parceiro` smallint(6) DEFAULT NULL,
  `valor_resgate` decimal(10,2) DEFAULT NULL,
  `anexo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comprovante` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_resgate` datetime DEFAULT NULL,
  `data_estorno` datetime DEFAULT NULL,
  `data_pagamento` datetime DEFAULT NULL,
  `status_resgate` enum('Pago','Aberto') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Aberto',
  PRIMARY KEY (`id_resgate`),
  KEY `id_parceiro` (`id_parceiro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_parceiros_sistemas_contabeis`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_parceiros_sistemas_contabeis` (
  `id_sistema_contabil` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome_sistema` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `namespace_sistema` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_sistema_contabil`),
  KEY `nome_sistema` (`nome_sistema`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_parceiros_usuarios`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_parceiros_usuarios` (
  `id_usuario` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_parceiro` int(11) NOT NULL DEFAULT '0',
  `nome_usuario` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_usuario` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `login_usuario` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `senha_usuario` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permissoes_dashboard` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissao_aplicativo` tinyint(1) DEFAULT '0',
  `data_cad_usuario` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `tipo_usuario` enum('Administrador','Usuario') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Administrador',
  `master_usuario` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `login_usuario` (`login_usuario`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_parceiro`),
  KEY `tipo_usuario` (`tipo_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_parceiros_usuarios_permissoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_parceiros_usuarios_permissoes` (
  `id_permissao` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_parceiro` int(11) DEFAULT '0',
  `id_usuario` bigint(20) DEFAULT '0',
  `id_sub_menu` int(11) DEFAULT '0',
  PRIMARY KEY (`id_permissao`),
  KEY `id_empresa` (`id_parceiro`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_parceiros_vouchers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_parceiros_vouchers` (
  `id_voucher` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_parceiro` int(10) unsigned NOT NULL,
  `id_fatura` bigint(20) unsigned DEFAULT NULL,
  `nome_voucher` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bandeira_cartao` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parcelamento` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `valor_total` decimal(16,2) unsigned NOT NULL,
  `liquidado` tinyint(1) DEFAULT '0',
  `data_liquidado` datetime DEFAULT NULL,
  `id_usuario_cad` int(10) unsigned NOT NULL,
  `data_cad_voucher` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_usuario_del` int(11) DEFAULT NULL,
  `data_del_voucher` datetime DEFAULT NULL,
  `analise_comprovante` tinyint(1) NOT NULL DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `tipo_pagamento` enum('Boleto','Cartao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Cartao',
  PRIMARY KEY (`id_voucher`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_parceiros_vouchers_comprovante`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_parceiros_vouchers_comprovante` (
  `id_comprovante` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_voucher` int(11) NOT NULL,
  `pasta_comprovante` varchar(70) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_comprovante` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cadastro` datetime NOT NULL,
  `data_mod` datetime DEFAULT NULL,
  `usuario_mod` int(11) DEFAULT NULL,
  `status_comprovante` enum('Aprovado','Negado','Aberto') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Aberto',
  PRIMARY KEY (`id_comprovante`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_parceiros_vouchers_planos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_parceiros_vouchers_planos` (
  `id_voucher_plano` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_voucher` int(10) unsigned NOT NULL,
  `id_plano` int(10) unsigned NOT NULL,
  `periodicidade` tinyint(1) NOT NULL DEFAULT '1',
  `qtde` int(11) NOT NULL DEFAULT '1',
  `qtde_usados` int(11) NOT NULL DEFAULT '0',
  `valor_unit` decimal(16,2) NOT NULL,
  `valor_total` decimal(16,2) NOT NULL,
  PRIMARY KEY (`id_voucher_plano`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_parceiros_vouchers_planos_vouchers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_parceiros_vouchers_planos_vouchers` (
  `id_voucher_plano_voucher` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_voucher_plano` int(11) NOT NULL,
  `id_empresa` int(11) DEFAULT NULL,
  `codigo_voucher` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo_voucher_curto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_utilizacao` datetime DEFAULT NULL,
  `data_expiracao` date DEFAULT NULL,
  `disponibilidade` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_voucher_plano_voucher`),
  KEY `codigo_voucher_curto` (`codigo_voucher_curto`),
  KEY `id_voucher_plano` (`id_voucher_plano`),
  KEY `usado` (`disponibilidade`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_pedidos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_pedidos` (
  `id_ped` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_pedido` int(11) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) DEFAULT '0',
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_local_entrega` int(11) NOT NULL DEFAULT '0',
  `id_local_retirada` int(11) NOT NULL DEFAULT '0',
  `id_local_cobranca` int(11) NOT NULL DEFAULT '0',
  `vendedor_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendedor_pedido_id` bigint(20) DEFAULT NULL,
  `vendedor2_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendedor2_pedido_id` bigint(20) DEFAULT NULL,
  `listapreco_produtos` int(11) NOT NULL DEFAULT '0',
  `valor_total_produtos` decimal(10,2) DEFAULT '0.00',
  `desconto_pedido` decimal(10,2) DEFAULT '0.00',
  `desconto_pedido_porc` decimal(10,2) DEFAULT '0.00',
  `peso_total_nota` decimal(10,2) DEFAULT '0.00',
  `peso_total_nota_liq` decimal(15,6) DEFAULT '0.000000',
  `frete_pedido` decimal(10,2) DEFAULT '0.00',
  `valor_total_nota` decimal(10,2) DEFAULT '0.00',
  `valor_baseICMS` decimal(10,2) DEFAULT '0.00',
  `valor_ICMS` decimal(10,2) DEFAULT '0.00',
  `valor_baseST` decimal(10,2) DEFAULT '0.00',
  `valor_ST` decimal(10,2) DEFAULT '0.00',
  `valor_IPI` decimal(10,2) DEFAULT '0.00',
  `condicao_pagamento_id` int(11) DEFAULT '0',
  `condicao_pagamento` tinyint(1) DEFAULT NULL,
  `frete_por_pedido` tinyint(1) DEFAULT '9',
  `transportadora_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_transportadora` int(11) DEFAULT NULL,
  `data_pedido` date DEFAULT NULL,
  `prazo_entrega` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referencia_pedido` char(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `obs_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `obs_interno_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `status_pedido` char(20) COLLATE utf8mb4_unicode_ci DEFAULT 'Em Aberto',
  `contas_pedido` tinyint(1) DEFAULT '0',
  `comissao_pedido` tinyint(1) DEFAULT '0',
  `estoque_pedido` tinyint(1) DEFAULT '0',
  `ordemc_emitido` tinyint(1) DEFAULT '0',
  `loja_emitido` int(11) DEFAULT '0',
  `usuario_cad_pedido` bigint(20) DEFAULT '0',
  `agrupado` tinyint(1) DEFAULT '0',
  `agrupado_data` datetime DEFAULT NULL,
  `agrupado_user` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agrupamento` tinyint(1) DEFAULT '0',
  `data_cad_pedido` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_pedido` datetime DEFAULT NULL,
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` char(100) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `sync_user` int(11) DEFAULT '0',
  `id_aplicativo` smallint(6) DEFAULT NULL,
  `id_pedido_aplicativo` bigint(20) DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  PRIMARY KEY (`id_ped`),
  KEY `sync` (`sync`),
  KEY `status_pedido` (`status_pedido`),
  KEY `ix_nfe_pedidos_id_empresa_id_pedido` (`id_empresa`,`id_pedido`),
  KEY `ix_nfe_pedidos_id_empesa_data_pedido` (`id_empresa`,`data_pedido`),
  KEY `ix_nfe_pedidos_id_empresa_nome_cliente` (`id_empresa`,`nome_cliente`),
  KEY `ix_nfe_pedidos_id_empresa_vendedor_pedido` (`id_empresa`,`vendedor_pedido`),
  KEY `ix_nfe_pedidos_id_empresa_lixeira` (`id_empresa`,`lixeira`),
  KEY `ix_nfe_pedidos_id_empresa_referencia_pedido` (`id_empresa`,`referencia_pedido`),
  KEY `id_empresa` (`id_empresa`),
  KEY `ix_nfe_pedidos_id_empresa_valor_total_nota` (`id_empresa`,`valor_total_nota`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_pedidos_parcelas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_pedidos_parcelas` (
  `id_parcela` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_pedido` bigint(20) DEFAULT '0',
  `data_parcela` date DEFAULT NULL,
  `valor_parcela` decimal(10,2) DEFAULT '0.00',
  `forma_pagamento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes_parcela` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_parcela`),
  KEY `id_pedido` (`id_pedido`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_pedidos_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_pedidos_produtos` (
  `id_ped_produto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_pedido` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `desc_produto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qtde_produto` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `desconto_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ipi_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `icms_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_unit_produto` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `valor_custo_produto` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `valor_total_produto` decimal(15,2) NOT NULL DEFAULT '0.00',
  `valor_desconto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `peso_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `peso_liq_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `info_adicional` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `xPed_produto` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nItem_produto` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_ped_produto`),
  KEY `id_produto` (`id_produto`),
  KEY `id_pedido` (`id_pedido`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_pedidos_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_pedidos_status` (
  `id_status` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_pedido` bigint(20) DEFAULT '0',
  `data_status` date DEFAULT NULL,
  `obs_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_status` char(15) COLLATE utf8mb4_unicode_ci DEFAULT 'Em Aberto',
  PRIMARY KEY (`id_status`),
  KEY `id_empresa_id_pedido` (`id_empresa`,`id_pedido`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_pedidos_sync`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_pedidos_sync` (
  `id_pedido` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  UNIQUE KEY `id_pedido_id_usuario_uniq` (`id_pedido`,`id_usuario`),
  KEY `sync` (`sync`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_cliente_id_usuario` (`id_pedido`,`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_planos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_planos` (
  `id_plano` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `id_parceiro` int(11) NOT NULL DEFAULT '0',
  `id_aplicativo` int(11) NOT NULL DEFAULT '0',
  `nome_plano` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_plano` decimal(10,2) NOT NULL DEFAULT '0.00',
  `limite_nota` int(11) NOT NULL DEFAULT '0',
  `limite_nfc` int(11) NOT NULL DEFAULT '0',
  `limite_cte` int(11) NOT NULL DEFAULT '0',
  `limite_user` int(11) NOT NULL DEFAULT '0',
  `limite_produtos` int(11) NOT NULL DEFAULT '0',
  `limite_nota_entrada` int(11) NOT NULL DEFAULT '0',
  `oculta_menu_limitado` tinyint(1) DEFAULT '0',
  `adicional_nota` decimal(10,2) NOT NULL DEFAULT '0.00',
  `adicional_nfc` decimal(10,2) NOT NULL DEFAULT '0.00',
  `adicional_cte` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pontuacao` decimal(10,2) NOT NULL DEFAULT '0.00',
  `plano_original` smallint(6) NOT NULL DEFAULT '0',
  `tipo` char(15) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Plano',
  `desc_aplicativo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc_plano_app` char(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `visivel` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sim',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `ocultar_sped_fiscal` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id_plano`),
  KEY `tipo` (`tipo`),
  KEY `id_aplicativo` (`id_aplicativo`)
) ENGINE=InnoDB AUTO_INCREMENT=191 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_planos_permissoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_planos_permissoes` (
  `id_permissao` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_plano` int(11) NOT NULL,
  `id_menu` int(11) DEFAULT NULL,
  `id_sub_menu` int(11) DEFAULT NULL,
  `id_aplicativo` int(11) DEFAULT NULL,
  `id_widget` int(11) DEFAULT NULL,
  `modulo_menu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secao_menu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_permissao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_permissao`),
  KEY `id_menu` (`id_menu`),
  KEY `id_widget` (`id_widget`),
  KEY `id_aplicativo` (`id_aplicativo`),
  KEY `id_plano` (`id_plano`),
  KEY `id_sub_menu` (`id_sub_menu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_planos_tipo`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_planos_tipo` (
  `id_tipo` tinyint(1) NOT NULL,
  `valor_tipo` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_tipo` char(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao_tipo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comissionado` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_recebimento_email`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_recebimento_email` (
  `chave_nfe` char(44) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_contas_rec` bigint(20) DEFAULT '0',
  `email_recebimento` char(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_recebimento` datetime NOT NULL,
  KEY `chave_nfe` (`chave_nfe`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_servico`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_servico` (
  `id_servico` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `recorrente` tinyint(1) NOT NULL DEFAULT '0',
  `serie_nota` char(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `id_pedido` int(11) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) NOT NULL DEFAULT '0',
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_local_retirada` int(11) NOT NULL DEFAULT '0',
  `id_local_entrega` int(11) NOT NULL DEFAULT '0',
  `id_local_cobranca` int(11) NOT NULL DEFAULT '0',
  `cliente_inexistente` tinyint(1) NOT NULL DEFAULT '0',
  `vendedor_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendedor_pedido_id` bigint(20) NOT NULL DEFAULT '0',
  `desc_servicos` longtext COLLATE utf8mb4_unicode_ci,
  `itemLista_servico` smallint(6) DEFAULT NULL,
  `valor_total_servicos` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_deducoes` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_incondicionado` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_condicionado` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_base_calculo` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_aliquota` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `valor_imposto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `reter_iss` tinyint(1) NOT NULL DEFAULT '0',
  `aliq_cofins` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_cofins` decimal(10,2) NOT NULL DEFAULT '0.00',
  `aliq_pis` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_pis` decimal(10,2) NOT NULL DEFAULT '0.00',
  `aliq_contribuicao` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_contribuicao` decimal(10,2) NOT NULL DEFAULT '0.00',
  `aliq_ir` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_ir` decimal(10,2) NOT NULL DEFAULT '0.00',
  `aliq_iss` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_iss` decimal(10,2) NOT NULL DEFAULT '0.00',
  `reter_cofins` tinyint(1) NOT NULL DEFAULT '0',
  `reter_pis` tinyint(1) NOT NULL DEFAULT '0',
  `reter_csll` tinyint(1) NOT NULL DEFAULT '0',
  `reter_ir` tinyint(1) NOT NULL DEFAULT '0',
  `reter_inss` tinyint(1) NOT NULL DEFAULT '0',
  `valor_total_nota` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_aliq_tributos` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_tributos` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_aliq_tributos_mun` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_tributos_mun` decimal(10,2) NOT NULL DEFAULT '0.00',
  `construcao_civil` tinyint(1) NOT NULL DEFAULT '0',
  `codigo_obra` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_art` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_material` decimal(10,2) NOT NULL DEFAULT '0.00',
  `condicao_pagamento_id` int(11) DEFAULT '0',
  `condicao_pagamento` tinyint(1) DEFAULT NULL,
  `regime_pedido` tinyint(1) NOT NULL DEFAULT '0',
  `natureza_pedido` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `numero_processo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `local_prestacao` tinyint(1) NOT NULL DEFAULT '0',
  `local_prestacao_cidade` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `local_prestacao_cidade_cod` char(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `obs_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `obs_interno_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `status_pedido` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Em Aberto',
  `contas_pedido` int(11) NOT NULL DEFAULT '0',
  `comissao_pedido` int(11) NOT NULL DEFAULT '0',
  `boletos_pedido` int(11) NOT NULL DEFAULT '0',
  `nota_emitida` int(11) NOT NULL DEFAULT '0',
  `nota_chave` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nota_protocolo` char(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nota_numero_nfse` bigint(20) NOT NULL DEFAULT '0',
  `nota_recibo_lote` char(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nota_data_autorizacao` datetime DEFAULT NULL,
  `nota_usuario_autorizacao` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nota_data_cancelamento` datetime DEFAULT NULL,
  `nota_key` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usuario_cad_pedido` bigint(20) NOT NULL DEFAULT '0',
  `data_cad_pedido` datetime NOT NULL,
  `data_mod_pedido` datetime DEFAULT NULL,
  `ambiente` tinyint(1) NOT NULL DEFAULT '1',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_servico`),
  KEY `nota_chave` (`nota_chave`),
  KEY `id_empresa` (`id_empresa`),
  KEY `lixeira` (`lixeira`),
  KEY `nota_emitida` (`nota_emitida`),
  KEY `ix_nfe_servico_id_empresa_nota_numero_nfse` (`id_empresa`,`nota_numero_nfse`),
  KEY `ix_nazar_nfe_servico_id_empresa_nota_data_autorizacao` (`id_empresa`,`nota_data_autorizacao`),
  KEY `ix_nfe_servico_id_empresa_nome_cliente` (`id_empresa`,`nome_cliente`),
  KEY `ix_nfe_servico_id_empresa_lixeira` (`id_empresa`,`lixeira`),
  KEY `ix_nfe_servico_id_empresa_vendedor_pedido` (`id_empresa`,`vendedor_pedido`),
  KEY `ix_nfe_servico_id_empresa_data_cad_pedido` (`id_empresa`,`data_cad_pedido`),
  KEY `ix_nfe_servico_id_empresa_status_pedido` (`id_empresa`,`status_pedido`),
  KEY `ix_nfe_servico_id_empresa_valor_total_servicos` (`id_empresa`,`valor_total_servicos`),
  KEY `status_pedido` (`status_pedido`),
  KEY `ix_nfe_servico_id_empresa_id_pedido` (`id_empresa`,`id_pedido`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_servico_lista`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_servico_lista` (
  `id_lista` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `Codigo` char(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CodigoAtividade` char(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Descricao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imposto_nac` decimal(10,2) NOT NULL DEFAULT '0.00',
  `imposto_inter` decimal(10,2) NOT NULL DEFAULT '0.00',
  `imposto_municipal` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_lista`),
  KEY `Codigo` (`Codigo`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_servico_ordem`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_servico_ordem` (
  `id_ordem` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_pedido` int(11) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) DEFAULT '0',
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_local_entrega` int(11) DEFAULT '0',
  `id_local_retirada` int(11) NOT NULL DEFAULT '0',
  `id_local_cobranca` int(11) NOT NULL DEFAULT '0',
  `vendedor_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendedor_pedido_id` bigint(20) DEFAULT '0',
  `vendedor2_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendedor2_pedido_id` bigint(20) DEFAULT '0',
  `listapreco_produtos` int(11) NOT NULL DEFAULT '0',
  `valor_total_servicos` decimal(10,2) DEFAULT '0.00',
  `valor_total_pecas` decimal(10,2) DEFAULT '0.00',
  `valor_total_despesas` decimal(10,2) DEFAULT '0.00',
  `valor_total_desconto` decimal(10,2) DEFAULT '0.00',
  `valor_total_os` decimal(10,2) DEFAULT '0.00',
  `condicao_pagamento_id` int(11) DEFAULT '0',
  `condicao_pagamento` tinyint(1) DEFAULT NULL,
  `data_pedido` date DEFAULT NULL,
  `data_entrega` date DEFAULT NULL,
  `data_realizacao` date DEFAULT NULL,
  `data_realizacao_hora` time DEFAULT '00:00:00',
  `garantia_ordem` char(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `equipamento_ordem` longtext COLLATE utf8mb4_unicode_ci,
  `problema_ordem` longtext COLLATE utf8mb4_unicode_ci,
  `recebimento_ordem` longtext COLLATE utf8mb4_unicode_ci,
  `referencia_ordem` char(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `obs_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `obs_interno_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `laudo_ordem` longtext COLLATE utf8mb4_unicode_ci,
  `status_pedido` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Em Aberto',
  `contas_pedido` tinyint(1) NOT NULL DEFAULT '0',
  `comissao_pedido` tinyint(1) NOT NULL DEFAULT '0',
  `estoque_pedido` tinyint(1) NOT NULL DEFAULT '0',
  `nota_servico_emitida` tinyint(1) NOT NULL DEFAULT '0',
  `nota_venda_emitida` tinyint(1) NOT NULL DEFAULT '0',
  `usuario_cad_pedido` bigint(20) NOT NULL DEFAULT '0',
  `funil_emitido` int(11) NOT NULL DEFAULT '0',
  `loja_emitido` int(11) NOT NULL DEFAULT '0',
  `agrupado` tinyint(1) DEFAULT '0',
  `agrupado_data` datetime DEFAULT NULL,
  `agrupado_user` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agrupamento` tinyint(1) DEFAULT '0',
  `data_cad_pedido` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_pedido` datetime DEFAULT NULL,
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  `sync_user` int(11) DEFAULT '0',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `tipo_servico` enum('OS','ORC') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'OS',
  PRIMARY KEY (`id_ordem`),
  KEY `sync` (`sync`),
  KEY `status_pedido` (`status_pedido`),
  KEY `ix_nfe_servico_ordem_id_empresa_vendedor_pedido` (`id_empresa`,`vendedor_pedido`),
  KEY `ix_nfe_servico_ordem_id_empresa_lixeira` (`id_empresa`,`lixeira`),
  KEY `ix_nfe_servico_ordem_id_empresa_referencia_ordem` (`id_empresa`,`referencia_ordem`),
  KEY `ix_nfe_servico_ordem_id_empresa_data_pedido` (`id_empresa`,`data_pedido`),
  KEY `ix_nfe_servico_ordem_id_empresa_status_pedido` (`id_empresa`,`status_pedido`),
  KEY `ix_nfe_servico_ordem_id_empresa_valor_total_os` (`id_empresa`,`valor_total_os`),
  KEY `ix_nfe_servico_ordem_id_empresa_id_pedido` (`id_empresa`,`id_pedido`),
  KEY `id_empresa` (`id_empresa`),
  KEY `ix_nfe_servico_ordem_id_empresa_nome_cliente` (`id_empresa`,`nome_cliente`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_servico_ordem_contas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_servico_ordem_contas` (
  `id_conta` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_conta_rec` int(11) NOT NULL DEFAULT '0',
  `id_ordem` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_conta`),
  KEY `id_conta_rec_id_ordem_id_empresa` (`id_conta_rec`,`id_ordem`,`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_servico_ordem_parcelas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_servico_ordem_parcelas` (
  `id_parcela` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_ordem` bigint(20) DEFAULT '0',
  `data_parcela` date DEFAULT NULL,
  `valor_parcela` decimal(10,2) DEFAULT '0.00',
  `forma_pagamento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes_parcela` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_parcela`),
  KEY `id_ordem` (`id_ordem`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_servico_ordem_pecas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_servico_ordem_pecas` (
  `id_ped_produto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_ordem` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `desc_produto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qtde_produto` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `valor_unit_produto` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `valor_custo_produto` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `valor_total_produto` decimal(15,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_ped_produto`),
  KEY `id_ordem` (`id_ordem`),
  KEY `id_produto` (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_servico_ordem_servicos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_servico_ordem_servicos` (
  `id_ped_servico` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_ordem` bigint(20) NOT NULL DEFAULT '0',
  `id_servico` bigint(20) NOT NULL DEFAULT '0',
  `desc_servico` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `horas_servico` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_unit_servico` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `valor_total_servico` decimal(15,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_ped_servico`),
  KEY `id_ordem` (`id_ordem`),
  KEY `id_servico` (`id_servico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_servico_ordem_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_servico_ordem_status` (
  `id_status` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_ordem` bigint(20) DEFAULT '0',
  `data_status` datetime DEFAULT NULL,
  `obs_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_status` char(15) COLLATE utf8mb4_unicode_ci DEFAULT 'Em Aberto',
  PRIMARY KEY (`id_status`),
  KEY `id_ordem` (`id_ordem`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_empresa_id_ordem` (`id_empresa`,`id_ordem`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_servico_ordem_sync`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_servico_ordem_sync` (
  `id_ordem` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  UNIQUE KEY `id_cliente_id_usuario_uniq` (`id_ordem`,`id_usuario`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_cliente_id_usuario` (`id_ordem`,`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_servico_parcelas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_servico_parcelas` (
  `id_parcela` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_servico` bigint(20) DEFAULT '0',
  `data_parcela` date DEFAULT NULL,
  `valor_parcela` decimal(10,2) DEFAULT '0.00',
  `forma_pagamento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes_parcela` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_parcela`),
  KEY `id_servico` (`id_servico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_servico_recorrente`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_servico_recorrente` (
  `id_recorrente` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_pedido` int(11) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) DEFAULT '0',
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendedor_pedido` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendedor_pedido_id` bigint(20) DEFAULT NULL,
  `listapreco_produtos` int(11) NOT NULL DEFAULT '0',
  `valor_total_servicos` decimal(10,2) DEFAULT '0.00',
  `valor_total_desconto` decimal(10,2) DEFAULT '0.00',
  `valor_total_pedido` decimal(10,2) DEFAULT '0.00',
  `dia_vencimento` tinyint(1) DEFAULT '1',
  `dias_gerar_fatura` tinyint(1) DEFAULT '5',
  `tipo_registro` char(15) COLLATE utf8mb4_unicode_ci DEFAULT 'Conta',
  `id_banco` int(10) unsigned NOT NULL DEFAULT '0',
  `com_registro` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `protestar` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `enviar_email` tinyint(1) NOT NULL DEFAULT '1',
  `lancar_comissao` tinyint(3) unsigned DEFAULT '0',
  `gerar_nota_fiscal` tinyint(1) DEFAULT '0',
  `itemLista_servico` smallint(6) DEFAULT NULL,
  `valor_aliquota` decimal(10,2) NOT NULL DEFAULT '0.00',
  `regime_pedido` tinyint(1) NOT NULL DEFAULT '0',
  `natureza_pedido` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `local_prestacao` tinyint(1) NOT NULL DEFAULT '0',
  `reter_iss` tinyint(1) NOT NULL DEFAULT '0',
  `gerar_ordem_servico` tinyint(1) DEFAULT '0',
  `referencia_pedido` char(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_centro_custos` bigint(20) unsigned NOT NULL DEFAULT '0',
  `centro_custos_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_categoria` int(10) unsigned NOT NULL DEFAULT '0',
  `categoria_rec` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_inicio` date DEFAULT NULL,
  `data_final` date DEFAULT NULL,
  `obs_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `obs_interno_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `status_pedido` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Em Aberto',
  `usuario_cad_pedido` bigint(20) NOT NULL DEFAULT '0',
  `data_cad_pedido` datetime NOT NULL,
  `data_mod_pedido` datetime NOT NULL,
  `data_sincronizacao` date NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_recorrente`),
  KEY `lixeira` (`lixeira`),
  KEY `ix_nfe_servico_recorrente_id_empresa_nome_cliente` (`id_empresa`,`nome_cliente`),
  KEY `ix_nfe_servico_recorrente_id_empresa_lixeira` (`id_empresa`,`lixeira`),
  KEY `ix_nfe_servico_recorrente_id_empresa_vendedor_pedido` (`id_empresa`,`vendedor_pedido`),
  KEY `ix_nfe_servico_recorrente_id_empresa_data_inicio` (`id_empresa`,`data_inicio`),
  KEY `ix_nfe_servico_recorrente_id_empresa_referencia_pedido` (`id_empresa`,`referencia_pedido`),
  KEY `ix_nfe_servico_recorrente_id_empresa_data_final` (`id_empresa`,`data_final`),
  KEY `ix_nfe_servico_recorrente_id_empresa_status_pedido` (`id_empresa`,`status_pedido`),
  KEY `ix_nfe_servico_recorrente_id_empresa_valor_total_pedido` (`id_empresa`,`valor_total_pedido`),
  KEY `id_empresa` (`id_empresa`),
  KEY `ix_nfe_servico_recorrente_id_empresa_id_pedido` (`id_empresa`,`id_pedido`),
  KEY `data_sincronizacao` (`data_sincronizacao`),
  KEY `status_pedido` (`status_pedido`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_servico_recorrente_adicionais`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_servico_recorrente_adicionais` (
  `id_adicional` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_recorrente` int(11) NOT NULL DEFAULT '0',
  `data_proveniente` date NOT NULL,
  `desc_adicional` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_adicional` decimal(10,2) NOT NULL DEFAULT '0.00',
  `processado` tinyint(1) NOT NULL DEFAULT '0',
  `data_cad_adicional` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_adicional`),
  KEY `id_recorrente` (`id_recorrente`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_servico_recorrente_alteracoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_servico_recorrente_alteracoes` (
  `id_historico` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_recorrente` bigint(20) DEFAULT '0',
  `id_empresa` bigint(20) DEFAULT '0',
  `id_pedido` int(11) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) DEFAULT '0',
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendedor_pedido` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendedor_pedido_id` bigint(20) DEFAULT NULL,
  `listapreco_produtos` int(11) NOT NULL DEFAULT '0',
  `valor_total_servicos` decimal(10,2) DEFAULT '0.00',
  `valor_total_desconto` decimal(10,2) DEFAULT '0.00',
  `valor_total_pedido` decimal(10,2) DEFAULT '0.00',
  `dia_vencimento` tinyint(1) DEFAULT '1',
  `dias_gerar_fatura` tinyint(1) DEFAULT '5',
  `tipo_registro` char(15) COLLATE utf8mb4_unicode_ci DEFAULT 'Conta',
  `id_banco` int(10) unsigned DEFAULT '0',
  `com_registro` tinyint(3) unsigned DEFAULT '0',
  `protestar` tinyint(3) unsigned DEFAULT '0',
  `enviar_email` tinyint(1) DEFAULT '1',
  `gerar_nota_fiscal` tinyint(1) DEFAULT '0',
  `itemLista_servico` smallint(6) DEFAULT NULL,
  `valor_aliquota` decimal(10,2) NOT NULL DEFAULT '0.00',
  `regime_pedido` tinyint(1) NOT NULL DEFAULT '0',
  `natureza_pedido` tinyint(1) NOT NULL DEFAULT '0',
  `local_prestacao` tinyint(1) NOT NULL DEFAULT '0',
  `reter_iss` tinyint(1) NOT NULL DEFAULT '0',
  `gerar_ordem_servico` tinyint(1) DEFAULT '0',
  `referencia_pedido` char(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_centro_custos` bigint(20) unsigned NOT NULL DEFAULT '0',
  `centro_custos_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_inicio` date DEFAULT NULL,
  `data_final` date DEFAULT NULL,
  `obs_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `obs_interno_pedido` longtext COLLATE utf8mb4_unicode_ci,
  `usuario_cad_pedido` bigint(20) NOT NULL DEFAULT '0',
  `data_cad_alteracao` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_historico`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_recorrente` (`id_recorrente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_servico_recorrente_alteracoes_servicos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_servico_recorrente_alteracoes_servicos` (
  `id_historico` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_ped_servico` bigint(20) NOT NULL DEFAULT '0',
  `id_recorrente` bigint(20) NOT NULL DEFAULT '0',
  `id_servico` bigint(20) NOT NULL DEFAULT '0',
  `desc_servico` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `obs_servico` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_pagamento` tinyint(1) DEFAULT '1',
  `proximo_mes` date DEFAULT NULL,
  `valor_total_servico` decimal(10,2) DEFAULT '0.00',
  `qtde_servico` decimal(10,4) DEFAULT '0.0000',
  `valor_unit_servico` decimal(10,2) DEFAULT '0.00',
  `data_cad_servico` datetime DEFAULT NULL,
  PRIMARY KEY (`id_historico`),
  KEY `proximo_mes` (`proximo_mes`),
  KEY `id_recorrente` (`id_recorrente`),
  KEY `id_ped_servico` (`id_ped_servico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_servico_recorrente_historico`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_servico_recorrente_historico` (
  `id_historico` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT NULL,
  `id_recorrente` bigint(20) DEFAULT NULL,
  `id_contas_rec` bigint(20) DEFAULT '0',
  `id_nota_fiscal` bigint(20) DEFAULT NULL,
  `id_ordem_servico` bigint(20) DEFAULT NULL,
  `id_cliente` bigint(20) DEFAULT '0',
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vencimento_fatura` date DEFAULT NULL,
  `valor_total_servico` decimal(10,2) DEFAULT '0.00',
  `data_cad_historico` datetime NOT NULL,
  PRIMARY KEY (`id_historico`),
  KEY `id_servico` (`id_nota_fiscal`),
  KEY `id_recorrente` (`id_recorrente`),
  KEY `id_contas_rec` (`id_contas_rec`),
  KEY `id_ordem` (`id_ordem_servico`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_servico_recorrente_historico_servicos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_servico_recorrente_historico_servicos` (
  `id_ped_servico` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_historico` bigint(20) NOT NULL DEFAULT '0',
  `id_servico` bigint(20) NOT NULL DEFAULT '0',
  `desc_servico` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `obs_servico` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_total_servico` decimal(10,2) NOT NULL DEFAULT '0.00',
  `data_cad_historico_servicos` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_ped_servico`),
  KEY `id_ordem` (`id_historico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_servico_recorrente_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_servico_recorrente_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `amount_month` int(11) DEFAULT NULL,
  `amount_next_month` int(11) DEFAULT NULL,
  `amount_date` int(11) DEFAULT NULL,
  `amount_inserted` int(11) DEFAULT NULL,
  `amount_not_inserted` int(11) DEFAULT NULL,
  `debug` int(11) DEFAULT NULL,
  `created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_servico_recorrente_servicos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_servico_recorrente_servicos` (
  `id_ped_servico` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_recorrente` bigint(20) NOT NULL DEFAULT '0',
  `id_servico` bigint(20) NOT NULL DEFAULT '0',
  `desc_servico` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `obs_servico` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_pagamento` tinyint(1) DEFAULT '1',
  `proximo_mes` date DEFAULT NULL,
  `qtde_servico` decimal(10,4) DEFAULT '0.0000',
  `valor_unit_servico` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_total_servico` decimal(10,2) NOT NULL DEFAULT '0.00',
  `data_cad_servico` datetime DEFAULT NULL,
  PRIMARY KEY (`id_ped_servico`),
  KEY `id_ordem` (`id_recorrente`),
  KEY `proximo_mes` (`proximo_mes`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_servico_recorrente_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_servico_recorrente_status` (
  `id_status` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_recorrente` bigint(20) DEFAULT '0',
  `data_status` date DEFAULT NULL,
  `obs_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_status` char(15) COLLATE utf8mb4_unicode_ci DEFAULT 'Em Aberto',
  PRIMARY KEY (`id_status`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_empresa_id_recorrente` (`id_empresa`,`id_recorrente`),
  KEY `id_ordem` (`id_recorrente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_servico_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_servico_status` (
  `id_status` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_servico` bigint(20) DEFAULT '0',
  `data_status` date DEFAULT NULL,
  `obs_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_status` char(15) COLLATE utf8mb4_unicode_ci DEFAULT 'Em Aberto',
  PRIMARY KEY (`id_status`),
  KEY `id_servico` (`id_servico`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_empresa_id_servico` (`id_empresa`,`id_servico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_suporte`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_suporte` (
  `id_suporte` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `id_parceiro` int(11) DEFAULT '0',
  `tipo_suporte` int(11) DEFAULT '0',
  `assunto_suporte` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `motivo` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `categoria_suporte` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `impacto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone_suporte` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `encaminhado_suporte` smallint(6) NOT NULL DEFAULT '0',
  `ratio_suporte` tinyint(1) NOT NULL DEFAULT '0',
  `ratio_interno` tinyint(1) NOT NULL DEFAULT '0',
  `sla_resposta` int(11) NOT NULL DEFAULT '0',
  `card_jira` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `permissao_acesso` tinyint(1) NOT NULL DEFAULT '0',
  `data_cad_suporte` datetime NOT NULL,
  `data_mod_suporte` datetime NOT NULL,
  `status_suporte` enum('Aberto','Pendente Cliente','Pendente Equipe','Fechado','Pendente SAC','Pendente BackOffice') COLLATE utf8mb4_unicode_ci NOT NULL,
  `situacao_suporte` enum('Aberto','Fechado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Aberto',
  `privado_suporte` enum('Nao','Sim') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `prioridade_suporte` enum('Baixo','Médio','Alto','Altíssimo','Crítico') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Baixo',
  PRIMARY KEY (`id_suporte`),
  KEY `status_suporte` (`status_suporte`),
  KEY `id_empresa` (`id_empresa`),
  KEY `ix_nfe_suporte_id_parceiro_encaminhado_suporte` (`id_parceiro`,`encaminhado_suporte`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_suporte_anexos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_suporte_anexos` (
  `id_anexo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_suporte` bigint(20) DEFAULT '0',
  `usuario_anexo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caminho_anexo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_anexo` datetime DEFAULT NULL,
  `oculto_cliente` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_anexo`),
  KEY `id_suporte` (`id_suporte`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_suporte_duvida_fatura`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_suporte_duvida_fatura` (
  `id_duvida_fatura` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titulo_duvida` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc_duvida` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_duvida_fatura`),
  KEY `id_duvida_fatura` (`id_duvida_fatura`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_suporte_mensagem`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_suporte_mensagem` (
  `id_mensagem` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_suporte` bigint(20) NOT NULL DEFAULT '0',
  `resposta_de` char(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mensagem` longtext COLLATE utf8mb4_unicode_ci,
  `parceiro` tinyint(1) NOT NULL DEFAULT '0',
  `data_cad_mensagem` datetime DEFAULT NULL,
  `data_mod_mensagem` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci DEFAULT 'Nao',
  `lido_mensagem` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `oculta_mensagem` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_mensagem`),
  KEY `id_suporte` (`id_suporte`),
  KEY `lixeira` (`lixeira`),
  KEY `ix_nfe_suporte_mensagem_resposta_de` (`resposta_de`),
  KEY `lido_mensagem` (`lido_mensagem`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_suporte_motivo`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_suporte_motivo` (
  `id_motivo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `desc_motivo` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordernacao` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_motivo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_suporte_online`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_suporte_online` (
  `id_acesso` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_suporte` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `usuario` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tempo` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_acesso`),
  KEY `id_suporte` (`id_suporte`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_suporte_padrao`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_suporte_padrao` (
  `id_padrao` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `tag_padrao` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mensagem_padrao` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_padrao` datetime NOT NULL,
  `data_mod_padrao` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_padrao`),
  KEY `tag_padrao` (`tag_padrao`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_suporte_prioridade`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_suporte_prioridade` (
  `id_prioridade` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `desc_prioridade` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordernacao` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_prioridade`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_suporte_sla_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_suporte_sla_log` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_suporte` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `data_remocao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sla_remocao` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_log`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_suporte_tipo`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_suporte_tipo` (
  `id_tipo` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `desc_tipo` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` char(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordernacao` tinyint(1) NOT NULL,
  `nivel` tinyint(1) NOT NULL DEFAULT '1',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_tipo`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_uso_sped_fiscal`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_uso_sped_fiscal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `clicou_relatorio` int(11) DEFAULT '0',
  `acessou_atualizar_empresa` int(11) DEFAULT '0',
  `acessou_atualizar_produtos` int(11) DEFAULT '0',
  `gerou_arquivo_sped` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_vendas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_vendas` (
  `id_venda` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `tp_nfe` tinyint(1) NOT NULL DEFAULT '1',
  `serie_nota` int(11) NOT NULL DEFAULT '1',
  `id_pedido` int(11) NOT NULL DEFAULT '0',
  `id_cliente` bigint(20) NOT NULL DEFAULT '0',
  `nome_cliente` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_local_retirada` int(11) NOT NULL DEFAULT '0',
  `id_local_entrega` int(11) NOT NULL DEFAULT '0',
  `id_local_cobranca` int(11) NOT NULL DEFAULT '0',
  `vendedor_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendedor_pedido_id` bigint(20) DEFAULT '0',
  `vendedor2_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendedor2_pedido_id` bigint(20) DEFAULT NULL,
  `listapreco_produtos` int(11) NOT NULL DEFAULT '0',
  `valor_total_produtos` decimal(10,2) DEFAULT '0.00',
  `desconto_pedido` decimal(10,2) DEFAULT '0.00',
  `desconto_pedido_porc` decimal(10,2) DEFAULT '0.00',
  `peso_total_nota` decimal(10,4) DEFAULT '0.0000',
  `peso_total_nota_liq` decimal(10,4) DEFAULT '0.0000',
  `frete_pedido` decimal(10,2) DEFAULT '0.00',
  `valor_total_nota` decimal(10,2) DEFAULT '0.00',
  `valor_baseICMS` decimal(10,2) DEFAULT '0.00',
  `valor_ICMS` decimal(10,2) DEFAULT '0.00',
  `valor_vICMSDeson_icms` decimal(10,2) DEFAULT '0.00',
  `valor_baseST` decimal(10,2) DEFAULT '0.00',
  `valor_ST` decimal(10,2) DEFAULT '0.00',
  `valor_IPI` decimal(10,2) DEFAULT '0.00',
  `valor_despesas` decimal(10,2) DEFAULT '0.00',
  `valor_serv_pis` decimal(10,2) DEFAULT '0.00',
  `valor_serv_cofins` decimal(10,2) DEFAULT '0.00',
  `valor_serv_csll` decimal(10,2) DEFAULT '0.00',
  `valor_serv_irrf` decimal(10,2) DEFAULT '0.00',
  `valor_serv_prev` decimal(10,2) DEFAULT '0.00',
  `valor_total_servicos` decimal(10,2) DEFAULT '0.00',
  `valor_desconto_blocked` tinyint(1) DEFAULT '0',
  `valor_despesas_blocked` tinyint(1) DEFAULT '0',
  `valor_frete_blocked` tinyint(1) DEFAULT '0',
  `condicao_pagamento_id` int(11) DEFAULT '0',
  `condicao_pagamento` tinyint(1) DEFAULT NULL,
  `frete_por_pedido` tinyint(1) DEFAULT '9',
  `transportadora_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_transportadora` int(11) DEFAULT NULL,
  `volumes_transporta` int(11) DEFAULT NULL,
  `especie_transporta` char(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marca_transporta` char(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numeracao_transporta` char(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `placa_transporta` char(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uf_embarque` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rntc_transporta` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `local_embarque` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_pedido` date DEFAULT NULL,
  `data_pedido_hora` time DEFAULT NULL,
  `data_emissao` date DEFAULT NULL,
  `ordem_pedido` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `indPres_pedido` tinyint(1) DEFAULT '9',
  `destino_operacao` tinyint(1) DEFAULT '0',
  `natureza_pedido` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `finalidade_nfe` tinyint(1) DEFAULT '1',
  `tipo_referencia` tinyint(1) DEFAULT '0',
  `chave_referenciada` varchar(44) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referencia_cupom_mod` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referencia_cupom_necf` char(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referencia_cupom_ncoo` char(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referencia_produtor_mod` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referencia_produtor_aamm` int(11) DEFAULT NULL,
  `referencia_produtor_serie` int(11) DEFAULT NULL,
  `referencia_produtor_num` int(11) DEFAULT NULL,
  `referencia_produtor_uf` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referencia_produtor_ie` varchar(14) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `referencia_produtor_doc` varchar(18) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `referencia_produtor_ct` varchar(44) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `iest_pedido` char(14) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `obs_pedido` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `obs_interno_pedido` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_pedido` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Em Aberto',
  `contas_pedido` tinyint(1) NOT NULL DEFAULT '0',
  `comissao_pedido` tinyint(1) NOT NULL DEFAULT '0',
  `boletos_pedido` tinyint(1) NOT NULL DEFAULT '0',
  `estoque_pedido` tinyint(1) NOT NULL DEFAULT '0',
  `nota_emitida` tinyint(1) NOT NULL DEFAULT '0',
  `nota_chave` char(44) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nota_protocolo` char(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nota_codigov` char(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nota_recibo` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nota_data_autorizacao` datetime DEFAULT NULL,
  `nota_usuario_autorizacao` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nota_data_cancelamento` datetime DEFAULT NULL,
  `nota_usuario_cancelamento` char(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nota_motivo_cancelamento` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nota_denegada` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nota_importada` tinyint(1) NOT NULL DEFAULT '0',
  `nota_scan` tinyint(1) NOT NULL DEFAULT '0',
  `xml_importado` tinyint(1) DEFAULT '0',
  `usuario_cad_pedido` bigint(20) NOT NULL DEFAULT '0',
  `data_cad_pedido` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_pedido` datetime DEFAULT NULL,
  `ambiente` tinyint(1) NOT NULL DEFAULT '2',
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  `sync_user` int(11) DEFAULT '0',
  `seguro_pedido` decimal(10,2) DEFAULT '0.00',
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `valor_seguro_blocked` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id_venda`),
  KEY `nota_chave` (`nota_chave`),
  KEY `data_cad_pedido` (`data_cad_pedido`),
  KEY `sync` (`sync`),
  KEY `status_pedido` (`status_pedido`),
  KEY `lixeira` (`lixeira`),
  KEY `ix_nfe_vendas_id_empresa_data_pedido` (`id_empresa`,`data_pedido`),
  KEY `nota_emitida` (`nota_emitida`),
  KEY `ix_nfe_vendas_id_empresa_valor_total_nota` (`id_empresa`,`valor_total_nota`),
  KEY `nota_data_autorizacao` (`nota_data_autorizacao`),
  KEY `ix_nfe_vendas_id_empresa_id_pedido` (`id_empresa`,`id_pedido`),
  KEY `ix_nfe_vendas_id_empresa_nome_cliente` (`id_empresa`,`nome_cliente`),
  KEY `ix_nazar_nfe_vendas_id_empresa_nota_data_autorizacao` (`id_empresa`,`nota_data_autorizacao`),
  KEY `ix_nfe_vendas_id_empresa_vendedor_pedido` (`id_empresa`,`vendedor_pedido`),
  KEY `id_empresa` (`id_empresa`),
  KEY `ix_nfe_vendas_id_empresa_lixeira` (`id_empresa`,`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_vendas_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_vendas_log` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `log` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `passo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_log` (`id_log`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_vendas_mensagens`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_vendas_mensagens` (
  `id_mensagem` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_venda` bigint(20) DEFAULT '0',
  `descricao_mensagem` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_mensagem`),
  KEY `id_venda` (`id_venda`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_vendas_parcelas`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_vendas_parcelas` (
  `id_parcela` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_venda` bigint(20) DEFAULT '0',
  `data_parcela` date DEFAULT NULL,
  `valor_parcela` decimal(10,2) DEFAULT '0.00',
  `forma_pagamento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes_parcela` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_parcela`),
  KEY `id_venda` (`id_venda`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_vendas_produtos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_vendas_produtos` (
  `id_ped_produto` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_venda` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `cod_produto` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desc_produto` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qtde_produto` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `desconto_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `ipi_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `icms_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_unit_produto` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `valor_custo_produto` decimal(15,6) NOT NULL DEFAULT '0.000000',
  `valor_total_produto` decimal(15,2) NOT NULL DEFAULT '0.00',
  `vBC_produto` decimal(15,2) NOT NULL DEFAULT '0.00',
  `vICMS_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vBCipi_produto` decimal(15,2) NOT NULL DEFAULT '0.00',
  `vIPI_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vBCST_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vST_produto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cfop_produto` int(11) NOT NULL DEFAULT '0',
  `ncm_produto` char(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unidade_produto` char(6) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'UN',
  `unidade_tributavel` char(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qtde_tributavel` decimal(15,4) DEFAULT '0.0000',
  `valor_unit_tributavel` decimal(15,6) DEFAULT '0.000000',
  `beneficio_fiscal` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `origem_produto` tinyint(1) NOT NULL DEFAULT '0',
  `peso_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `peso_liq_produto` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `tipo_produto` tinyint(1) NOT NULL DEFAULT '1',
  `info_adicional` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ordem_produto` char(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_barras` char(14) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_tributos_unit` decimal(15,2) NOT NULL DEFAULT '0.00',
  `valor_tributos_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_tributosEst_unit` decimal(15,2) NOT NULL DEFAULT '0.00',
  `valor_tributosEst_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_desconto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_frete` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_outros` decimal(10,2) NOT NULL DEFAULT '0.00',
  `xPed_produto` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nItem_produto` smallint(6) DEFAULT NULL,
  `valor_seguro` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id_ped_produto`),
  KEY `id_venda` (`id_venda`),
  KEY `id_produto` (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_vendas_produtos_ARMA`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_vendas_produtos_ARMA` (
  `id_arma` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_venda` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `tpArma_arma` tinyint(1) NOT NULL DEFAULT '0',
  `nSerie_arma` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nCano_arma` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descr_arma` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_arma`),
  UNIQUE KEY `id_produto` (`id_produto`),
  KEY `id_venda` (`id_venda`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_vendas_produtos_COFINS`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_vendas_produtos_COFINS` (
  `id_cofins` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_venda` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `cst_cofins` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '08',
  `vBC_cofins` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pCOFINS_cofins` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vCOFINS_cofins` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_cofins`),
  UNIQUE KEY `id_produto` (`id_produto`),
  KEY `id_venda` (`id_venda`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_vendas_produtos_COMB`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_vendas_produtos_COMB` (
  `id_comb` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_venda` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `cod_anp_comb` char(9) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cod_codif_comb` char(21) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qTemp_comb` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `UFCons_comb` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qBCProd_comb` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `vAliqProd_comb` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `vCIDE_comb` decimal(10,2) NOT NULL DEFAULT '0.00',
  `descANP_comb` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pGLP_comb` decimal(10,4) DEFAULT NULL,
  `pGNn_comb` decimal(10,4) DEFAULT NULL,
  `pGNi_comb` decimal(10,4) DEFAULT NULL,
  `vPart_comb` decimal(10,4) DEFAULT NULL,
  PRIMARY KEY (`id_comb`),
  UNIQUE KEY `id_produto` (`id_produto`),
  KEY `id_venda` (`id_venda`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_vendas_produtos_DEVO`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_vendas_produtos_DEVO` (
  `id_exp` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_venda` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `valor_devolucao` decimal(10,2) DEFAULT NULL,
  `valor_ipi_devolucao` decimal(10,4) DEFAULT NULL,
  PRIMARY KEY (`id_exp`),
  UNIQUE KEY `id_produto` (`id_produto`),
  KEY `id_venda` (`id_venda`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_vendas_produtos_DI`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_vendas_produtos_DI` (
  `id_di` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `id_venda` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `numero_di` char(12) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_registro` date NOT NULL,
  `cod_exportador` char(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uf_desembaraco` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `local_desembaraco` char(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_desembaraco` date DEFAULT NULL,
  `via_transporte` tinyint(1) NOT NULL,
  `valor_afrmm` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tipo_importacao` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_di`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_produto` (`id_produto`),
  KEY `id_venda` (`id_venda`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_vendas_produtos_DI_adicao`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_vendas_produtos_DI_adicao` (
  `id_adicao` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_venda` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL,
  `id_di` bigint(20) NOT NULL DEFAULT '0',
  `numero_adicao` smallint(6) NOT NULL DEFAULT '0',
  `cod_fabricante` char(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desconto_adicao` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_adicao`),
  KEY `id_produto` (`id_produto`),
  KEY `id_venda` (`id_venda`),
  KEY `id_di` (`id_di`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_vendas_produtos_EXP`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_vendas_produtos_EXP` (
  `id_exp` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_venda` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `nDraw_exp` char(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nRE_exp` char(12) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chNFe_exp` char(44) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qExport_exp` decimal(20,4) DEFAULT NULL,
  PRIMARY KEY (`id_exp`),
  UNIQUE KEY `id_produto` (`id_produto`),
  KEY `id_venda` (`id_venda`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_vendas_produtos_ICMS`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_vendas_produtos_ICMS` (
  `id_icms` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_venda` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `cst_icms` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '40',
  `origem_mercadoria` tinyint(1) NOT NULL DEFAULT '0',
  `modalidade_icms` tinyint(1) NOT NULL DEFAULT '3',
  `vBC_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pICMS_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vICMS_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pRedBC_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vICMSDeson_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `motDesICMS_icms` tinyint(1) NOT NULL DEFAULT '9',
  `pCredSN_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vCredICMSSN_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vBCSTRet_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vICMSSubstituto` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pST_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vICMSSTRet_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vBCUFDest_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pICMSUFDest_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vBCEfet_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pRedBCEfet_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pICMSEfet_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vICMSEfet_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pFCPUFDest_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vBCFCPST_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pFCPST_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vFCPST_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vBCFCP_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pFCP_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vFCP_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vBCFCPSTRet_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vFCPSTRet_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pFCPSTRet_icms` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pDif_icms` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `grupo_repasse_st` tinyint(1) DEFAULT '0',
  `vBCSTRet_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vICMSSTRet_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vBCSTDest_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vICMSSTDest_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_icms`),
  UNIQUE KEY `id_produto` (`id_produto`),
  KEY `id_venda` (`id_venda`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_vendas_produtos_II`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_vendas_produtos_II` (
  `id_ii` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_venda` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `vBC_ii` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vDespesas_ii` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vIOF_ii` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vII_ii` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_ii`),
  UNIQUE KEY `id_produto` (`id_produto`),
  KEY `id_venda` (`id_venda`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_vendas_produtos_IPI`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_vendas_produtos_IPI` (
  `id_ipi` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_venda` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `cst_ipi` char(2) COLLATE utf8mb4_unicode_ci DEFAULT '52',
  `classe_enquadramento` char(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cEnq_enquadramento` char(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vBC_ipi` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pIPI_ipi` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vIPI_ipi` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_ipi`),
  UNIQUE KEY `id_produto` (`id_produto`),
  KEY `id_venda` (`id_venda`),
  KEY `id_venda_id_produto` (`id_venda`,`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_vendas_produtos_ISSQN`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_vendas_produtos_ISSQN` (
  `id_issqn` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_venda` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `tributacao_issqn` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'I',
  `vBC_issqn` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pISSQN_issqn` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vISSQN_issqn` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cListServ_issqn` char(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_issqn` char(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cidade_issqn_cod` int(11) DEFAULT '0',
  `estado_issqn` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_issqn`),
  UNIQUE KEY `id_produto` (`id_produto`),
  KEY `id_venda` (`id_venda`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_vendas_produtos_MED`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_vendas_produtos_MED` (
  `id_med` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_venda` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `nLote_med` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cProdANVISA_med` char(13) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qLote_med` decimal(11,3) DEFAULT NULL,
  `dFab_med` date DEFAULT NULL,
  `dVal_med` date DEFAULT NULL,
  `vPMC_med` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_med`),
  UNIQUE KEY `id_produto` (`id_produto`),
  KEY `id_venda` (`id_venda`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_vendas_produtos_PIS`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_vendas_produtos_PIS` (
  `id_pis` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_venda` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `cst_pis` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '08',
  `vBC_pis` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pPIS_pis` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vPIS_pis` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_pis`),
  UNIQUE KEY `id_produto` (`id_produto`),
  KEY `id_venda` (`id_venda`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_vendas_produtos_ST`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_vendas_produtos_ST` (
  `id_st` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_venda` bigint(20) NOT NULL DEFAULT '0',
  `id_produto` bigint(20) NOT NULL DEFAULT '0',
  `modalidade_st` tinyint(1) DEFAULT '4',
  `pMVAST_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pRedBCST_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vBCST_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pICMSST_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vICMSST_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vBCpis_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pPIS_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vPIS_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vBCcofins_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pCOFINS_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `vCOFINS_st` decimal(10,2) NOT NULL DEFAULT '0.00',
  `codigo_cest` char(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_st`),
  UNIQUE KEY `id_produto` (`id_produto`),
  KEY `id_venda` (`id_venda`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_vendas_produtos_VEIC`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_vendas_produtos_VEIC` (
  `id_veic` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_vendas` bigint(20) NOT NULL,
  `id_produto` bigint(20) NOT NULL,
  `tipo_operacao_veic` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chassi_veic` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cod_cor_veic` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descricao_cor_veic` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `potencia_motor_veic` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cilindradas_veic` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `peso_liquido_veic` decimal(12,4) DEFAULT '0.0000',
  `peso_bruto_veic` decimal(12,4) DEFAULT '0.0000',
  `serie_veic` varchar(9) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_combustivel_veic` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_motor_veic` varchar(21) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `capacidade_maxima_tracao_veic` decimal(12,4) DEFAULT '0.0000',
  `distancia_eixos_veic` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ano_modelo_fabricacao_veic` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ano_fabricacao_veic` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_pintura_veic` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_veic` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `especie_veic` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `condicao_vin_veic` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `condicao_veic` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_marca_modelo_veic` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_cor_veic` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `capacidade_maxima_lotacao_veic` int(11) DEFAULT NULL,
  `restricao_veic` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_veic`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_vendas_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_vendas_status` (
  `id_status` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) DEFAULT '0',
  `id_venda` bigint(20) DEFAULT '0',
  `data_status` date DEFAULT NULL,
  `obs_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_status` char(15) COLLATE utf8mb4_unicode_ci DEFAULT 'Em Aberto',
  PRIMARY KEY (`id_status`),
  KEY `id_empresa_id_venda` (`id_empresa`,`id_venda`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_venda` (`id_venda`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_vendas_sync`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_vendas_sync` (
  `id_venda` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `sync` tinyint(1) DEFAULT '0',
  `sync_id` int(11) DEFAULT '0',
  UNIQUE KEY `id_venda_id_usuario_uniq` (`id_venda`,`id_usuario`),
  KEY `id_venda_id_usuario` (`id_venda`,`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_versao`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_versao` (
  `id_versao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome_versao` char(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc_versao` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `destaque_versao` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_versao` datetime NOT NULL,
  PRIMARY KEY (`id_versao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_versao_recursos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_versao_recursos` (
  `id_recurso` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome_recurso` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc_recurso` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_recurso` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visivel_recurso` tinyint(1) NOT NULL DEFAULT '0',
  `data_recurso` datetime NOT NULL,
  PRIMARY KEY (`id_recurso`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_voucher_certificados`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_voucher_certificados` (
  `id_voucher_certificado` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_suporte` int(11) NOT NULL DEFAULT '0',
  `id_fatura` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL,
  `razao_empresa` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cidade_empresa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uf_empresa` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_empresa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fone_empresa` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `celular_empresa` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `origem` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `obs_voucher_certificado` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_compra` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `tipo_voucher` enum('Compra','Bonus') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_voucher_certificado`),
  KEY `id_voucher_certificado` (`id_voucher_certificado`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_webservice`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_webservice` (
  `id_nfe` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `chave_nfe` char(44) COLLATE utf8mb4_unicode_ci NOT NULL,
  `autenticacao_protocolo` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `autenticacao_data` datetime NOT NULL,
  `cancelamento_protocolo` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancelamento_data` datetime DEFAULT NULL,
  `ambiente` tinyint(1) NOT NULL DEFAULT '2',
  PRIMARY KEY (`id_nfe`),
  UNIQUE KEY `autenticacao_protocolo` (`autenticacao_protocolo`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_webservice_erros`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_webservice_erros` (
  `id_erro` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `chave_acesso` char(44) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `erro` longtext COLLATE utf8mb4_unicode_ci,
  `xml_erro` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_erro` datetime DEFAULT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_erro`),
  KEY `lixeira` (`lixeira`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_webservice_requisicoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_webservice_requisicoes` (
  `id_requisicao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc_requisicao` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_requisicao` datetime NOT NULL,
  PRIMARY KEY (`id_requisicao`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_webservice_token`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_webservice_token` (
  `id_token` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` bigint(20) NOT NULL DEFAULT '0',
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_webservice` enum('Notas','Dados') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Notas',
  PRIMARY KEY (`id_token`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_whitelabel_permissoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_whitelabel_permissoes` (
  `id_permissao` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_whitelabel` int(11) NOT NULL,
  `id_menu` int(11) DEFAULT NULL,
  `id_sub_menu` int(11) DEFAULT NULL,
  `id_parametro_menu` int(11) DEFAULT NULL,
  `id_parametro_submenu` int(11) DEFAULT NULL,
  `id_aplicativo` int(11) DEFAULT NULL,
  `id_widget` int(11) DEFAULT NULL,
  `modulo_menu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secao_menu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_cad_permissao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_permissao`),
  KEY `id_widget` (`id_widget`),
  KEY `id_aplicativo` (`id_aplicativo`),
  KEY `id_sub_menu` (`id_sub_menu`),
  KEY `id_whitelabel` (`id_whitelabel`),
  KEY `id_menu` (`id_menu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_whitelabel_usuarios`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_whitelabel_usuarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `id_whitelabel` int(11) NOT NULL,
  `sso_id` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nfe_whitelabel_usuarios_id_usuario_uindex` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_wizard`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_wizard` (
  `id_wizard` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `pagina_nfe` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `pagina_nfce` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `pagina_cb` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `data_cad_wizard` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_wizard` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status_nfe` enum('Sim','Nao','Pendente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pendente',
  `status_nfce` enum('Sim','Nao','Pendente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pendente',
  `status_cb` enum('Sim','Nao','Pendente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pendente',
  PRIMARY KEY (`id_wizard`),
  UNIQUE KEY `id_usuario` (`id_usuario`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_wizard` (`id_wizard`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notificacoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `notificacoes` (
  `id_notificacao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `tipo_notificacao` tinyint(1) NOT NULL DEFAULT '1',
  `id_aplicativo` int(11) DEFAULT NULL,
  `titulo_notificacao` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `texto_notificacao` varchar(700) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_notificacao` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visivel_notificacao` tinyint(1) NOT NULL DEFAULT '0',
  `data_notificacao` datetime NOT NULL,
  `permissao_notificacao` enum('Administrador','Usuario','Ambos') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Ambos',
  PRIMARY KEY (`id_notificacao`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notificacoes_lido`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `notificacoes_lido` (
  `id_lido` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_notificacao` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `id_usuario` int(11) NOT NULL DEFAULT '0',
  `data_leitura` datetime NOT NULL,
  PRIMARY KEY (`id_lido`),
  KEY `ix_notificacoes_lido_id_notificacao_id_usuario` (`id_notificacao`,`id_usuario`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `promocoes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `promocoes` (
  `id_promocao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome_promocao` char(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_inicio_promocao` date NOT NULL,
  `data_fim_promocao` date NOT NULL,
  `banner_promocao` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `banner_planos_promocao` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `banner_buynow` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desconto_mensal_contratacao` decimal(10,2) NOT NULL DEFAULT '0.00',
  `desconto_trimestral_contratacao` decimal(10,2) NOT NULL DEFAULT '0.00',
  `desconto_semestral_contratacao` decimal(10,2) NOT NULL DEFAULT '0.00',
  `desconto_anual_contratacao` decimal(10,2) NOT NULL DEFAULT '0.00',
  `desconto_mensal_renovacao` decimal(10,2) NOT NULL DEFAULT '0.00',
  `desconto_trimestral_renovacao` decimal(10,2) NOT NULL DEFAULT '0.00',
  `desconto_semestral_renovacao` decimal(10,2) NOT NULL DEFAULT '0.00',
  `desconto_anual_renovacao` decimal(10,2) NOT NULL DEFAULT '0.00',
  `data_cad_promocao` datetime NOT NULL,
  `data_mod_promocao` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_promocao`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `promocoes_aplicativos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `promocoes_aplicativos` (
  `id_promocao` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_aplicativo` int(11) NOT NULL DEFAULT '0',
  `desconto_padrao` decimal(10,2) NOT NULL DEFAULT '0.00',
  `desconto_maximo` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_promocao`),
  KEY `id_aplicativo` (`id_aplicativo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `promocoes_combo`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `promocoes_combo` (
  `id_combo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome_combo` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao_combo` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario_cad_combo` int(11) NOT NULL,
  `data_cad_combo` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_mod_combo` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  `tipo_venda` enum('Ambos','Clientes','CRM') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Ambos',
  PRIMARY KEY (`id_combo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `promocoes_combo_aplicativos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `promocoes_combo_aplicativos` (
  `id_combo_aplicativo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_combo` int(11) DEFAULT NULL,
  `id_aplicativo` int(11) DEFAULT NULL,
  `id_plano` int(11) DEFAULT NULL,
  `id_tipo` int(11) DEFAULT NULL,
  `desconto_aplicativo` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_combo_aplicativo`),
  KEY `id_combo` (`id_combo`),
  KEY `id_aplicativo` (`id_aplicativo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `promocoes_cupom`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `promocoes_cupom` (
  `id_cupom` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome_cupom` char(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_inicio_cupom` date NOT NULL,
  `data_fim_cupom` date NOT NULL,
  `qtde_utilizacoes` smallint(6) NOT NULL DEFAULT '0',
  `qtde_utilizado` smallint(6) NOT NULL DEFAULT '0',
  `codigo_cupom` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_cupom` datetime NOT NULL,
  `data_mod_cupom` datetime NOT NULL,
  `lixeira` enum('Sim','Nao') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nao',
  PRIMARY KEY (`id_cupom`),
  KEY `codigo_cupom` (`codigo_cupom`),
  KEY `lixeira` (`lixeira`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `promocoes_cupom_historico`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `promocoes_cupom_historico` (
  `id_historico` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_cupom` int(11) NOT NULL DEFAULT '0',
  `id_empresa` int(11) NOT NULL DEFAULT '0',
  `data_utilizacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_historico`),
  KEY `id_empresa` (`id_empresa`),
  KEY `id_cupom` (`id_cupom`),
  KEY `id_historico` (`id_historico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `promocoes_cupom_planos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `promocoes_cupom_planos` (
  `id_cupom` int(11) NOT NULL,
  `id_plano` smallint(6) NOT NULL,
  `cupom_mensal_contratacao` decimal(27,15) DEFAULT '0.000000000000000',
  `cupom_trimestral_contratacao` decimal(27,15) DEFAULT '0.000000000000000',
  `cupom_semestral_contratacao` decimal(27,15) DEFAULT '0.000000000000000',
  `cupom_anual_contratacao` decimal(27,15) DEFAULT '0.000000000000000',
  KEY `id_cupom` (`id_cupom`),
  KEY `id_cupom_id_plano` (`id_cupom`,`id_plano`),
  KEY `id_plano` (`id_plano`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `promocoes_planos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `promocoes_planos` (
  `id_promocao` int(11) NOT NULL,
  `id_plano` smallint(6) NOT NULL,
  `plano_mensal_contratacao` decimal(10,2) DEFAULT '0.00',
  `plano_trimestral_contratacao` decimal(10,2) DEFAULT '0.00',
  `plano_semestral_contratacao` decimal(10,2) DEFAULT '0.00',
  `plano_anual_contratacao` decimal(10,2) DEFAULT '0.00',
  KEY `id_promocao_id_plano` (`id_promocao`,`id_plano`),
  KEY `id_promocao` (`id_promocao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `untitled_table_573`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `untitled_table_573` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vhsys_migrations_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `vhsys_migrations_log` (
  `version` bigint(20) NOT NULL,
  `migration_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `breakpoint` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `weak_pass_change`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `weak_pass_change` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dt_notification` datetime NOT NULL,
  `dt_change` datetime NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `weak_pass_change_user_force`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `weak_pass_change_user_force` (
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nfe_especies_titulos`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT  EXISTS `nfe_especies_titulos` (
  `id_especie_titulo` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `esp_codigo` char(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `esp_descricao` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_especie_titulo`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `despesa_recorrente_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `despesa_recorrente_log` (
  `id_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_custo_fixo` bigint(20) NOT NULL,
  `id_agendamento` int(11) DEFAULT NULL,
  `id_empresa` int(11) DEFAULT NULL,
  `data_cad_log` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `despesa_recorrente_detalhe_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `despesa_recorrente_detalhe_log` (
  `id_detalhe_log` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_despesa_recorrente_log` int(10) unsigned NOT NULL,
  `id_conta_pag` bigint(20) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `nome_usuario` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL COMMENT '1- Criado 2- Editado 3- removido 4 - Lançado 5 - Estornado',
  `descricao` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_cad_detalhe_log` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_detalhe_log`),
  KEY `despesa_recorrente_detalhe_log_id_despesa_recorrente_log_foreign` (`id_despesa_recorrente_log`),
  CONSTRAINT `despesa_recorrente_detalhe_log_id_despesa_recorrente_log_foreign` FOREIGN KEY (`id_despesa_recorrente_log`) REFERENCES `despesa_recorrente_log` (`id_log`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'vhsys_erp_test'
--

--
-- Dumping routines for database 'vhsys_erp_test'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 17:37:25
