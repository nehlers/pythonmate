
CREATE TRIGGER `nfe_financeiro_contas_pag_fluxo_add` AFTER INSERT ON `nfe_financeiro_contas_pag` FOR EACH ROW BEGIN
    IF NEW.valor_pago > 0 THEN
        INSERT INTO nfe_financeiro_fluxo (id_empresa,id_banco,id_conta,id_recebimento,nome_conta,id_cliente,nome_cliente,data_fluxo,valor_fluxo,observacoes_fluxo,id_centro_custos,centro_custos_fluxo,id_categoria,categoria_fluxo,forma_pagamento,tipo_fluxo,data_cad_fluxo)VALUES(NEW.id_empresa, NEW.id_banco, NEW.id_conta_pag, 0, NEW.nome_conta, NEW.id_fornecedor, NEW.nome_fornecedor, NEW.data_pagamento, NEW.valor_pago, CONCAT(COALESCE(NEW.observacoes_pag, ''), '', COALESCE(NEW.obs_pagamento, '')), NEW.id_centro_custos, NEW.centro_custos_pag, NEW.id_categoria, NEW.categoria_pag, NEW.forma_pagamento,'Saida',now());
    END IF;

    IF NEW.sync = 1 THEN
        INSERT INTO nfe_financeiro_contas_pag_sync(id_conta_pag,id_usuario,sync,sync_id)VALUES(NEW.id_conta_pag,NEW.sync_user,1,NEW.sync_id);
    END IF;
END;;

CREATE TRIGGER `nfe_financeiro_contas_pag_sync_alt`
BEFORE UPDATE ON `nfe_financeiro_contas_pag` FOR EACH ROW
BEGIN
    DELETE FROM nfe_financeiro_contas_pag_sync WHERE id_conta_pag = NEW.id_conta_pag;

    IF OLD.sync = 1 AND NEW.sync != 2 THEN
        SET NEW.sync = 0;
    END IF;

    IF NEW.sync = 2 THEN
        SET NEW.sync = 1;
        INSERT INTO nfe_financeiro_contas_pag_sync(id_conta_pag,id_usuario,sync,sync_id)VALUES(NEW.id_conta_pag,NEW.sync_user,1,NEW.sync_id);
    END IF;
END;;


CREATE TRIGGER `nfe_financeiro_contas_pag_fluxo` AFTER UPDATE ON `nfe_financeiro_contas_pag` FOR EACH ROW BEGIN
    DECLARE recebimento INT;

    IF NEW.valor_pago > 0 AND OLD.fluxo = 0 AND NEW.lixeira != 'Sim' THEN

        IF NEW.data_pagamento != '0000-00-00'THEN
            IF NEW.valor_pago < NEW.valor_pag THEN

                INSERT INTO nfe_financeiro_contas_pag_recebimentos(id_conta_pag,data_pagamento,valor_pago,valor_juros,valor_desconto,valor_acrescimo,forma_pagamento,obs_pagamento,id_pagamento_ob,id_banco_cad)VALUES(NEW.id_conta_pag,NEW.data_pagamento,NEW.valor_pago,NEW.valor_juros,NEW.valor_desconto,NEW.valor_acrescimo,NEW.forma_pagamento,NEW.obs_pagamento,NEW.id_pagamento_ob,NEW.id_banco);
                SET recebimento = LAST_INSERT_ID();
            END IF;

            INSERT INTO nfe_financeiro_fluxo (id_empresa,id_banco,id_conta,id_recebimento,nome_conta,id_cliente,nome_cliente,data_fluxo,valor_fluxo,observacoes_fluxo,id_centro_custos,centro_custos_fluxo,id_categoria,categoria_fluxo,forma_pagamento,tipo_fluxo,data_cad_fluxo)VALUES(NEW.id_empresa, NEW.id_banco, NEW.id_conta_pag, recebimento, NEW.nome_conta, NEW.id_fornecedor, NEW.nome_fornecedor, NEW.data_pagamento, NEW.valor_pago, NEW.obs_pagamento, NEW.id_centro_custos, NEW.centro_custos_pag, NEW.id_categoria, NEW.categoria_pag, NEW.forma_pagamento,'Saida',now());
        END IF;
    END IF;

    IF NEW.valor_pago > 0 AND NEW.lixeira = 'Sim' THEN
        UPDATE nfe_financeiro_fluxo SET lixeira='Sim',lixeira_location='trigerpag' WHERE id_conta = NEW.id_conta_pag AND id_empresa = NEW.id_empresa AND tipo_fluxo='Saida';
    END IF;
END;;

CREATE TRIGGER `nfe_financeiro_contas_pag_recebimentos_sync_alt`
BEFORE UPDATE ON `nfe_financeiro_contas_pag_recebimentos` FOR EACH ROW
BEGIN
    DELETE FROM nfe_financeiro_contas_pag_recebimentos_sync WHERE id_recebimento = NEW.id_recebimento;

    IF OLD.sync = 1 AND NEW.sync != 2 THEN
        SET NEW.sync = 0;
    END IF;

    IF NEW.sync = 2 THEN
        SET NEW.sync = 1;
        INSERT INTO nfe_financeiro_contas_pag_recebimentos_sync(id_recebimento,id_usuario,sync,sync_id)VALUES(NEW.id_recebimento,NEW.sync_user,1,NEW.sync_id);
    END IF;
END;;

CREATE TRIGGER `nfe_financeiro_contas_pag_recebimentos_del` AFTER DELETE ON `nfe_financeiro_contas_pag_recebimentos` FOR EACH ROW
BEGIN
    DECLARE qtderecebimento INT;
    DECLARE varfluxo TINYINT;

    SELECT COUNT(id_conta_pag) INTO qtderecebimento FROM nfe_financeiro_contas_pag_recebimentos WHERE id_conta_pag = OLD.id_conta_pag;
    IF qtderecebimento > 0 THEN
        SET varfluxo = 1;
    ELSE
        SET varfluxo = 0;
    END IF;

    UPDATE nfe_financeiro_contas_pag SET valor_pago=valor_pago-OLD.valor_pago,liquidado_pag='Nao',data_pagamento=null,obs_pagamento='',forma_pagamento='',valor_juros=null,valor_desconto=null,valor_acrescimo=null,fluxo=varfluxo WHERE id_conta_pag = OLD.id_conta_pag;

    IF OLD.id_recebimento > 0 THEN
        UPDATE nfe_financeiro_fluxo SET data_mod_fluxo=now(), lixeira='Sim' WHERE id_conta = OLD.id_conta_pag AND id_recebimento = OLD.id_recebimento;
    END IF;
END;;

CREATE TRIGGER `nfe_financeiro_contas_rec_fluxo_add` AFTER INSERT ON `nfe_financeiro_contas_rec` FOR EACH ROW BEGIN

    IF NEW.valor_pago > 0 THEN
        INSERT INTO nfe_financeiro_fluxo (id_empresa,id_banco,id_conta,id_recebimento,nome_conta,id_cliente,nome_cliente,data_fluxo,valor_fluxo,observacoes_fluxo,id_centro_custos,centro_custos_fluxo,id_categoria,categoria_fluxo,forma_pagamento,tipo_fluxo,data_cad_fluxo)VALUES(NEW.id_empresa, NEW.id_banco, NEW.id_conta_rec, 0, NEW.nome_conta, NEW.id_cliente, NEW.nome_cliente, NEW.data_pagamento, NEW.valor_pago, CONCAT(COALESCE(NEW.observacoes_rec, ''), '', COALESCE(NEW.obs_pagamento, '')), NEW.id_centro_custos, NEW.centro_custos_rec, NEW.id_categoria, NEW.categoria_rec, NEW.forma_pagamento,'Entrada',now());
    END IF;

    IF NEW.registrado = 1 AND NEW.tipo_conta = 'Boleto' THEN
        INSERT INTO nfe_financeiro_contas_rec_operacoes(id_conta_rec,codigo_operacao,data_operacao)VALUES(NEW.id_conta_rec,'01',now());

    END IF;

    IF NEW.sync = 1 THEN
        INSERT INTO nfe_financeiro_contas_rec_sync(id_conta_rec,id_usuario,sync,sync_id)VALUES(NEW.id_conta_rec,NEW.sync_user,1,NEW.sync_id);
    END IF;
END;;

CREATE TRIGGER `nfe_financeiro_contas_rec_fluxo_registrado` BEFORE UPDATE ON `nfe_financeiro_contas_rec` FOR EACH ROW BEGIN
    DECLARE entradaconfirmada INT;

    IF NEW.registrado = 1 AND NEW.remetido = 1 AND NEW.tipo_conta = 'Boleto' AND NEW.lixeira = 'Sim' THEN
        SELECT id_retornado INTO entradaconfirmada FROM nfe_financeiro_contas_rec_retornos_reg WHERE id_contas_rec = NEW.id_conta_rec AND codigo_operacao='02';

        IF entradaconfirmada > 0 THEN
            INSERT INTO nfe_financeiro_contas_rec_operacoes(id_conta_rec,codigo_operacao,data_operacao)VALUES(NEW.id_conta_rec,'02',now());

            SET NEW.lixeira='Nao';
        END IF;
    END IF;

    DELETE FROM nfe_financeiro_contas_rec_sync WHERE id_conta_rec = NEW.id_conta_rec;

    IF OLD.sync = 1 AND NEW.sync != 2 THEN
        SET NEW.sync = 0;
    END IF;

    IF NEW.sync = 2 THEN
        SET NEW.sync = 1;
        INSERT INTO nfe_financeiro_contas_rec_sync(id_conta_rec,id_usuario,sync,sync_id)VALUES(NEW.id_conta_rec,NEW.sync_user,1,NEW.sync_id);
    END IF;
END;;

CREATE TRIGGER `nfe_financeiro_contas_rec_fluxo` AFTER UPDATE ON `nfe_financeiro_contas_rec` FOR EACH ROW BEGIN
    DECLARE recebimento INT;
    DECLARE nome_cliente CHAR(255);

    IF NEW.valor_pago > 0 AND OLD.fluxo = 0 AND NEW.lixeira != 'Sim' THEN

        IF NEW.data_pagamento != '0000-00-00' THEN
            IF NEW.valor_pago < NEW.valor_rec THEN

                INSERT INTO nfe_financeiro_contas_rec_recebimentos(id_contas_rec,data_pagamento,valor_pago,valor_juros,valor_desconto,valor_acrescimo,forma_pagamento,obs_pagamento)VALUES(NEW.id_conta_rec,NEW.data_pagamento,NEW.valor_pago,NEW.valor_juros,NEW.valor_desconto,NEW.valor_acrescimo,NEW.forma_pagamento,NEW.obs_pagamento);
                SET recebimento = LAST_INSERT_ID();
            END IF;

            IF NEW.nome_cliente IS NULL THEN SET nome_cliente = ''; ELSE SET nome_cliente = NEW.nome_cliente; END IF;
            INSERT INTO nfe_financeiro_fluxo (id_empresa,id_banco,id_conta,id_recebimento,nome_conta,id_cliente,nome_cliente,data_fluxo,valor_fluxo,observacoes_fluxo,id_centro_custos,centro_custos_fluxo,id_categoria,categoria_fluxo,forma_pagamento,tipo_fluxo,data_cad_fluxo)VALUES(NEW.id_empresa, NEW.id_banco, NEW.id_conta_rec, recebimento, NEW.nome_conta, NEW.id_cliente, nome_cliente, NEW.data_pagamento, NEW.valor_pago, NEW.obs_pagamento, NEW.id_centro_custos, NEW.centro_custos_rec, NEW.id_categoria, NEW.categoria_rec, NEW.forma_pagamento,'Entrada',now());
        END IF;

        IF NEW.retorno_pagamento = 0 AND NEW.registrado = 1 THEN
            INSERT INTO nfe_financeiro_contas_rec_operacoes(id_conta_rec,codigo_operacao,data_operacao)VALUES(NEW.id_conta_rec,'34',now());

        END IF;
    END IF;

    IF NEW.valor_pago > 0 AND NEW.lixeira = 'Sim' THEN
        UPDATE nfe_financeiro_fluxo SET lixeira='Sim',lixeira_location='trigerrec' WHERE id_conta = NEW.id_conta_rec AND id_empresa = NEW.id_empresa AND tipo_fluxo='Entrada';
    END IF;
END;;

CREATE TRIGGER `nfe_financeiro_contas_rec_retornos_reg_add` AFTER INSERT ON `nfe_financeiro_contas_rec_retornos_reg` FOR EACH ROW BEGIN
    IF NEW.Pagamento = 'Sim' OR (NEW.codigo_operacao = '09' AND NEW.ValorPago > 0) THEN
        UPDATE nfe_financeiro_contas_rec SET valor_pago = NEW.ValorPago, liquidado_rec='Sim', data_pagamento = NEW.DataCredito,
        obs_pagamento = 'Liquidado via RET', forma_pagamento = 'Boleto', retorno_pagamento = 1, NossoNumero = NEW.NossoNumero,
        lixeira = 'Nao', fluxo = 1 WHERE id_conta_rec = NEW.id_contas_rec;
    ELSE
        UPDATE nfe_financeiro_contas_rec SET NossoNumero = NEW.NossoNumero WHERE id_conta_rec = NEW.id_contas_rec;
    END IF;

    IF NEW.codigo_operacao = '10' THEN
        IF NEW.Banco = '237' AND NEW.codigo_operacao_motivo = '14' THEN
            UPDATE nfe_financeiro_contas_rec SET protestar = 1, liquidado_rec = 'Nao', obs_pagamento = 'Protestado',
            forma_pagamento = 'Boleto' WHERE id_conta_rec = NEW.id_contas_rec;
        ELSE
            IF NEW.ValorPago > 0 THEN
                UPDATE nfe_financeiro_contas_rec SET protestar = 0, liquidado_rec = 'Sim', valor_pago = NEW.ValorPago, data_pagamento = NOW(),
                obs_pagamento = 'Liquidado via RET / Baixado', forma_pagamento = 'Boleto' WHERE id_conta_rec = NEW.id_contas_rec;
            END IF;
        END IF;
    END IF;

    IF NEW.codigo_operacao = '18' OR NEW.codigo_operacao = '19' THEN
        UPDATE nfe_financeiro_contas_rec SET protestar = 0 WHERE id_conta_rec = NEW.id_contas_rec;
    END IF; 

    IF NEW.codigo_operacao = '03' THEN
        UPDATE nfe_financeiro_contas_rec SET remetido = 0 WHERE id_conta_rec = NEW.id_contas_rec;
    END IF;
END