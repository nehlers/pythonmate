import pymysql.cursors
import os
from dotenv import load_dotenv

load_dotenv()

CONST_NOME_BANCO_LOCAL = "vhsys_erp_test"

class DBStructure(object):

    def __init__(self):
        if os.getenv('DB_NAME') == CONST_NOME_BANCO_LOCAL:
            self.connection = pymysql.connect(host=os.getenv('DB_HOST'),
                user=os.getenv('DB_USER'),
                password=os.getenv('DB_PASS'),
                port=int(os.getenv('DB_PORT')),
                cursorclass=pymysql.cursors.DictCursor)

    def __del__(self): 
        if os.getenv('DB_NAME') == CONST_NOME_BANCO_LOCAL:
            self.connection.close()

    def create_ddl_local(self):
        if os.getenv('DB_NAME') == CONST_NOME_BANCO_LOCAL:
            with open('database/files/dump_20200504.sql', 'r') as f:
                for statement in f.read().split(';'): 
                    self._execute_command(statement)

    def create_ddl_trigger(self):
        if os.getenv('DB_NAME') == CONST_NOME_BANCO_LOCAL:           
            with open('database/files/trigger.sql', 'r') as f:
                for statement in f.read().split(';;'): 
                    try:
                        self._execute_command(statement)
                    except Exception:
                        pass

    def _execute_command(self, command):
        if os.getenv('DB_NAME') == CONST_NOME_BANCO_LOCAL:
            with self.connection.cursor() as cursor:
                cursor.execute(command)
            self.connection.commit()