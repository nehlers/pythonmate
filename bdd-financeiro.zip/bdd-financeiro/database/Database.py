import sys, inspect
from .DDL.DBStructure import DBStructure
from .Models.aplicativos_instalados import aplicativos_instalados
from .Models.aplicativos import aplicativos
from .Models.CONFIG import CONFIG
from .Models.nfe_bancos import nfe_bancos
from .Models.nfe_cadastros_bancos import nfe_cadastros_bancos
from .Models.nfe_config_empresas_contatos import nfe_config_empresas_contatos
from .Models.nfe_config_empresas import nfe_config_empresas
from .Models.nfe_config_empresas_numeracao import nfe_config_empresas_numeracao
from .Models.nfe_config_empresas_parametros import nfe_config_empresas_parametros
from .Models.nfe_config_empresas_servicos import nfe_config_empresas_servicos
from .Models.nfe_config_usuarios import nfe_config_usuarios
from .Models.nfe_config_usuarios_widgets import nfe_config_usuarios_widgets
from .Models.nfe_config_whitelabel import nfe_config_whitelabel
from .Models.nfe_config_widgets import nfe_config_widgets
from .Models.nfe_estados import nfe_estados
from .Models.nfe_formas_pagamento import nfe_formas_pagamento
from .Models.nfe_financeiro_contas_pag import nfe_financeiro_contas_pag
from .Models.nfe_financeiro_contas_pag_agrupamentos import nfe_financeiro_contas_pag_agrupamentos
from .Models.nfe_financeiro_contas_pag_historico import nfe_financeiro_contas_pag_historico
from .Models.nfe_financeiro_contas_pag_recebimentos import nfe_financeiro_contas_pag_recebimentos
from .Models.nfe_financeiro_fluxo import nfe_financeiro_fluxo
from .Models.nfe_financeiro_contas_rec import nfe_financeiro_contas_rec
from .Models.nfe_financeiro_contas_rec_agrupamentos import nfe_financeiro_contas_rec_agrupamentos
from .Models.nfe_menu_sub import nfe_menu_sub
from .Models.nfe_menu import nfe_menu
from .Models.nfe_parametros_menu_sub import nfe_parametros_menu_sub
from .Models.nfe_parametros_menu import nfe_parametros_menu
from .Models.nfe_planos import nfe_planos
from .Models.despesa_recorrente_agendamento import despesa_recorrente_agendamento
from .Models.nfe_financeiro_custos_fixos import nfe_financeiro_custos_fixos
from .Models.nfe_config_usuarios_relatorios import nfe_config_usuarios_relatorios
from .Models.nfe_logins_block import nfe_logins_block

from peewee import *
from dotenv import load_dotenv
import os

load_dotenv()

db_schema = DBStructure()
db_schema.create_ddl_local()
db_schema.create_ddl_trigger()
del db_schema


empresa = aplicativos_instalados.select(fn.MAX(aplicativos_instalados.id_empresa)).scalar()
os.environ["ID_EMPRESA"] = str(empresa + 1) if empresa is not None else '1'
os.environ["LOGIN"] = f"{os.getenv('LOGIN')}_{os.getenv('ID_EMPRESA')}"
usuario = nfe_config_usuarios.select(fn.MAX(nfe_config_usuarios.id_usuario)).scalar()
os.environ["ID_USUARIO"] = str(usuario + 1) if usuario is not None else '1'

aplicativos_instalados.inserir_dados_iniciais(os.environ["ID_EMPRESA"], os.environ["ID_USUARIO"])
nfe_logins_block.delete().execute()

def criar_dados_iniciais(id_empresa, id_usuario):
    
    for name, obj in inspect.getmembers(sys.modules[__name__]):
        if inspect.isclass(obj) and hasattr(obj, "inserir_dados_iniciais"):
            try:
                inserir_dados_iniciais = getattr(obj, "inserir_dados_iniciais")                
            except:
                return None
                        
            inserir_dados_iniciais(id_empresa, id_usuario)


def apagar_dados_empresa(id_empresa):
    nfe_wizard.dados_iniciais(os.environ["ID_EMPRESA"], os.environ["ID_USUARIO"])
    nfe_vendas.apagar_dados_empresa(os.environ["ID_EMPRESA"])
    nfe_consumidor.apagar_dados_empresa(os.environ["ID_EMPRESA"])
    nfe_pedidos.apagar_dados_empresa(os.environ["ID_EMPRESA"])
    for name, obj in inspect.getmembers(sys.modules[__name__]):
        if inspect.isclass(obj) and hasattr(obj, "apagar_dados_empresa"):
            try:
                apagar_dados_empresa = getattr(obj, "apagar_dados_empresa")
            except:
                return None
                        
            apagar_dados_empresa(id_empresa)


def apagar_dados_tabela(id_empresa, tabela):
    for table_name, obj in inspect.getmembers(sys.modules[__name__]):
        if (inspect.isclass(obj) and hasattr(obj, "apagar_dados_empresa")) and (tabela == table_name):
            try:
                apagar_dados_empresa = getattr(obj, "apagar_dados_empresa")
            except:
                return
                        
            return apagar_dados_empresa(id_empresa)


def criar_dados_iniciais_tabela(id_empresa, id_usuario, tabela):
    for table_name, obj in inspect.getmembers(sys.modules[__name__]):
        if inspect.isclass(obj) and hasattr(obj, "inserir_dados_iniciais") and (tabela == table_name):
            try:
                inserir_dados_iniciais = getattr(obj, "inserir_dados_iniciais")                
            except:
                return
                        
            return inserir_dados_iniciais(id_empresa, id_usuario)