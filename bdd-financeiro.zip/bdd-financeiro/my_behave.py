#!/usr/bin/env python3.8

import sys
from behave.__main__ import main as behave_main


if __name__ == "__main__":
    sys.exit(behave_main())

    