import sys
from rotinas import Financeiro
from rotinas import Cadastros

def abrir_telas(context, rotina):
    rotinas = rotina.split(".")
    try:
        classe = getattr(sys.modules[__name__], rotinas[0])
        method_to_call = getattr(classe, rotinas[1])
    except:
        return None

    return method_to_call(context) 
    