from datetime import datetime
import time


def wait_request(context):
    contador_xajax = context.browser.execute_script("return window.xajax_active;")
    if (contador_xajax != None) and (contador_xajax > 0):
        wait_request(context) 


def formatar_data(data):
    try:
        data = datetime.strptime(data, '%m/%d/%Y').date()
        return data.strftime("%d/%m/%Y")
    except:
        try:
            data = datetime.strptime(data, '%d/%m/%Y').date()
            return data.strftime("%d/%m/%Y")
        except Exception as ex:
            pass
