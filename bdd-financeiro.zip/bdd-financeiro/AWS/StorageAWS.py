import boto3
import os

class StorageAWS:

    @staticmethod
    def get_object(bucket_name, object_name):

        if bucket_name is None:
            raise ValueError("Invalid bucket name name.")

        if object_name is None:
            raise ValueError("Invalid object name name.")
        
        s3 = boto3.client('s3',
            region_name=os.getenv('AWS_QUEUE_REGION'),
            aws_access_key_id=os.getenv('BUCKET_AWS_ACCESS_KEY_ID'),
            aws_secret_access_key=os.getenv('BUCKET_AWS_SECRET_ACCESS_KEY'),
        )
        
        response = s3.get_object(Bucket=bucket_name, Key=object_name)

        return response['Body']._raw_stream.data

    @staticmethod
    def put_object(bucket_name, path, content_file):

        if bucket_name is None:
            raise ValueError("Invalid bucket name name.")

        if path is None:
            raise ValueError("Invalid path name.")

        if content_file is None:
            raise ValueError("Invalid content file.")

        s3 = boto3.client('s3',
            region_name=os.getenv('AWS_QUEUE_REGION'),
            aws_access_key_id=os.getenv('BUCKET_AWS_ACCESS_KEY_ID'),
            aws_secret_access_key=os.getenv('BUCKET_AWS_SECRET_ACCESS_KEY'),
        )
        
        response = s3.put_object(
            Bucket=bucket_name,
            Key=path,            
            Body=content_file,
            ACL='public-read',
        )

        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            return response['ResponseMetadata']['RequestId']
            