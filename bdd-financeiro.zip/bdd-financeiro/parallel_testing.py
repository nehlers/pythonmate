import os
import pathlib
import asyncio


async def run(features):
    cmd = ""
    time = 10
    for item in features:
        time += 10
        cmd += "behave -i {} & sleep {}; ".format(item, time)

    proc = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE)

    stdout, stderr = await proc.communicate()

    print(f'[{cmd!r} exited with {proc.returncode}]')
    if stdout:
        print(f'[stdout]\n{stdout.decode()}')
    if stderr:
        print(f'[stderr]\n{stderr.decode()}')

features = []

for root, dirs, files in os.walk(pathlib.Path(__file__).parent.absolute()):
    for file in files:
        if file.endswith(".feature"):
            features.append(file)

n_run = int(len(features)/5)+1 if len(str(len(features)/5-int(len(features)/5)).split('.')) > 1 else int(len(features)/5)

for i in range(0, n_run):
    ini = 5 * i
    fim = ini + 5
    asyncio.run(run(features[ini: fim]))
