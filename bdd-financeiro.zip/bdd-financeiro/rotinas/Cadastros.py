def contas_bancarias(context):
    context.browser.get(context.url_base +'index.php?Secao=Cadastros.Bancos&Modulo=Cadastros')

def clientes_fornecedor(context):
    context.browser.get(context.url_base +'index.php?Secao=Cadastros.Clientes&Modulo=Cadastros')

