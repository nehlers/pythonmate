import os
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from database import Database

def contas_pag(context):
    context.browser.get(context.url_base +'index.php?Secao=Financeiro.Contas.Pag&Modulo=Financeiro')


def contas_rec(context):
    context.browser.get(context.url_base +'index.php?Secao=Financeiro.Contas.Rec&Modulo=Financeiro')


def despesa_recorrente(context):
    context.browser.get(context.url_base +'index.php?Secao=Financeiro.Despesa.Recorrente&Modulo=Financeiro')
    WebDriverWait(context.browser, 30).until(
      EC.presence_of_element_located((By.ID, "btn-adicionar"))
    )


def relatorio_contas_pag(context):
    context.browser.get(context.url_base +'index.php?Secao=Relatorio.Contas.Pag&Modulo=Relatorio')


def extrato(context):
    context.browser.get(context.url_base +'index.php?Secao=Financeiro.Caixa&Modulo=Financeiro')


def despesas_recorrentes_limpar_registros(context):
  Database.apagar_dados_tabela(os.getenv('ID_EMPRESA'), 'despesa_recorrente_agendamento')
  Database.apagar_dados_tabela(os.getenv('ID_EMPRESA'), 'nfe_financeiro_contas_pag')
  Database.apagar_dados_tabela(os.getenv('ID_EMPRESA'), 'nfe_financeiro_custos_fixos')


def despesas_recorrentes_adicionar_exemplos(context):
    Database.apagar_dados_tabela(os.getenv('ID_EMPRESA'), 'nfe_financeiro_custos_fixos')
    Database.criar_dados_iniciais_tabela(os.getenv('ID_EMPRESA'), os.getenv("ID_USUARIO"), 'nfe_financeiro_custos_fixos')      


def adicionar_exemplos_cada_tabela(context):
  cursor = context.conexao_bd.cursor()

  SQL_DELETE_BANCO = f"""
  DELETE FROM `nfe_cadastros_bancos` WHERE id_empresa = {os.getenv('ID_EMPRESA')}
  """

  SQL_DELETE_CENTRO_CUSTO = f"""
  DELETE FROM `nfe_financeiro_centro` WHERE id_empresa = {os.getenv('ID_EMPRESA')}
  """

  SQL_BANCO = f"""INSERT INTO `nfe_cadastros_bancos`
        (`id_empresa`,`id_banco`,`nome_banco_cad`,`status_banco`)
        VALUES 
        ({os.getenv('ID_EMPRESA')},10,'Itau','Ativo'),
        ({os.getenv('ID_EMPRESA')},1,'Bradesco','Ativo')"""

  SQL_CENTRO_CUSTO = f"""INSERT INTO `nfe_financeiro_centro`
        (`id_empresa`,`desc_centro_custos`,`status_centro_custos`,`lixeira`)
        VALUES 
        ({os.getenv('ID_EMPRESA')},'Centro Primeiro','Ativo','Nao'),
        ({os.getenv('ID_EMPRESA')},'Centro Segundo','Ativo','Nao')"""

  cursor.execute(SQL_DELETE_BANCO)
  cursor.execute(SQL_DELETE_CENTRO_CUSTO)
  cursor.execute(SQL_BANCO)
  cursor.execute(SQL_CENTRO_CUSTO)
  
  SQL_SELECT_BANCO_SELECIONADO = f"""
  SELECT id_banco_cad
  FROM nfe_cadastros_bancos
  WHERE id_banco = 10
  AND id_empresa = {os.getenv('ID_EMPRESA')}
  LIMIT 1
  """
  cursor.execute(SQL_SELECT_BANCO_SELECIONADO)
  banco_selecionado = cursor.fetchone()

  SQL_ATUALIZA_BANCO = f"""
  UPDATE `nfe_financeiro_custos_fixos`
  SET id_banco = {banco_selecionado[0]}
  WHERE id_empresa = {os.getenv('ID_EMPRESA')}
  """

  cursor.execute(SQL_ATUALIZA_BANCO)
  
  context.conexao_bd.commit()

