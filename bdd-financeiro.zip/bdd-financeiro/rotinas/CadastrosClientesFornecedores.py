def cadastro_cliente_adicionar(context):
    context.browser.get(context.url_base +'index.php?Secao=Cadastros.Clientes&Modulo=Cadastros')
