from AWS import StorageAWS
import os	
import re


class ElementosTela:


    @staticmethod
    def comparar(elemento, **kwargs):
        nome = re.sub('[^a-zA-Z0-9 \\\]', '', elemento.screenshot_as_base64[:50])

        if kwargs['prefixo'] is not None:
            nome = kwargs['prefixo'] + nome

        arquivo = StorageAWS.get_object(os.getenv('BUCKET_BDD'), nome+".png")

        assert arquivo == elemento.screenshot_as_png


    @staticmethod
    def salva_imagem(elemento, **kwargs):
        nome = re.sub('[^a-zA-Z0-9 \\\]', '', elemento.screenshot_as_base64[:50])

        if kwargs['prefixo'] is not None:
            nome = kwargs['prefixo'] + nome

        return StorageAWS.put_object(os.getenv('BUCKET_BDD'), nome+".png", elemento.screenshot_as_png)