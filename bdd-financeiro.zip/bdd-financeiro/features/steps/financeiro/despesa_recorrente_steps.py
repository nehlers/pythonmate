from behave import *
from selenium import webdriver
import time 
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from hooks import Global


@given(u'ao adicionar uma nova despesa recorrente')
def step_impl(context):
  try: 
    Global.wait_request(context)
    context.browser.find_element(By.ID, "btn-adicionar").click()
    Global.wait_request(context)
  except:
    pass


@given(u'ao editar a despesa recorrente "{nr_linha}"')
def step_impl(context, nr_linha):
  table = WebDriverWait(context.browser, 3).until(EC.presence_of_element_located((By.ID, 'table_despesas_recorrente')))
  
  WebDriverWait(context.browser, 10).until(
    EC.invisibility_of_element_located((By.ID, "loading-despesas-recorrentes"))
  )

  linhas = table.find_elements(By.TAG_NAME, 'tr')
  linhas[int(nr_linha)].click()
  Global.wait_request(context)


@given(u'a exclusao da primeira despesa recorrente')
def step_impl(context):
  Global.wait_request(context)
        
  WebDriverWait(context.browser, 10).until(
    EC.invisibility_of_element_located((By.ID, "loading-despesas-recorrentes"))
  )
  Global.wait_request(context)

  elements = context.browser.find_elements(By.CLASS_NAME, "rcg")
  elements[1].click()
  Global.wait_request(context)

  excluir = context.browser.find_element(By.ID, 'btn-removerTodos')
  excluir.click()

  try:
    alert = context.browser.switch_to.alert
    alert.accept()
  except:
    pass

  Global.wait_request(context)