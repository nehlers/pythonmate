from behave import *
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time 
from hooks import Global


@given(u'a exclusao de todas as contas a pagar')
def step_impl(context):
    try:    
        Global.wait_request(context)
        context.browser.find_element(By.CLASS_NAME, "rcg-box").click()
        context.browser.find_element(By.ID, "action-excluir").click()

        alert = context.browser.switch_to_alert()
        alert.accept()
        Global.wait_request(context)

        time.sleep(2)
        context.browser.find_element(By.ID, "action-excluir-agrupador").click()
        time.sleep(2)
    except:
        pass


@given(u'a selecao da conta a pagar "{nome_a_pagar}"')
def step_impl(context, nome_a_pagar):
    Global.wait_request(context)

    table = WebDriverWait(context.browser, 3).until(EC.presence_of_element_located((By.ID, "table-contas-pag")))
    linhas = table.find_elements(By.TAG_NAME, "tr")
    for l in linhas:
        columns = l.find_elements(By.TAG_NAME, "td")
        if (len(columns) > 2) and (columns[2].text == nome_a_pagar):
            select = columns[0].find_element(By.CLASS_NAME, "rcg-box")
            select.click()


@given(u'a adicao de uma nova conta a pagar')
def step_impl(context):    
    Global.wait_request(context)
    context.browser.find_element(By.ID, "wrapper-btn-inserir").click()
    time.sleep(1)
    context.browser.find_element(By.ID, "btn-inserir").click()
    Global.wait_request(context)


@given(u'o agrupamento das contas a pagar')
def step_impl(context):
    Global.wait_request(context)
    context.browser.find_element(By.CLASS_NAME, "rcg-box").click()
    time.sleep(1)
    context.browser.find_elements(By.CLASS_NAME, "btn-more-actions")[1].click()    
    time.sleep(1)
    context.browser.find_element(By.ID, "action-agrupar").click() 
    Global.wait_request(context)


@given(u'ao editar a conta a pagar com descricao "{descricao}"')
def step_impl(context, descricao):
    Global.wait_request(context)

    table = WebDriverWait(context.browser, 3).until(EC.presence_of_element_located((By.ID, "table-contas-pag")))
    linhas = table.find_elements(By.TAG_NAME, "tr")
    for l in linhas:
        columns = l.find_elements(By.TAG_NAME, "td")
        if (len(columns) > 2) and (columns[2].text == descricao):
            l.click()
            # select.click()
            time.sleep(2)