from behave import *
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time 
from hooks import Global

@given(u'que tenho um novo cliente para cadastrar')
def step_impl(context): 
    #time.sleep(3)  
    context.browser.find_element(By.ID, "btn-inserir").click()
    

@when(u'eu preencher seus dados e salvar')
def step_impl(context):
    time.sleep(2)
    context.browser.find_element(By.ID, "razao_cliente").send_keys("teste")
    context.browser.find_element(By.ID, "endereco_cep_cliente_0").send_keys("88701090")
    context.browser.find_element(By.ID, "endereco_cliente_0").send_keys("rua do peso da ilusao")
    context.browser.find_element(By.ID, "endereco_numero_cliente_0").send_keys("115")
    context.browser.find_element(By.ID, "endereco_bairro_cliente_0").send_keys("Centro")
    context.browser.find_element(By.ID, "endereco_cidade_cliente_0").send_keys("Curitiba")
    context.browser.key
    context.browser.find_element(By.ID, "salvar").click()


@then(u'o sistema deve armazenar o novo cliente')
def step_impl(context):
    raise NotImplementedError(u'STEP: Then o sistema deve armazenar o novo cliente')