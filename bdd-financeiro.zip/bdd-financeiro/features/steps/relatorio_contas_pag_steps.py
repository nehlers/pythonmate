from behave import *
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from extrato_steps import buscar_id_banco_cad_por_nome_conta_id_empresa, cria_id_banco_cad_por_nome_conta
import time 
import os
from hooks import Global
# from environment import criar_conexao_bd


def cria_despesa_recorrente(**kwargs):
    cursor = kwargs['context'].conexao_bd.cursor()
    SQL = f" INSERT INTO nfe_financeiro_custos_fixos SET id_empresa = {os.getenv('ID_EMPRESA')}, nome_conta = '{kwargs['nome_conta']}', id_banco = {kwargs['id_banco']}, valor_custo = 100, data_inicio_ocorrencia = '2020-03-03', periodicidade = 1, dia_semana_ocorrencia = 3" 
    cursor.execute(SQL)
    kwargs['context'].conexao_bd.commit()
    return cursor.lastrowid


def cria_agendamento_despesa_recorrente(**kwargs):
    cursor = kwargs['context'].conexao_bd.cursor()
    SQL = f" INSERT INTO despesa_recorrente_agendamento SET id_custo_fixo = {kwargs['id_custo']}, valor_custo = '35.00', data_agendamento = '2020-03-03', status = 1" 
    cursor.execute(SQL)
    kwargs['context'].conexao_bd.commit()
    return cursor.lastrowid


@given(u'a exclusao de todas as despesas recorrentes')
def step_impl(context):
    SQL = " UPDATE nfe_financeiro_custos_fixos SET lixeira = 'Sim' WHERE id_empresa = "+os.getenv('ID_EMPRESA')

    cursor = context.conexao_bd.cursor()
    cursor.execute(SQL)

    context.conexao_bd.commit()


# @given(u'a adicao de despesa recorrente com agendamento')
# def step_impl(context):
#     Global.wait_request(context)
    
#     id_banco = buscar_id_banco_cad_por_nome_conta_id_empresa(context=context, nome_conta='Relatorio contas pag')
#     if not id_banco:
#         context.conexao_bd = None
#         criar_conexao_bd(context)

#         id_banco = cria_id_banco_cad_por_nome_conta(context=context, nome_conta='Relatorio contas pag')
    
#     context.conexao_bd = None
#     criar_conexao_bd(context)
#     id_custo = cria_despesa_recorrente(context=context, nome_conta='Relatorio contas pag', id_banco=id_banco)

#     context.conexao_bd = None
#     criar_conexao_bd(context)
#     cria_agendamento_despesa_recorrente(context=context, id_custo=id_custo)
    
    
