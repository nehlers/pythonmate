from features.steps.geral.steps import *
from features.steps.financeiro.despesa_recorrente_steps import *
from features.steps.financeiro.contas_pag_steps import *
from features.steps.cadastro.cadastro_clifor_steps import *