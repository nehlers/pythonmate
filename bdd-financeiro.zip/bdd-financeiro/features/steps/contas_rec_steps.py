from behave import *
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import time 
from Elementos import ElementosTela
from hooks import Global


@given(u'a exclusao de todas as contas a receber')
def step_impl(context):
    try:    
        Global.wait_request(context)
        context.browser.find_element(By.CLASS_NAME, "rcg-box").click()
        context.browser.find_element(By.ID, "action-excluir").click()

        alert = context.browser.switch_to_alert()
        alert.accept()
        Global.wait_request(context)

        time.sleep(2)
        context.browser.find_element(By.ID, "action-excluir-agrupador").click()
    except:
        pass


@given(u'a adicao de uma nova conta a receber')
def step_impl(context):
    Global.wait_request(context)
    context.browser.find_element(By.ID, "btn-inserir").click()
    Global.wait_request(context)
     

@given(u'o agrupamento das contas a receber')
def step_impl(context):
    Global.wait_request(context)
    context.browser.find_element(By.CLASS_NAME, "rcg-box").click()
    time.sleep(1)
    context.browser.find_element(By.CLASS_NAME, "btn-more-actions").click()    
    time.sleep(1)
    context.browser.find_element(By.ID, "action-agrupar").click()       
    Global.wait_request(context)