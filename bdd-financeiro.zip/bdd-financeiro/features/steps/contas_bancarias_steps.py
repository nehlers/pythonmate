from behave import *
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import time 
from hooks import Global


@given(u'a adicao de uma nova conta bancaria')
def step_impl(context):
    Global.wait_request(context)
    context.browser.find_element(By.ID, "btn-inserir").click()
    Global.wait_request(context)


@given(u'a exclusao da conta bancaria "{nome_conta_bancaria}"')
def step_impl(context, nome_conta_bancaria):
    Global.wait_request(context)
    try:
        tables = context.browser.find_elements(By.ID, "table-contas")
   
        for tb in tables:
            if "table" in tb.tag_name:
                rows = tb.find_elements(By.TAG_NAME, "tr")                        
                
                for r in rows: 
                    columns = r.find_elements(By.TAG_NAME, "td")
                
                    for x in range(len(columns)): 
                        if columns[1].text == nome_conta_bancaria:
                            items = columns[x].find_element(By.CLASS_NAME, "rcg-box")
                            items.click()

                            elem = context.browser.find_element(By.ID, "btn-excluir")
                            elem.click()       

                            alert = context.browser.switch_to_alert()
                            alert.accept()
                            Global.wait_request(context)

                            time.sleep(2)
                            context.browser.find_element(By.ID, "btn-inativar").click() 
    except:
        Global.wait_request(context)
        pass


@given(u'a selecao do banco "{codigo_banco}"')
def step_impl(context, codigo_banco):
    time.sleep(1)
    divs = context.browser.find_elements(By.CLASS_NAME, "list-banks")
    for dv in divs:
        buttons = dv.find_elements(By.TAG_NAME, "BUTTON")
        for b in buttons:
            if b.find_element(By.TAG_NAME, "STRONG").text == codigo_banco:
               b.click()
            #    Global.wait_request(context)
               break


@given(u'a alteração dos dados da conta "{nome_conta}"')
def step_impl(context, nome_conta):
    SQL = ''
    table = context.table
    
    for i in range(len(table.headings)):
        SQL = SQL+", "+table.headings[i] +" = '"+ table.rows[0].cells[i]+"'"

    if SQL != '':
        SQL = SQL.replace(',', '', 1)
        SQL = " UPDATE nfe_cadastros_bancos SET "+SQL+" WHERE (nome_banco_cad = '"+nome_conta+"') AND (lixeira = 'Nao')"

        cursor = context.conexao_bd.cursor()
        cursor.execute(SQL)

        context.conexao_bd.commit()
