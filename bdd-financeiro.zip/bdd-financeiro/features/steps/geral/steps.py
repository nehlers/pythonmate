from behave import *
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from hooks import Telas, Global
from datetime import date
import time 
import os
import re
from Elementos import ElementosTela
from database.Models.nfe_config_usuarios_relatorios import nfe_config_usuarios_relatorios
from database.Models.nfe_config_usuarios import nfe_config_usuarios
from database import Database

DATE_REGEX = "^((0?[13578]|10|12)(-|\/)(([1-9])|(0[1-9])|([12])([0-9]?)|(3[01]?))(-|\/)((19)([2-9])(\d{1})|(20)([01])(\d{1})|([8901])(\d{1}))|(0?[2469]|11)(-|\/)(([1-9])|(0[1-9])|([12])([0-9]?)|(3[0]?))(-|\/)((19)([2-9])(\d{1})|(20)([01])(\d{1})|([8901])(\d{1}))|(((|1)\d{1})/((0|1|2)\d{1})/((19|20)\d{2})))$"


def obter_nome_usuario(context):
    return nfe_config_usuarios.get(
        nfe_config_usuarios.login_usuario == os.getenv('LOGIN'),
        nfe_config_usuarios.id_empresa == os.getenv('ID_EMPRESA'),
    ).nome_usuario


@given(u'o preenchimento dos campos')
def step_impl(context):
    Global.wait_request(context)
    for rows in context.table:
        for i in range(len(rows)):
            try:
                elem = context.browser.find_element(By.ID, rows.headings[i])
            except Exception as e:
                try:
                    elem = context.browser.find_element(By.NAME, rows.headings[i])
                except Exception as e:
                    raise e

            if(elem.tag_name == 'select'):
                elem = Select(elem)
                elem.select_by_visible_text(rows.cells[i])
            else:
                elem.send_keys(Keys.CONTROL, 'a', Keys.BACKSPACE)  #limpa campo 
                elem.send_keys(rows.cells[i])

            Global.wait_request(context)


@given(u'o click do elemento "{elemento}"')
def step_impl(context, elemento):
    Global.wait_request(context)
    action=ActionChains(context.browser)
    try:
        elem = WebDriverWait(context.browser, 3).until(EC.presence_of_element_located((By.ID, elemento)))
        action.move_to_element(elem).click().perform()
    except Exception as e:
        try:
            elem = WebDriverWait(context.browser, 5).until(EC.presence_of_element_located((By.CLASS_NAME, elemento)))
            action.move_to_element(elem).click().perform()
        except:
            try:
                elem = context.browser.find_element(By.XPATH, elemento)
                action.move_to_element(elem).click().perform()
            except Exception as e:
                raise e
    Global.wait_request(context)


@given(u'a pesquisa pelo texto "{texto}"')
def step_impl(context, texto):
    Global.wait_request(context)
    context.browser.find_element(By.ID, "pesquisar").send_keys(texto)
    Global.wait_request(context)
    context.browser.find_element(By.CLASS_NAME, "action-search").click()
    Global.wait_request(context)
    

@then(u'deve conter a classe "{classe_nome}" no elemento "{elemento}"')
def step_impl(context, classe_nome, elemento):
    try:
        el = context.browser.find_element(By.ID, elemento)
        assert el.get_attribute('class').find(classe_nome) >= 0
    except Exception as e:
        raise e 


@then(u'deve haver o elemento "{elemento}" na tela "{nome_imagem}"')
def step_impl(context, elemento, nome_imagem):
    try:
        Global.wait_request(context)
        context.browser.find_element(By.CLASS_NAME, elemento)
    except:
        try:
            Global.wait_request(context)
            context.browser.find_element(By.ID, elemento)
            ElementosTela.comparar(el, prefixo=nome_imagem)
        except Exception as e:
            raise e

    
@then(u'devem haver os seguintes lancamento na tabela "{tabela}"')
def step_impl(context, tabela):
    Global.wait_request(context)
    table = WebDriverWait(context.browser, 10).until(
      EC.presence_of_element_located((By.ID, tabela))
    )

    Global.wait_request(context)
    WebDriverWait(context.browser, 10).until(
        EC.invisibility_of_element_located(table.find_elements(By.CLASS_NAME, 'gif'))
    )

    Global.wait_request(context)
    assert "table" == table.tag_name
    contextRows = context.table.rows

    rows = table.find_elements(By.TAG_NAME, "tr")
    assert len(rows) - 1 == len(contextRows)

    try:    
        for r in range(len(rows)):      
            columns = rows[r].find_elements(By.TAG_NAME, "td")
            for c in range(len(columns)):
                columnContext = contextRows[r - 1].cells[c]
                if columnContext.find('usuario:') >= 0:
                    valorColuna = columns[c].text.replace('\n', '')
                    assert valorColuna == obter_nome_usuario(context)
                elif columnContext.find('date:') >= 0:
                    if columnContext.split(":")[1] == 'hoje':
                        data = date.today().strftime("%d/%m/%Y")
                    valorColuna = columns[c].text.replace('\n', '')
                    assert valorColuna == data
                elif columnContext.find('status:') >= 0:
                    status = columns[c].find_element(By.CLASS_NAME, 'status-icon')
                    assert status.get_attribute('data-tooltip') == columnContext.split(":")[1]                
                else:
                    assert columns[c+1].text.replace('\n', '') == columnContext
                    
        Global.wait_request(context)
    except:
        pass


@then(u'devem haver os seguintes lancamento na tabela do relatorio "{tabela}"')
def step_impl(context, tabela):
    Global.wait_request(context)
    tables = context.browser.find_elements(By.ID, tabela)

    dados = []
    for tb in tables:
        if "table" in tb.tag_name:
            rows = tb.find_elements(By.TAG_NAME, "tr")
                        
            for row in rows:      
                th = row.find_elements(By.TAG_NAME, "td")
                dt = []
                for t in th:
                    p = re.compile(DATE_REGEX)
                    if p.match(t.text) is not None:
                        dt.append(Global.formatar_data(t.text))
                    else:
                        dt.append(t.text)
                    
                if dt != []:
                    dados.append(dt)

    for i in range(len(context.table.rows)):
        assert context.table.rows[i].cells == dados[i]


@given(u'a tabela "{tabela}" clique na {nr_linha} linha')
def step_impl(context, tabela, nr_linha):
    Global.wait_request(context)
    tables = context.browser.find_elements(By.ID, tabela)    
    
    for tb in tables:
        if "table" in tb.tag_name:
            rows = tb.find_elements(By.TAG_NAME, "tr")                        
            for i in range(len(rows)): 
                if i == int(nr_linha):
                    rows[i].find_elements(By.TAG_NAME, "td")[1].click()


@given(u'clique na acao "{acao}" na linha "{nr_linha}" na tabela "{tabela}"')
def step_impl(context, acao, nr_linha, tabela):
    element = WebDriverWait(context.browser, 10).until(
      EC.presence_of_element_located((By.ID, tabela))
    )

    linhas = element.find_elements(By.TAG_NAME, 'tr')
    linhas[int(nr_linha)].find_element(By.CLASS_NAME, acao).click()

    
@given(u'o agrupamento das contas')
def step_impl(context):
    elem = context.browser.find_element(By.CLASS_NAME, "rcg-box")
    elem.click()

    elem = context.browser.find_element(By.CLASS_NAME, "btn-more-actions")
    elem.click()
    
    elem = context.browser.find_element(By.ID, "action-agrupar")        
    elem.click()       

    Global.wait_request(context)


@then(u'o cancelamento da tarefa')
def step_impl(context):
    try:
        context.browser.get(context.url_base)
        alert = context.browser.switch_to_alert()
        alert.accept()
        Global.wait_request(context)
    except:
        pass


@then(u'devem haver os valores nos elementos')
def step_impl(context):
    for rows in context.table:
        for i in range(len(rows)):    
            elem = context.browser.find_element(By.ID, rows.headings[i])
            assert elem.get_attribute('value') == rows[i]


@then(u'deve conter o texto "{texto}" no elemento "{elemento}"')
def step_impl(context, texto, elemento):
    elem = context.browser.find_element(By.ID, elemento)
    assert elem.text.find(texto) >= 0  


@given(u'selecionar a opção "{opcao}" no select "{elemento}"')
def step_impl(context, opcao, elemento):
    elem = context.browser.find_element(By.ID, elemento)
    select = Select(elem)
    select.select_by_visible_text(opcao)
    elem.send_keys(Keys.TAB) # aplica o change no elemento


@then(u'o "{elemento}" deve existir na tela')
def step_impl(context, elemento):
    elem = WebDriverWait(context.browser, 10).until(
      EC.presence_of_element_located((By.ID, elemento))
    )
    assert elem.is_displayed()


@then(u'o "{elemento}" nao deve existir na tela')
def step_impl(context, elemento):
    elem = WebDriverWait(context.browser, 10).until(
      EC.presence_of_element_located((By.ID, elemento))
    )
    assert elem == None


@then(u'uma alerta de "{tipo}" com a mensagem "{mensagem}" deve ser exibida')
def step_impl(context, tipo, mensagem):
    alerta = WebDriverWait(context.browser, 10).until(
      EC.presence_of_element_located((By.CLASS_NAME, 'notify-message-general-wrapper'))
    )
    alerta_mensagem = context.browser.find_element(By.CLASS_NAME, 'notify-message-general-info')
    if tipo == 'sucesso':
        assert alerta.get_attribute('data-notify-state') == 'message-success'
    else: 
        assert alerta.get_attribute('data-notifos.gety-state') == 'message-erro'

    assert alerta_mensagem.text == mensagem


@given(u'confirmar alerta')
def step_impl(context):
    alerta = WebDriverWait(context.browser, 10).until(
      EC.alert_is_present()
    )
    # alert = context.browser.switch_to_alert()
    alerta.accept()
    time.sleep(2)


@given(u'a rotina "{nome_rotina}"')
def step_impl(context, nome_rotina):
    Global.wait_request(context)   
    Telas.abrir_telas(context, nome_rotina)


@given(u'a exclusao da configuracao do relatorio "{relatorio}"')
def step_impl(context, relatorio):
    nfe_config_usuarios_relatorios.delete().where(
        nfe_config_usuarios_relatorios.id_empresa == os.getenv('ID_EMPRESA'),
        nfe_config_usuarios_relatorios.relatorio == relatorio).execute()


@given(u'aguardar o elemento "{elemento}" ser exibido na tela')
def step_impl(context, elemento):
    WebDriverWait(context.browser, 10).until(
        EC.presence_of_element_located((By.ID, elemento))
    )


@given(u'selecionar a opcao "{elemento}" no radio button')
def step_impl(context, elemento):
    WebDriverWait(context.browser, 10).until(
        EC.element_to_be_clickable((By.ID, elemento))
    )
    radio = context.browser.find_element(By.ID, elemento)
    radio.click()


@given(u'selecionar as opcoes "{opcoes}" no multi select "{id_select}"')
def step_impl(context, opcoes, id_select):
    Global.wait_request(context)    
    div = context.browser.find_element(By.ID, id_select)

    button = div.find_element(By.XPATH, f'.//button')
    button.click()
    
    option = div.find_element(By.XPATH, f'.//a[text()="{opcoes}"]')
    option.click()
    

@given(u'a remocao de todos os dados da tabela "{nome_tabela}"')
def step_impl(context, nome_tabela):
    Database.apagar_dados_tabela(os.getenv('ID_EMPRESA'), nome_tabela)


@given(u'a recarga de todos os dados iniciais da tabela "{nome_tabela}"')
def step_impl(context, nome_tabela):
    Database.apagar_dados_tabela(os.getenv('ID_EMPRESA'), nome_tabela)
    Database.criar_dados_iniciais_tabela(os.getenv('ID_EMPRESA'), os.getenv("ID_USUARIO"), nome_tabela)


@given(u'o click do elemento "{elemento}" com confirmacao')
def step_impl(context, elemento):
    Global.wait_request(context)
    action=ActionChains(context.browser)

    elem = WebDriverWait(context.browser, 3).until(EC.presence_of_element_located((By.ID, elemento)))
    action.move_to_element(elem).click().perform()
        
    try:
        alert = context.browser.switch_to.alert
        alert.accept()
    except:
        pass

    Global.wait_request(context)
