from behave import *
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import time 
import os
from hooks import Global
from peewee import *
from database.Models.nfe_cadastros_bancos import nfe_cadastros_bancos


def buscar_id_banco_cad_por_nome_conta_id_empresa(**kwargs):
    id = nfe_cadastros_bancos.get(
        nfe_cadastros_bancos.id_empresa == os.getenv('ID_EMPRESA'),
        nfe_cadastros_bancos.nome_banco_cad == kwargs['nome_conta'], 
        nfe_cadastros_bancos.lixeira == 'Nao'
    ).id_banco_cad
    
    return id


def cria_id_banco_cad_por_nome_conta(**kwargs):
    cursor = kwargs['context'].conexao_bd.cursor()
    SQL = f" INSERT INTO nfe_cadastros_bancos SET id_empresa = {os.getenv('ID_EMPRESA')}, id_banco = 37, nome_banco_cad = '{kwargs['nome_conta']}'"
    cursor.execute(SQL)
    kwargs['context'].conexao_bd.commit()
    return cursor.lastrowid


@then(u'o saldo do sistema da conta bancaria "{nome_conta}" deve ser "{valor_saldo}"')
def step_impl(context, nome_conta, valor_saldo):
    Global.wait_request(context)
    
    saldo = None
    id_banco = buscar_id_banco_cad_por_nome_conta_id_empresa(context=context, nome_conta=nome_conta)
    
    elemento = context.browser.find_element(By.ID, "saldos_contas")
    lists = elemento.find_elements(By.XPATH, f"//li[@codigo='{id_banco}']")

    for ls in lists:
        for span in ls.find_elements(By.TAG_NAME, "span"):
            if span.get_attribute("qa") == 'saldo_sistema':
                saldo = span.text
                break
    
    assert saldo == valor_saldo           


@then(u'deve haver saldo do banco para a conta bancaria "{nome_conta}"')
def step_impl(context, nome_conta):
    Global.wait_request(context)
    
    saldo = None
    id_banco = buscar_id_banco_cad_por_nome_conta_id_empresa(context=context, nome_conta=nome_conta)
    
    elemento = context.browser.find_element(By.ID, "saldos_contas")
    lists = elemento.find_elements(By.XPATH, f"//li[@codigo='{id_banco}']")

    for ls in lists:
        for span in ls.find_elements(By.TAG_NAME, "span"):
            if span.get_attribute("qa") == 'saldo_banco':
                saldo = span.text
                break

    assert (saldo != None) and (saldo != 0)
