from behave import *
from behave.log_capture import capture
from selenium import webdriver
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import os
import time 
from hooks import Telas, Global
from database import Database
from dotenv import load_dotenv
import os
import stat

load_dotenv()

LOGIN_VISUALHOST = 'VISUALHOST'
CONST_PRE_PUSH  = "#!/bin/bash \n\nsource .venv/bin/activate \n\npython my_behave.py \n"


def criar_browser(context):    
    if context.browser is None:
        context.url_base = os.getenv('URL_BASE')
        context.config.setup_logging()

        navegadores = {
            "firefox": firefox,
            "chrome": chrome,
            "remote": remote
        }
        nav = navegadores.get(os.getenv("NAVEGADOR").lower(), lambda: "navegador inválido!")        
        nav(context)


def firefox(context):
    options = FirefoxOptions()
    options.add_argument("--start-maximized")
    options.headless = True if os.getenv('HEADLESS') is None or os.getenv('HEADLESS') == '' else False
    context.browser = webdriver.Firefox(options=options)


def chrome(context):
    options = ChromeOptions()
    options.add_argument("--start-maximized")
    options.headless = True if os.getenv('HEADLESS') is None or os.getenv('HEADLESS') == '' else False
    context.browser = webdriver.Chrome(options=options)


def remote(context):
    options = ChromeOptions()
    options.add_argument("--headless")
    options.add_argument("--disable-gpu")
    options.add_argument("--start-maximized")

    capabilities = options.to_capabilities()
    context.browser = webdriver.Remote(command_executor=os.getenv("REMOTE"), desired_capabilities=capabilities)


def before_all(context):      
    context.browser = None
    criar_browser(context)
    
    Database.criar_dados_iniciais(os.getenv("ID_EMPRESA"), os.getenv("ID_USUARIO"))    

    context.browser.get(context.url_base)

    elem = context.browser.find_element_by_name("login")
    elem.clear()
    elem.send_keys(os.getenv('LOGIN'))
    elem = context.browser.find_element_by_name("senha")
    elem.clear()
    elem.send_keys(os.getenv('SENHA'))
    elem.send_keys(Keys.RETURN)
    time.sleep(1)

    try:
        confirmacao = context.browser.find_element(By.ID, "login-revoking-other")
        confirmacao.click()
        Global.wait_request(context)
    except:
        pass

    elem = WebDriverWait(context.browser, 30).until(EC.presence_of_element_located((By.CLASS_NAME, 'toolbar-header')))  
    assert "vhsys" in context.browser.title 
    
    
def before_tag(context, tag):
    Telas.abrir_telas(context, tag)


def before_step(context, step):
    Global.wait_request(context)


def after_step(context, step):
    Global.wait_request(context)


def after_all(context):
    Database.apagar_dados_empresa(os.getenv("ID_EMPRESA"))    

    with open(".git/hooks/pre-push", "w") as f:
        f.write(CONST_PRE_PUSH)

    st = os.stat('.git/hooks/pre-push')
    os.chmod('.git/hooks/pre-push', st.st_mode | stat.S_IEXEC)

    if context.browser is not None:
        context.browser.quit()
